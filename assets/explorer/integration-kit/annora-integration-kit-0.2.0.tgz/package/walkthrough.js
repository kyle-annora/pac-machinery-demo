import { c as ie, A as ae, B as se, C as ce, b as le } from "./project-repository-M8FB_Gz3.js";
const z = "kinetic-01", ue = "annora.walkthrough.projects.v1.", de = "annora.walkthrough.independent.projects.v1.", he = /^WTI?-[A-Za-z0-9-]{8,64}$/, H = (e, t) => Object.assign(new Error(t), { code: e }), M = (e) => typeof e == "string" && he.test(e);
function X(e) {
  return e instanceof URLSearchParams ? e : e instanceof URL ? e.searchParams : new URLSearchParams(e || "");
}
function Ie(e = globalThis.location?.search || "") {
  return X(e).has("walkthrough");
}
function Te(e = globalThis.location?.search || "") {
  const t = X(e).getAll("walkthrough");
  return t.length === 1 && M(t[0]) ? t[0] : null;
}
function J(e) {
  if (!M(e)) throw H("WALKTHROUGH_SESSION_INVALID", "This walkthrough link is incomplete. Open the walkthrough start page to resume or start a new demonstration.");
  return e;
}
function w(e) {
  return J(e).startsWith("WTI-") ? "independent" : "explorer";
}
function pe(e) {
  return (w(e) === "independent" ? de : ue) + e;
}
function Z(e, t) {
  const r = new URL(e, globalThis.location?.href || "http://localhost/");
  return r.searchParams.set("walkthrough", J(t)), r;
}
const fe = /* @__PURE__ */ new Set([
  "saveDraft",
  "submitInquiry",
  "saveQuoteDraft",
  "issueQuote",
  "sendReply",
  "sendCustomerReply",
  "acknowledgeNextStep",
  "createSampleInquiry",
  "createSampleQuote",
  "requestRevision",
  "simulateReply",
  "confirmNextStep"
]);
function _(e, t = !1) {
  if (e && (e.productId !== z || e.modelId !== z))
    throw H("WALKTHROUGH_PRODUCT_INVALID", "This demonstration follows the crank-slider project. Open another product outside the walkthrough.");
  if (e && t && !e.viewerReference)
    throw H("WALKTHROUGH_REFERENCE_REQUIRED", "Return to the independent viewer and select a part before continuing this inquiry. Its saved model reference must stay with the demonstration.");
}
function me(e, t = {}) {
  const r = pe(e), n = w(e) === "independent", c = ie({ ...t, key: r }), l = { ...c, mode: "walkthrough", storageKey: r, sessionId: e };
  for (const [o, m] of Object.entries(c))
    typeof m == "function" && (l[o] = async (...g) => {
      (o === "getDraft" || o === "createSampleInquiry") && _(g[0], n);
      const s = o === "saveDraft" ? g[0] : o === "submitInquiry" ? g[0]?.draft : null;
      if (s && (_(s.context, n), n && Array.isArray(s.requestItems)))
        for (const y of s.requestItems) _(y?.context, !0);
      const u = await m(...g);
      if (fe.has(o))
        try {
          const y = globalThis.window;
          y?.dispatchEvent && typeof globalThis.CustomEvent == "function" && y.dispatchEvent(new CustomEvent("annora:walkthrough-change", { detail: { sessionId: e, method: o } }));
        } catch {
        }
      return u;
    });
  return Object.freeze(l);
}
const I = [
  { id: 1, title: "Understand the product", short: "Product" },
  { id: 2, title: "Get a quotation", short: "Quotation" },
  { id: 3, title: "Resolve and move forward", short: "Next step" }
];
function ge(e, { hasDraft: t = !1, viewer: r = "explorer" } = {}) {
  if (!e) return {
    chapter: t ? 2 : 1,
    role: "buyer",
    state: t ? "inquiry" : "explore",
    title: t ? "Review a request grounded in the product." : r === "independent" ? "Start in the customer’s existing viewer." : "Start with the mechanism.",
    note: t ? "Use sample details for 20 assemblies. Review the request, then confirm it below." : r === "independent" ? "Select Connecting rod. Carry the selected part and this model version into a reviewed inquiry." : "Run one short cycle. Select Connecting rod, then start an inquiry from that context.",
    focus: t ? ["Review inquiry", "Confirm demo inquiry"] : ["Request a quote", "Inquire"]
  };
  const n = e.quotes.at(-1), c = ae(e), l = se(e);
  if (c) return { chapter: 3, role: "buyer", state: "question", title: "Answer the seller’s question.", note: "The reply stays with this project and its quotation. Review it before confirming.", focus: ["Reply to question", "Review reply", "Confirm demo reply"] };
  if (l) return { chapter: 3, role: "seller", state: "revision", title: "Respond with a revised quotation.", note: "Update to 30 assemblies. Address quantity and requested timing; proposed delivery remains a separate commitment.", focus: ["Prepare next version", "Continue quotation", "Review quotation", "Issue demo quotation"] };
  if (!n) return { chapter: 2, role: "seller", state: "quotation", title: "Turn the inquiry into a reviewed quotation.", note: "Use demo pricing and propose 6–8 weeks after technical review. Save a draft, review it, then issue v1.", focus: ["Continue quotation", "Prepare quotation", "Review quotation", "Issue demo quotation"] };
  const o = e.nextSteps.filter((m) => m.quoteId === n.id).at(-1);
  return o ? e.messages.some((g) => g.kind === "next-step-confirmation" && g.nextStepId === o.id) ? { chapter: 3, role: "buyer", state: "complete", title: "The next step is agreed.", note: "The product reference, inquiry, quotation versions and confirmed discussion stay together. No order or payment has been created.", focus: ["View conversation"] } : { chapter: 3, role: "seller", state: "acknowledge", title: "Close the loop on the next action.", note: "Acknowledge the customer’s requested engineering discussion. Review your response before confirming.", focus: ["Confirm next step", "Review response", "Confirm demo response"] } : n.version > 1 ? { chapter: 3, role: "buyer", state: "compare", title: "See what changed, then agree on the next step.", note: "Compare v1 and v2. Request an engineering review of the mounting interface and application load.", focus: ["Choose next step", "Review request", "Confirm demo request"] } : { chapter: 3, role: "buyer", state: "change", title: "Keep a change inside the same conversation.", note: "Request 30 assemblies and an earlier delivery using sample changes. Review and confirm the request.", focus: ["Request a change", "Review request", "Confirm demo request"] };
}
function U(e) {
  const t = new URL(e, globalThis.location?.href || "http://localhost/");
  return t.search = "", t.hash = "", t.pathname = t.pathname.replace(/\/(?:integrations\/existing-viewer|walkthrough|product-room|studio)(?:\/(?:index\.html)?)?$/, "/"), t.pathname.endsWith("/index.html") && (t.pathname = t.pathname.slice(0, -10)), t.pathname.endsWith("/") || (t.pathname += "/"), t;
}
function V(e, t) {
  const r = w(t) === "independent", n = Z(new URL(r ? "integrations/existing-viewer/" : "product-room/", U(e)), t);
  return r || (n.searchParams.set("model", "kinetic-01"), n.hash = "explore"), n;
}
function B(e, t, r, n) {
  if (!t && e.role === "buyer" && w(n) === "independent")
    return V(r, n);
  const c = Z(new URL(e.role === "seller" ? "studio/" : "product-room/", U(r)), n);
  if (e.role === "buyer" && c.searchParams.set("model", "kinetic-01"), !t) c.hash = e.state === "inquiry" ? "inquiry" : "explore";
  else if (e.role === "seller") {
    const l = new URLSearchParams({ id: t.id });
    e.state === "revision" && l.set("tab", "quotation"), c.hash = `project?${l}`;
  } else {
    const l = new URLSearchParams({ project: t.id, tab: e.state === "question" || e.state === "complete" ? "activity" : "quotation" });
    t.quotes.at(-1) && l.set("quote", t.quotes.at(-1).id), c.hash = `project&${l}`;
  }
  return c;
}
function we() {
  const e = /* @__PURE__ */ new Map(), t = /* @__PURE__ */ new Set(), r = () => {
    for (const n of t) n();
  };
  return {
    register(n, c) {
      if (!n || typeof c?.run != "function" || !c.id) throw new TypeError("A named walkthrough action and handler are required.");
      const l = { owner: n, ...c };
      return e.set(n, l), r(), () => {
        e.get(n) === l && (e.delete(n), r());
      };
    },
    get(n) {
      return e.get(n) || null;
    },
    subscribe(n) {
      return t.add(n), () => t.delete(n);
    }
  };
}
const K = we(), Ue = (e, t) => K.register(e, t), Y = (e) => K.get(e), ye = (e) => K.subscribe(e);
function ve(e, t, r, n = Y) {
  return !!e && t === r && (!e.owner || n(e.owner) === e);
}
function qe({ now: e = () => Date.now(), settleMs: t = 800 } = {}) {
  let r = !1, n = 0;
  return {
    get blocked() {
      return r || e() < n;
    },
    async run(c) {
      if (r || e() < n) return !1;
      r = !0, n = e() + t;
      try {
        return await c(), !0;
      } finally {
        r = !1, n = Math.max(n, e() + 250);
      }
    }
  };
}
function be(e) {
  return !!(e && (e.confirmation || [
    "inquiry-project",
    "inquiry-resume",
    "inquiry-recovery",
    "seller-review-current-quotation",
    "seller-review-current-reply"
  ].includes(e.id)));
}
function je({ state: e, panel: t }) {
  return !e || !t || e.busy ? { id: "inquiry-loading", busy: !0, disabled: !0, run: () => {
  } } : !e.open || !e.expanded ? {
    id: "inquiry-resume",
    note: "Reopen the saved inquiry before reviewing or confirming it.",
    run: () => t.resume()
  } : e.stage === "confirmed" ? {
    id: "inquiry-project",
    note: "Open the saved project to continue the buyer and seller conversation.",
    run: () => t.openProject()
  } : ["CONFLICT", "STALE_REVIEW", "RELOAD_FAILED", "DRAFT_UNAVAILABLE", "REVIEW_UNAVAILABLE"].includes(e.errorCode) ? {
    id: "inquiry-recovery",
    disabled: !0,
    note: "Keep your entries or explicitly load the saved draft in the inquiry panel.",
    run: () => {
    }
  } : e.hasDraft ? e.stage === "review" ? {
    id: "inquiry-confirm",
    confirmation: !0,
    note: "Confirm the complete inquiry shown beside the product. Nothing is sent.",
    run: () => t.confirm()
  } : {
    id: "inquiry-review",
    note: "Fill empty fields with fictional sample details, then review the complete inquiry before confirming.",
    run: () => t.review({ fillSample: !0 })
  } : { id: "inquiry-loading", disabled: !0, run: () => {
  } };
}
const Re = Object.freeze({
  "inquiry-review": "Prepare your inquiry",
  "inquiry-confirm": "Review your inquiry",
  "inquiry-resume": "Continue your saved inquiry",
  "inquiry-recovery": "Resolve the saved draft",
  "inquiry-project": "Open your saved project",
  "seller-review-sample-quotation": "Prepare the quotation",
  "seller-review-current-quotation": "Review your draft",
  "seller-confirm-quotation": "Review the quotation",
  "change-review": "Request a revision",
  "change-confirm": "Review requested changes",
  "next-review": "Choose the next step",
  "next-confirm": "Review your next step",
  "seller-review-acknowledgement": "Reply to the next-step request",
  "seller-confirm-response": "Review your response",
  "seller-review-current-reply": "Review your reply",
  "reply-review": "Prepare your reply",
  "reply-confirm": "Review your reply",
  "latest-quotation": "Open the latest quotation",
  "completed-conversation": "View the agreed next step",
  "return-to-project": "Return to your project"
});
function xe({ role: e, chapter: t, action: r = {}, flow: n = {}, locked: c = !1 }) {
  const l = I.find((m) => m.id === t) || I[0], o = /^handoff-(buyer|seller)-/.exec(r.id || "")?.[1];
  return {
    chapterLabel: `${l.id} / ${I.length} · ${l.title}`,
    title: o ? `Continue as ${o}.` : r.title || Re[r.id] || n.title || "",
    roleLabel: e === "seller" ? "Seller view" : "Buyer view",
    nextRoleLabel: o ? `Next: ${o}` : "",
    buttonLabel: c ? "Please wait…" : r.id === "complete" ? "Demo complete" : r.confirmation ? "Confirm & continue" : "Continue demo"
  };
}
function Oe(e) {
  const t = me(e), r = location.pathname.includes("/studio/"), n = new URLSearchParams(location.search), c = w(e) === "independent" && location.pathname.includes("/integrations/existing-viewer/") && n.has("project"), l = r || c && n.get("returnRole") === "seller" ? "seller" : "buyer", o = document.createElement("aside");
  o.className = "walkthrough-strip", o.setAttribute("aria-label", "Demo walkthrough"), o.innerHTML = `<div class="wt-main"><div class="wt-context" aria-live="polite" aria-atomic="true"><span class="wt-current-chapter"></span><strong class="wt-current-step">Opening the demo…</strong></div><div class="wt-role-context" aria-live="polite" aria-atomic="true"><span class="wt-role">${l === "seller" ? "Seller" : "Buyer"} view</span><span class="wt-next-role" hidden></span></div><button type="button" class="wt-handoff" disabled data-step="loading"><span class="wt-action-label">Continue demo</span><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M4 12h15m-6-6 6 6-6 6"/></svg></button><details class="wt-tools"><summary aria-label="Demo guide">Guide</summary><div class="wt-menu"><p class="wt-menu-note"></p><nav class="wt-chapters" aria-label="Demonstration chapters"></nav><button type="button" class="wt-navigation" aria-expanded="false">Show workspace navigation</button><p class="wt-sample-note">Fictional sample · Saved in this browser. Nothing is sent.</p><button type="button" class="wt-restart">Start a new sample</button></div></details></div><p id="wt-next-action" class="wt-sr-only"></p><p class="wt-error" role="alert" hidden></p>`, document.body.prepend(o), document.body.dataset.walkthrough = "true", document.body.dataset.walkthroughViewer = w(e);
  const m = new ResizeObserver(() => document.documentElement.style.setProperty("--walkthrough-height", `${o.getBoundingClientRect().height}px`));
  m.observe(o);
  const g = o.querySelector(".wt-chapters");
  for (const i of I) {
    const a = document.createElement("button");
    a.type = "button", a.dataset.chapter = i.id, a.innerHTML = `<span class="wt-step">0${i.id}</span><span class="wt-chapter-title-long">${i.title}</span><span class="wt-chapter-title-short">${i.short}</span>`, a.setAttribute("aria-label", `Chapter ${i.id}: ${i.title}`), g.append(a);
  }
  let s = null, u = null, y = 1, x = 0, b, d = null, Q = "", j = !1, k = null;
  const O = `annora.walkthrough.keyboard.${e}`;
  let L = !1;
  try {
    L = sessionStorage.getItem(O) === "continue";
  } catch {
  }
  const $ = qe(), f = o.querySelector(".wt-handoff");
  f.setAttribute("aria-describedby", "wt-next-action");
  function C(i) {
    const a = { url: String(i), handled: !1 };
    window.dispatchEvent(new CustomEvent("annora:walkthrough-navigate", { detail: a })), a.handled || location.assign(a.url);
  }
  function ne(i) {
    if (i === 1) {
      const h = V(location.href, e);
      return h.searchParams.set("demoChapter", "1"), s ? (h.hash = `explore&project=${encodeURIComponent(s.id)}`, w(e) === "independent" && h.searchParams.set("project", s.id), h.searchParams.set("returnRole", l), h.searchParams.set("returnView", location.hash)) : h.hash = "explore", h;
    }
    if (i === 2 && !s && w(e) === "independent") {
      const h = V(location.href, e);
      return h.hash = "inquiry", h;
    }
    const a = i === 2 ? { role: s && !s.quotes.length ? "seller" : "buyer", state: s ? "quotation" : "inquiry" } : u, p = B(a, s, location.href, e);
    return p.searchParams.set("demoChapter", String(i)), i === 2 && s?.quotes.length && (p.hash = `project&${new URLSearchParams({ project: s.id, tab: "quotation", quote: s.quotes[0].id })}`), p;
  }
  function re(i) {
    const a = Y(i ? "buyer-viewer" : `${l}-workspace`), p = r ? location.hash.startsWith("#project?") : /^#(project|inquiry)/.test(location.hash);
    c ? d = a?.id === "reference-return" ? a : { id: "loading", disabled: !0, note: "Restoring this saved reference…" } : a?.busy && (i || p) || a?.id === "buyer-refresh" && p || p && be(a) || i && !s && a ? d = a : l !== u.role ? d = { id: `handoff-${u.role}-${u.state}`, note: `Next: view this project as ${u.role}.`, run: () => C(B(u, s, location.href, e)) } : i || !p ? d = { id: "return-to-project", note: "Next: return to the current step in this project.", run: () => C(B(u, s, location.href, e)) } : a?.id === "latest-quotation" || u.state === "complete" && a?.id === "completed-conversation" && !location.hash.includes("tab=activity") ? d = a : u.state === "complete" ? d = { id: "complete", label: "Demo complete", disabled: !0, title: "The next step is agreed.", note: "The buyer and seller share the revised quotation and confirmed engineering discussion." } : a ? d = a : d = { id: "loading", disabled: !0, note: "Opening the next action…" };
    const h = j || $.blocked || d.busy;
    f.dataset.step = d.id, f.dataset.confirmation = String(!!d.confirmation), f.disabled = !!(h || d.disabled), f.setAttribute("aria-busy", String(!!h));
    const q = xe({ role: l, chapter: y, action: d, flow: u, locked: h });
    f.querySelector(".wt-action-label").textContent = q.buttonLabel, o.querySelector(".wt-current-chapter").textContent = q.chapterLabel, o.querySelector(".wt-current-step").textContent = q.title, o.querySelector(".wt-role").textContent = q.roleLabel;
    const E = o.querySelector(".wt-next-role");
    E.textContent = q.nextRoleLabel, E.hidden = !q.nextRoleLabel;
    const S = d.note || u.note;
    if (o.querySelector("#wt-next-action").textContent = S, o.querySelector(".wt-menu-note").textContent = S, Q = location.href, !f.disabled && L && !document.querySelector('dialog[open], .ei-panel[role="dialog"]')) {
      L = !1;
      try {
        sessionStorage.removeItem(O);
      } catch {
      }
      f.focus({ preventScroll: !0 });
    }
  }
  async function A() {
    const i = ++x;
    try {
      const [a, p] = await Promise.all([t.listProjects(), t.listDrafts()]);
      if (i !== x) return;
      k === "refresh" && (o.querySelector(".wt-error").hidden = !0, k = null);
      const h = new URLSearchParams(location.hash.replace(/^#project[?&]/, "")), q = h.get("project") || h.get("id") || new URLSearchParams(location.search).get("project");
      if (q && w(e) === "independent" && !a.some((R) => R.id === q)) throw new Error("This saved project is unavailable. Open a valid project reference or start a new sample from Guide.");
      s = a.find((R) => R.id === q) || a[0] || null, u = ge(s, { hasDraft: p.length > 0, viewer: w(e) });
      const E = !r && location.hash.startsWith("#explore"), S = E ? 1 : !s && !r ? 2 : u.chapter;
      y = S;
      for (const R of g.children) {
        const D = Number(R.dataset.chapter);
        R.disabled = D === 3 && !s?.quotes.length, R.toggleAttribute("aria-current", D === S), D === S && R.setAttribute("aria-current", "step");
      }
      re(E);
    } catch (a) {
      if (i !== x) return;
      o.querySelector(".wt-current-step").textContent = "The sample could not be opened.", o.querySelector("#wt-next-action").textContent = a.message, o.querySelector(".wt-menu-note").textContent = a.message;
      const p = o.querySelector(".wt-error");
      p.textContent = a.message, p.hidden = !1, k = "refresh", f.disabled = !0, f.dataset.step = "error";
    }
  }
  const v = o.querySelector(".wt-tools"), N = o.querySelector(".wt-navigation");
  N.addEventListener("click", () => {
    const i = !document.body.hasAttribute("data-wt-navigation");
    document.body.toggleAttribute("data-wt-navigation", i), N.setAttribute("aria-expanded", String(i)), N.textContent = i ? "Hide workspace navigation" : "Show workspace navigation", v.open = !1, i ? document.querySelector(".room-header a, .studio-header a")?.focus({ preventScroll: !0 }) : v.querySelector("summary").focus({ preventScroll: !0 });
  }), o.addEventListener("keydown", (i) => {
    i.key === "Escape" && v.open && (v.open = !1, v.querySelector("summary").focus());
  });
  const G = (i) => {
    v.open && !v.contains(i.target) && (v.open = !1);
  };
  document.addEventListener("pointerdown", G), f.addEventListener("click", async (i) => {
    if (v.open = !1, i.detail > 1 || f.disabled || !d?.run || $.blocked) return;
    if (!ve(d, Q, location.href)) {
      W();
      return;
    }
    const a = d;
    if (i.detail === 0) {
      L = !0;
      try {
        sessionStorage.setItem(O, "continue");
      } catch {
      }
    }
    j = !0, o.querySelector(".wt-error").hidden = !0, k = null, f.disabled = !0, f.setAttribute("aria-busy", "true"), f.querySelector(".wt-action-label").textContent = "Please wait…";
    try {
      await $.run(a.run);
    } catch (p) {
      const h = o.querySelector(".wt-error");
      h.textContent = p.message || "This step could not finish. Try again.", h.hidden = !1, k = "action";
    } finally {
      j = !1, setTimeout(() => {
        A();
      }, 850), A();
    }
  }), f.addEventListener("keydown", (i) => {
    i.repeat && ["Enter", " "].includes(i.key) && i.preventDefault();
  }), g.addEventListener("click", (i) => {
    const a = i.target.closest("button");
    if (!a || a.disabled || !u) return;
    const p = Number(a.dataset.chapter);
    v.open = !1, p === 2 && !s && document.getElementById("room-discuss") && !document.getElementById("room-discuss").hidden ? document.getElementById("room-discuss").click() : C(ne(p));
  }), o.querySelector(".wt-restart").addEventListener("click", () => C(new URL(`walkthrough/?new=1${w(e) === "independent" ? "&viewer=independent" : ""}`, U(location.href))));
  const P = () => {
    clearTimeout(b), b = setTimeout(A, 80);
  };
  function W() {
    ++x, d = null, f.disabled = !0, P();
  }
  for (const i of ["annora:walkthrough-change", "annora:routechange", "popstate", "hashchange"]) window.addEventListener(i, W);
  window.addEventListener("focus", P), window.addEventListener("storage", (i) => {
    (!i.key || i.key === t.storageKey) && P();
  }), document.addEventListener("visibilitychange", () => {
    document.hidden || P();
  });
  const oe = ye(W);
  window.addEventListener("pagehide", (i) => {
    i.persisted || (oe(), m.disconnect(), clearTimeout(b), document.removeEventListener("pointerdown", G));
  }), A();
}
const ee = /* @__PURE__ */ new Set(["inquiry", "quotation", "activity"]), te = /* @__PURE__ */ new Set(["revision", "next", "message"]);
function Se(e = globalThis.location?.hash || "") {
  const [t, ...r] = String(e || "").replace(/^#/, "").split("&"), n = new URLSearchParams(r.join("&")), c = n.get("part") ? { kind: "part", nodeId: n.get("part") } : n.get("chapter") && n.get("tour") ? { kind: "chapter", chapterId: n.get("chapter"), tourId: n.get("tour") } : void 0;
  return {
    view: t || "explore",
    projectId: n.get("project") || void 0,
    ...c ? { target: c } : {},
    ...ee.has(n.get("tab")) ? { tab: n.get("tab") } : {},
    ...n.get("quote") ? { quoteId: n.get("quote") } : {},
    ...n.get("message") ? { messageId: n.get("message") } : {},
    ...te.has(n.get("mode")) ? { mode: n.get("mode") } : {},
    ...n.get("stage") === "review" ? { stage: "review" } : {},
    ...n.get("compare") === "all" ? { compare: "all" } : {}
  };
}
function ke(e) {
  const t = new URLSearchParams();
  return ["project", "explore"].includes(e.view) && e.projectId && t.set("project", e.projectId), e.view === "explore" && e.target && (e.target.kind === "part" ? t.set("part", e.target.nodeId) : (t.set("chapter", e.target.chapterId), t.set("tour", e.target.tourId))), e.view === "project" && (ee.has(e.tab) && t.set("tab", e.tab), e.quoteId && t.set("quote", e.quoteId), e.mode === "message" && e.messageId && t.set("message", e.messageId), te.has(e.mode) && t.set("mode", e.mode), e.compare === "all" && t.set("compare", "all")), ["project", "inquiry"].includes(e.view) && e.stage === "review" && t.set("stage", "review"), `#${e.view || "explore"}${t.size ? `&${t}` : ""}`;
}
const Ee = ["project", "requestItem", "referenceQuote", "referenceEntry", "referenceReview"], F = (e) => {
  throw Object.assign(new Error(e), { code: "EXTERNAL_REFERENCE_UNAVAILABLE" });
}, T = () => F("This exact viewer reference is unavailable. Return to the saved project and open its reference again.");
function Le(e) {
  const t = le(e), r = t.viewerReference?.adapter;
  return (!r || r.id !== "annora-example-three-viewer" || r.version !== "1" || r.coordinateFrame !== "source-meters-y-up-v1" || t.productId !== "kinetic-01" || t.modelId !== "kinetic-01") && F("The viewer that captured this reference is not installed in this demonstration. The saved record has not changed."), t;
}
function Ce(e) {
  w(e) !== "independent" && F("Open this viewer reference in its original independent-viewer demonstration. Existing projects have not changed.");
}
const Ae = (e) => [...e?.scopeSelection?.entries || [], ...e?.questionScope?.entries || [], ...e?.impactScope?.entries || []];
function $e(e, t) {
  if (!e?.id || Ee.some((n) => t.getAll(n).length > 1 || t.has(n) && !t.get(n)) || t.get("project") !== e.id || t.has("referenceReview") || t.has("requestItem") && t.has("referenceQuote") || t.has("referenceEntry") && !t.has("referenceQuote")) return T();
  let r;
  if (t.has("referenceQuote")) {
    const n = e.quotes?.find((c) => c.id === t.get("referenceQuote"));
    if (!n) return T();
    r = t.has("referenceEntry") ? Ae(n).find((c) => c.id === t.get("referenceEntry"))?.context : ce(e, n);
  } else t.has("requestItem") ? r = e.inquiry?.requestItems?.find((n) => n.id === t.get("requestItem"))?.context : r = e.inquiry?.context || e.context;
  return r?.viewerReference ? Le(r) : T();
}
function Ne({ base: e, sessionId: t, projectId: r, role: n = "buyer", returnView: c = "" } = {}) {
  if (Ce(t), typeof r != "string" || !r || r.length > 320 || /[\u0000-\u001f]/.test(r)) return T();
  const l = n === "seller", o = new URL(l ? "studio/" : "product-room/", U(e));
  if (o.searchParams.set("walkthrough", t), o.searchParams.set(l ? "product" : "model", "kinetic-01"), l) {
    const [m, g = ""] = String(c).replace(/^#/, "").split("?"), s = new URLSearchParams(g), u = new URLSearchParams({ id: r });
    if (m === "project" && s.getAll("id").length === 1 && s.get("id") === r) {
      const y = s.get("tab"), x = s.get("mode");
      ["inquiry", "quotation", "conversation"].includes(y) && u.set("tab", y), ["detail", "edit", "quote-review", "reply", "reply-review", "ack", "ack-review"].includes(x) && u.set("mode", x);
      for (const b of ["quote", "draft"]) s.getAll(b).length === 1 && s.get(b) && u.set(b, s.get(b));
    }
    o.hash = `project?${u}`;
  } else {
    const m = Se(c);
    o.hash = ke(m.view === "project" && m.projectId === r ? m : { view: "project", projectId: r });
  }
  return o;
}
export {
  me as createWalkthroughRepository,
  Ne as externalViewerReturnURL,
  Ie as hasWalkthroughRequest,
  je as inquiryWalkthroughAction,
  Oe as mountWalkthrough,
  $e as readExternalViewerReference,
  Te as readWalkthroughSession,
  Ue as registerWalkthroughAction,
  B as walkthroughDestination,
  ge as walkthroughFlow,
  U as walkthroughRootURL,
  w as walkthroughViewer,
  V as walkthroughViewerURL
};
