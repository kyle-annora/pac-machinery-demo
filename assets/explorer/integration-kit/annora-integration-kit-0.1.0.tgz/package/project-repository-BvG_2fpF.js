const re = (e) => typeof e == "string" ? e.trim() : "", S = (e, i = {}) => {
  throw new h("VALIDATION", e, i);
}, Xt = (e) => typeof e == "string" && Number.isFinite(Date.parse(e)), ht = (e) => Number.isSafeInteger(e) && e > 0, Zt = ["buyer", "seller"], ji = ["opened", "answer", "clarification", "buyer-reply", "resolved", "reopened"], ei = (e) => {
  (!e?.id || !ht(e.revision)) && S("Open a saved customer project first.");
}, ti = (e) => {
  const i = re(e);
  return (!i || i.length > 4e3) && S("Write a question, reply or explanation of 1–4,000 characters.", { body: "Enter a concise explanation before reviewing." }), i;
};
function vt(e) {
  const i = e?.events?.at(-1)?.kind, t = { opened: "open", answer: "answered", clarification: "waiting-on-buyer", "buyer-reply": "waiting-on-seller", resolved: "resolved", reopened: "open" }[i] || "open";
  return { status: t, ownerRole: t === "resolved" ? null : t === "waiting-on-buyer" ? "buyer" : "seller" };
}
const Li = (e) => (e?.questions || []).filter((i) => i.blocking && vt(i).status !== "resolved");
function ii(e) {
  if (Li(e).length) throw new h("CONFLICT", "Resolve the scope-affecting questions through explicit review before confirming a next step.");
}
function wt(e, i) {
  ei(e), i?.authorRole !== void 0 && i.authorRole !== "buyer" && S("Only the buyer can open a new question."), (e.questions || []).length >= 24 && S("Keep this demonstration within 24 independent questions.");
  const t = e.inquiry?.requestItems?.find((o) => o.id === i?.requestItemId);
  return t || S("Choose an original requested detail in this project.", { requestItemId: "Choose the saved component or view this question concerns." }), typeof i.blocking != "boolean" && S("State whether this question affects quotation scope.", { blocking: "Choose whether this question blocks a quotation." }), Y({
    kind: "question-add",
    projectId: e.id,
    projectRevision: e.revision,
    requestItemId: t.id,
    requestItem: I(t),
    context: I(t.context),
    body: ti(i.body),
    blocking: i.blocking,
    scopeEntryId: `request:${t.id}`,
    authorRole: "buyer"
  });
}
function mt(e, i, t, o) {
  ei(e);
  const n = e.questions?.find((d) => d.id === i?.questionId);
  n || S("Choose a saved question in this project.", { questionId: "Reopen the question before continuing." }), n.events.length >= 60 && S("This demonstration keeps up to 60 events per question.");
  const r = i.authorRole;
  Zt.includes(r) || S("Choose the buyer or seller role for this action.");
  const s = vt(n).status;
  if (t === "question-reply") {
    if (s === "resolved") throw new h("CONFLICT", "Reopen this resolved question before adding another reply.");
    (r === "seller" ? !["answer", "clarification"].includes(o) : o !== "buyer-reply" || s !== "waiting-on-buyer") && S("The reply must match this question’s current owner and action.");
  } else if (t === "question-resolution") {
    if (s !== "answered") throw new h("CONFLICT", "Answer this question before reviewing its resolution. An answer alone does not resolve it.");
  } else if (s !== "resolved") throw new h("CONFLICT", "Only a resolved question can be reopened.");
  return Y({
    kind: t,
    projectId: e.id,
    projectRevision: e.revision,
    questionId: n.id,
    questionRevision: n.events.length,
    requestItemId: n.requestItemId,
    context: I(n.context),
    scopeEntryId: n.scopeEntryId,
    action: o,
    authorRole: r,
    body: ti(i.body)
  });
}
const gt = (e, i) => mt(e, i, "question-reply", i?.kind || i?.action), It = (e, i) => mt(e, i, "question-resolution", "resolved"), yt = (e, i) => mt(e, i, "question-reopen", "reopened");
function ni(e, i) {
  return (e.questions || []).filter((t) => t.events[0].projectRevision <= i).map((t) => ({
    ...I(t),
    events: I(t.events.filter((o) => o.projectRevision <= i))
  }));
}
function Vi(e) {
  return e.questionPolicy ? { version: 1, projectRevision: e.revision, questions: I(e.questions) } : void 0;
}
function oi(e) {
  (!e || e.version !== 1 || !ht(e.projectRevision) || !Array.isArray(e.questions) || e.questions.length > 24) && S("Keep the quotation’s question evidence attached to its reviewed project revision.");
  for (const i of e.questions)
    (!re(i.id) || !re(i.projectId) || !re(i.requestItemId) || !re(i.body) || i.body.length > 4e3 || typeof i.blocking != "boolean" || i.scopeEntryId !== `request:${i.requestItemId}` || !Xt(i.createdAt) || !i.requestItem || !Array.isArray(i.events) || !i.events.length || i.events.length > 60 || !y(W(i.context), i.context)) && S("A question snapshot lost its original context or history.");
  return new Set(e.questions.map((i) => i.id)).size !== e.questions.length && S("Each quotation question needs a distinct identity."), { version: 1, projectRevision: e.projectRevision, questions: I(e.questions) };
}
function Ve(e, i, { current: t = !0, requireResolved: o = !0 } = {}) {
  if (!e.questionPolicy && !i.questionScope) return {};
  if (!e.questionPolicy || !i.questionScope) return { questionScope: "Review and explicitly adopt the question evidence before saving or issuing this quotation." };
  let n;
  try {
    n = oi(i.questionScope);
  } catch (s) {
    return { questionScope: s.message };
  }
  if (n.projectRevision > e.revision || !y(n.questions, ni(e, n.projectRevision)))
    return { questionScope: "The quotation question evidence does not match the exact saved history." };
  if (t && !y(n.questions, e.questions)) return { questionScope: "Review and explicitly adopt the latest question evidence before issuing this quotation." };
  const r = {};
  for (const s of n.questions)
    e.approvedOptionSet && !i.scopeSelection?.entries?.some((d) => d.id === s.scopeEntryId && d.requestItemId === s.requestItemId && y(d.context, s.context)) ? r[`questionScope.${s.id}`] = "Keep this question linked to the matching original request scope entry." : o && s.blocking && vt(s).status !== "resolved" && (r[`questionScope.${s.id}`] = "This scope-affecting question needs an explicit reviewed resolution before issue.");
  return r;
}
function $i(e, i) {
  const t = Ve(e, i, { requireResolved: !1 });
  if (Object.keys(t).length) throw new h("QUESTION_REVIEW_REQUIRED", Object.values(t)[0], t);
}
function Ui(e, i = []) {
  if (!e.questionPolicy) {
    (Object.hasOwn(e, "questions") || Object.hasOwn(e, "questionEventIndex") || e.quotes.some((a) => a.questionScope) || i.some((a) => a.questionScope)) && S("Question history has no opt-in policy.");
    return;
  }
  (!y(e.questionPolicy, { version: 1 }) || !Array.isArray(e.questions) || !e.questions.length || e.questions.length > 24) && S("The saved question policy or history is invalid.");
  const t = { ...e, questions: [] }, o = [], n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Set();
  for (const a of e.questions) {
    n.has(a.id) && S("Question identities must be unique."), n.add(a.id), (!Array.isArray(a.events) || !a.events.length || a.events.length > 60) && S("Question history is incomplete.");
    let c = 0;
    for (const [u, g] of a.events.entries())
      (!re(g.id) || r.has(g.id) || d.has(g.reviewToken) || g.questionId !== a.id || g.version !== u + 1 || !ht(g.projectRevision) || g.projectRevision <= 1 || g.projectRevision > e.revision || g.projectRevision <= c || s.has(g.projectRevision) || !Xt(g.createdAt) || !Zt.includes(g.authorRole) || !ji.includes(g.kind)) && S("Question events have invalid identity, order or provenance."), c = g.projectRevision, r.add(g.id), s.add(g.projectRevision), d.add(g.reviewToken), o.push({ question: a, event: g });
  }
  o.sort((a, c) => a.event.projectRevision - c.event.projectRevision), y(e.questionEventIndex, o.map(({ event: a }) => ({ id: a.id, questionId: a.questionId, projectRevision: a.projectRevision }))) || S("The question history index identifies missing or changed events.");
  for (const { question: a, event: c } of o) {
    t.revision = c.projectRevision - 1;
    const u = c.kind === "opened" ? "question-add" : c.kind === "resolved" ? "question-resolution" : c.kind === "reopened" ? "question-reopen" : "question-reply", g = P({ ...JSON.parse(c.reviewToken), token: c.reviewToken }, u), A = { "question-add": wt, "question-reply": gt, "question-resolution": It, "question-reopen": yt }[u], R = A(t, { ...g, kind: g.action });
    (!y(R, { ...g, token: c.reviewToken }) || g.projectRevision + 1 !== c.projectRevision || g.authorRole !== c.authorRole || g.body !== c.body || (g.action || "opened") !== c.kind) && S("A question event changed after review.");
    const v = {
      id: c.id,
      questionId: a.id,
      version: c.version,
      kind: c.kind,
      authorRole: g.authorRole,
      body: g.body,
      projectRevision: c.projectRevision,
      createdAt: c.createdAt,
      reviewToken: c.reviewToken
    };
    if (y(v, c) || S("A question event has unexpected or missing fields."), c.kind === "opened") {
      const f = {
        id: a.id,
        projectId: e.id,
        requestItemId: g.requestItemId,
        requestItem: I(g.requestItem),
        context: I(g.context),
        body: g.body,
        blocking: g.blocking,
        scopeEntryId: g.scopeEntryId,
        createdAt: c.createdAt,
        events: [I(c)]
      };
      (!re(a.id) || a.projectId !== e.id || !y({ ...a, events: [c] }, f)) && S("A question’s immutable source or opening text changed."), t.questions.push(f);
    } else t.questions.find((f) => f.id === a.id).events.push(I(c));
  }
  y(t.questions, e.questions) || S("Question order or history changed.");
  const l = o[0].event.projectRevision;
  for (const a of e.quotes) {
    if (!a.questionScope) {
      a.source === "seller-demo" && a.issuedProjectRevision > l && S("An issued quotation lost its question evidence.");
      continue;
    }
    (a.source !== "seller-demo" || a.questionScope.projectRevision >= a.issuedProjectRevision || !y(a.questionScope.questions, ni(e, a.issuedProjectRevision - 1)) || Object.keys(Ve(e, a, { current: !1 })).length) && S("An issued quotation changed its question evidence or contains unresolved blockers.");
    const c = P({ ...JSON.parse(a.reviewToken), token: a.reviewToken }, "issue-quote");
    y(c.draft.questionScope, a.questionScope) || S("Issued question evidence differs from the reviewed quotation.");
  }
  for (const a of i)
    a.questionScope ? Object.keys(Ve(e, a, { current: !1, requireResolved: !1 })).length && S("A saved quotation draft changed its question evidence.") : a.projectRevision >= l && S("A saved quotation draft lost its question evidence.");
}
function $e(e) {
  return ["quantity", "timing", ...e.values.notes ? ["notes"] : []];
}
function _i(e, i) {
  if (e.replies?.some((n) => n.changeId === i)) return !0;
  const t = e.changes.find((n) => n.id === i);
  if (!t) return !1;
  const o = /* @__PURE__ */ new Map();
  for (const n of e.messages || [])
    if (!(n.authorRole !== "seller" || n.kind !== "change-response" || n.changeId !== i))
      for (const r of n.resolutions || []) o.set(r.topic, r);
  return $e(t).every((n) => o.has(n) && o.get(n).status !== "needs-info");
}
function ke(e) {
  return e.changes.filter((i) => !_i(e, i.id)).at(-1) || null;
}
function ne(e) {
  return (e.messages || []).filter((i) => (i.kind === "clarification" || i.kind === "change-response" && i.resolutions?.some((t) => t.status === "needs-info")) && !(e.messages || []).some((t) => t.replyTo === i.id && t.authorRole === "buyer")).at(-1) || null;
}
function Ze(e) {
  return Array.isArray(e) ? `[${e.map(Ze).join(",")}]` : e && typeof e == "object" ? `{${Object.keys(e).sort().map((i) => `${JSON.stringify(i)}:${Ze(e[i])}`).join(",")}}` : JSON.stringify(e);
}
function qt(e) {
  const i = Ze(e);
  let t = 2166136261, o = 2246822519;
  for (let n = 0; n < i.length; n++)
    t = Math.imul(t ^ i.charCodeAt(n), 16777619), o = Math.imul(o ^ i.charCodeAt(n), 3266489917);
  return `${(t >>> 0).toString(16).padStart(8, "0")}${(o >>> 0).toString(16).padStart(8, "0")}`;
}
const Z = (e) => typeof e == "string" && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$/.test(e), Pe = (e) => new Set(e).size === e.length, kt = (e, i, t) => ({ code: e, path: i, message: t, severity: "error" });
function Fi(e) {
  return `source-${qt({
    id: e.id,
    revision: e.revision,
    modelId: e.modelId,
    modelRevision: e.modelRevision,
    assets: e.assets.map(({ id: i, kind: t, sha256: o }) => ({ id: i, kind: t, sha256: o })).sort((i, t) => i.id.localeCompare(t.id)),
    sheets: e.sheets.map(({ id: i, assetId: t, pdfPage: o, rotation: n, viewBox: r }) => ({ id: i, assetId: t, pdfPage: o || 1, rotation: n || 0, viewBox: r }))
  })}`;
}
function Wi(e, i, t) {
  const o = e.sheets.find((n) => n.id === i)?.regions.find((n) => n.id === t);
  return o ? `link-${qt({
    sheetId: i,
    regionId: t,
    partId: o.partId,
    bounds: o.bounds,
    camera: o.camera || null,
    focusPoint: o.focusPoint || null
  })}` : null;
}
function Qi(e) {
  if (!e || e.schemaVersion !== 1 || !Z(e.sourceKey) || !Array.isArray(e.sheets) || e.sheets.length > 32)
    throw new TypeError("The overview configuration is invalid.");
  if (!Pe(e.sheets.map((t) => t.sheetId))) throw new TypeError("Overview sheets must have unique identifiers.");
  const i = e.sheets.map((t) => {
    if (!Z(t.sheetId) || !Array.isArray(t.views) || t.views.length > 8 || !Pe(t.views.map((n) => n.id)))
      throw new TypeError("Choose up to eight unique views per sheet.");
    const o = t.views.map((n) => {
      if (!Z(n.id) || !Z(n.viewRevision) || typeof n.title != "string" || n.title.length > 120 || !Array.isArray(n.targets) || n.targets.length > 32 || !Pe(n.targets.map((s) => s.targetId)) || !Pe(n.targets.map((s) => s.regionId)))
        throw new TypeError("Each overview view needs a valid asset version, title and unique feature links.");
      const r = n.targets.map((s) => {
        if (!Z(s.targetId) || !Z(s.regionId) || !Z(s.associationKey) || typeof s.confirmed != "boolean")
          throw new TypeError("Each overview feature needs an exact drawing association.");
        return { targetId: s.targetId, regionId: s.regionId, associationKey: s.associationKey, confirmed: s.confirmed };
      });
      return { id: n.id, viewRevision: n.viewRevision, title: n.title, targets: r };
    });
    if (t.defaultViewId !== null && (!Z(t.defaultViewId) || !o.some((n) => n.id === t.defaultViewId)))
      throw new TypeError("Choose a visible view as the initial overview view.");
    return { sheetId: t.sheetId, defaultViewId: t.defaultViewId, views: o };
  });
  return { schemaVersion: 1, sourceKey: e.sourceKey, sheets: i };
}
function Rt(e) {
  if (e == null) return null;
  const i = Qi(e), t = `overview-${qt(i)}`;
  if (e.revision !== t) throw new TypeError("This overview version no longer matches its saved content.");
  return { ...i, revision: t };
}
function zi(e, i, t, { requireConfirmed: o = !0 } = {}) {
  if (e == null) return [];
  let n;
  try {
    n = Rt(e);
  } catch (d) {
    return [kt("INVALID_OVERVIEW", "presentationSnapshot", d.message)];
  }
  const r = [], s = (d, l, a) => r.push(kt(d, `presentationSnapshot.${l}`, a));
  n.sourceKey !== Fi(i) && s("OVERVIEW_SOURCE_CHANGED", "sourceKey", "This overview belongs to another drawing source. Prepare views for the selected source before publishing."), n.sheets.some((d) => d.views.length) || s("EMPTY_OVERVIEW", "sheets", "Choose at least one overview view, or use the source PDF without an overview.");
  for (const d of n.sheets) {
    const l = i.sheets.find((c) => c.id === d.sheetId), a = `sheets.${d.sheetId}`;
    if (!l) {
      s("OVERVIEW_SHEET_MISSING", a, "This overview sheet is not in the selected drawing.");
      continue;
    }
    d.views.length && !d.defaultViewId && s("OVERVIEW_DEFAULT_MISSING", a, "Choose an initial view for this sheet.");
    for (const c of d.views) {
      c.title.trim() || s("OVERVIEW_TITLE_MISSING", `${a}.${c.id}`, "Give this view a customer-readable title.");
      for (const u of c.targets) {
        const g = l.regions.find((R) => R.id === u.regionId), A = `${a}.${c.id}.${u.targetId}`;
        (!g || g.mappingStatus !== "confirmed" || u.associationKey !== Wi(i, d.sheetId, u.regionId)) && s("OVERVIEW_ASSOCIATION_CHANGED", A, "Review the original drawing association, then confirm this feature link again."), o && !u.confirmed && s("OVERVIEW_LINK_UNCONFIRMED", A, "Confirm this feature link before publishing.");
      }
    }
  }
  return r;
}
function si(e, i) {
  if (!e || typeof e != "object" || Array.isArray(e)) throw new TypeError("A drawing reference needs its saved identity.");
  if (!i.modelId || !i.modelRevision || !i.part) throw new TypeError("A drawing reference needs a part and exact model revision.");
  const t = {};
  for (const n of ["id", "title", "revision", "assetId", "assetRevision", "partId", "sheetId", "sheetTitle", "regionId", "regionLabel", "sourceURL"]) {
    const r = typeof e[n] == "string" ? e[n].trim() : "", s = n === "sourceURL" ? 2048 : 320;
    if (!r || r.length > s || /[\u0000-\u001f]/.test(r)) throw new TypeError(`A drawing reference needs a valid ${n}.`);
    t[n] = r;
  }
  if (t.partId !== i.part.id) throw new TypeError("The drawing detail must reference the selected part.");
  let o;
  try {
    o = new URL(t.sourceURL);
  } catch {
    throw new TypeError("A drawing source needs an HTTP or HTTPS address.");
  }
  if (!["http:", "https:"].includes(o.protocol) || o.username || o.password) throw new TypeError("A drawing source needs an HTTP or HTTPS address.");
  for (const n of ["mappingRevision", "revisionLabel"]) if (e[n] !== void 0) {
    const r = typeof e[n] == "string" ? e[n].trim() : "";
    if (!r || r.length > (n === "revisionLabel" ? 160 : 320) || /[\u0000-\u001f]/.test(r)) throw new TypeError(`A drawing reference needs a valid ${n}.`);
    t[n] = r;
  }
  if (e.presentationSnapshot !== void 0) {
    const n = Rt(e.presentationSnapshot);
    if (n && e.presentationRevision !== n.revision || !n && e.presentationRevision !== void 0)
      throw new TypeError("The saved overview does not match its presentation version.");
    t.presentationSnapshot = n, n && (t.presentationRevision = n.revision);
  } else if (e.presentationRevision !== void 0)
    throw new TypeError("A saved overview version needs its exact presentation snapshot.");
  return t;
}
const Ue = (e) => e.drawing ? [
  e.drawing.id,
  e.drawing.revision,
  e.drawing.assetId,
  e.drawing.assetRevision,
  ...e.drawing.mappingRevision ? [e.drawing.mappingRevision] : []
] : null, G = (e) => e.activeDrawingContext || e.context, L = (e, i) => i?.context || e.context, de = (e) => JSON.stringify([
  e.modelId,
  e.modelRevision,
  ...Ue(e) || [],
  e.drawing?.sheetId,
  e.drawing?.regionId,
  e.drawing?.partId
]), Ge = Object.freeze({ appearance: "light", grid: !1, ambientOcclusion: !0, featureEdges: !0, hiddenEdges: !1, lineWeight: "standard" }), Mi = Object.freeze(["light", "dark"]), Ki = Object.freeze({ fine: 0.8, standard: 1, bold: 1.25 });
function Ji(e = {}, i = Ge) {
  if (!e || typeof e != "object" || Array.isArray(e)) throw new TypeError("Display options must be an object.");
  for (const [t, o] of Object.entries(e)) {
    if (!Object.hasOwn(Ge, t)) throw new TypeError(`Unknown display option: ${t}`);
    if (!(t === "appearance" ? Mi.includes(o) : t === "lineWeight" ? Object.hasOwn(Ki, o) : typeof o == "boolean")) throw new TypeError(`Invalid display option: ${t}`);
  }
  return { ...Ge, ...i, ...e };
}
const Gi = "1", Hi = 131072, ri = 12e4, ai = (e) => e !== null && typeof e == "object" && !Array.isArray(e) && [Object.prototype, null].includes(Object.getPrototypeOf(e)), te = (e) => typeof e == "number" && Number.isFinite(e), X = (e, i = 256) => typeof e == "string" && e.length > 0 && e.length <= i, xt = (e) => te(e) && e >= 0 && e <= 1, di = (e, i = "INVALID_ARGUMENT") => {
  throw Object.assign(new TypeError(e), { code: i });
}, C = (e, i, t) => {
  e || di(i, t);
}, M = (e, i) => C(ai(e) && Object.keys(e).every((t) => i.includes(t)), "Unexpected inspection fields.");
function ci(e, i = 0) {
  if (i > 12) return !1;
  if (e === null || typeof e == "boolean") return !0;
  if (typeof e == "string") return e.length <= ri;
  if (typeof e == "number") return te(e);
  if (!Array.isArray(e) && !ai(e) || Array.isArray(e) && e.length > 64) return !1;
  const t = Object.getOwnPropertyDescriptors(e);
  return Reflect.ownKeys(t).length > 65 ? !1 : Reflect.ownKeys(t).every((o) => typeof o == "string" && !["__proto__", "prototype", "constructor"].includes(o) && "value" in t[o] && ci(t[o].value, i + 1));
}
function Yi(e) {
  M(e, ["position", "target", "up", "projection", "viewport", "layoutKey"]);
  for (const s of ["position", "target", "up"]) C(Array.isArray(e[s]) && e[s].length === 3 && e[s].every((d) => te(d) && Math.abs(d) <= 1e6), "Invalid inspection camera vectors.");
  const i = e.position.map((s, d) => s - e.target[d]), t = e.up, o = [i[1] * t[2] - i[2] * t[1], i[2] * t[0] - i[0] * t[2], i[0] * t[1] - i[1] * t[0]];
  C(Math.hypot(...i) >= 0.01 && Math.hypot(...t) >= 1e-6 && Math.hypot(...o) / Math.hypot(...i) / Math.hypot(...t) > 1e-6, "The inspection camera needs a stable viewing plane.");
  const n = e.projection, r = e.viewport;
  return M(n, ["kind", "verticalFovDegrees", "zoom", "offsetX", "offsetY"]), C(n.kind === "perspective" && te(n.verticalFovDegrees) && n.verticalFovDegrees >= 1 && n.verticalFovDegrees <= 170 && te(n.zoom) && n.zoom >= 1e-3 && n.zoom <= 1e3 && [n.offsetX, n.offsetY].every((s) => te(s) && Math.abs(s) <= 1e6), "Invalid inspection projection."), M(r, ["width", "height"]), C([r.width, r.height].every((s) => te(s) && s > 0 && s <= 1e6), "Invalid inspection viewport."), C(e.layoutKey === void 0 || X(e.layoutKey, 1024), "Invalid inspection layout."), JSON.parse(JSON.stringify(e));
}
function Ot(e) {
  C(X(e.selectedId) && X(e.scopeId), "An inspection needs a selected part and scope."), C(typeof e.isolated == "boolean" && ["explore", "explode", "operate"].includes(e.mode) && ["engineering", "linework", "flat"].includes(e.renderStyle) && xt(e.separation), "Invalid inspection presentation."), C(e.mode !== "explore" || e.separation === 0, "An Explore inspection must be assembled."), e.mode === "operate" ? (M(e.operation, ["clipId", "progress", "status"]), C(e.separation === 0 && X(e.operation.clipId) && xt(e.operation.progress) && e.operation.status === "paused", "Invalid paused operation.")) : C(e.operation === null, "Only an operating inspection may contain source playback."), M(e.displayOptions, ["appearance", "grid", "ambientOcclusion", "featureEdges", "hiddenEdges", "lineWeight"]);
  try {
    e.displayOptions = Ji(e.displayOptions);
  } catch (i) {
    di(i.message);
  }
  e.camera = Yi(e.camera);
}
function bt(e, { model: i } = {}) {
  C(ci(e) && JSON.stringify(e).length <= Hi, "Inspection must be bounded plain JSON.");
  const t = JSON.parse(JSON.stringify(e));
  M(t, ["version", "model", "view", "tour", "preview"]), C(t.version === Gi, "Unsupported inspection version.", "INCOMPATIBLE_VIEW"), M(t.model, ["id", "revision"]), C(X(t.model.id) && X(t.model.revision), "An inspection needs a model revision."), i && C(t.model.id === i.id && t.model.revision === i.revision, "This inspection belongs to another model revision.", "INCOMPATIBLE_VIEW"), C(!!t.view != !!t.tour, "An inspection needs exactly one view or paused tour.");
  const o = ["selectedId", "scopeId", "isolated", "mode", "renderStyle", "displayOptions", "separation", "operation", "camera"];
  return t.view ? (M(t.view, ["viewVersion", "model", "coordinateFrame", ...o]), C(t.view.viewVersion === "0.1" && t.view.coordinateFrame === "normalized-assembly-v1" && t.view.model?.id === t.model.id && t.view.model?.revision === t.model.revision, "The inspection view has an incompatible model or coordinate convention.", "INCOMPATIBLE_VIEW"), M(t.view.model, ["id", "revision"]), Ot(t.view)) : (M(t.tour, ["tourId", "chapterId", "time", "sourceOwned", "highlightIds", ...o]), C(X(t.tour.tourId) && X(t.tour.chapterId) && te(t.tour.time) && t.tour.time >= 0 && t.tour.time <= 86400, "Invalid paused tour position."), C(typeof t.tour.sourceOwned == "boolean" && Array.isArray(t.tour.highlightIds) && t.tour.highlightIds.length <= 64 && t.tour.highlightIds.every((n) => X(n)), "Invalid tour emphasis."), Ot(t.tour)), t.preview !== void 0 && (M(t.preview, ["dataUrl", "width", "height"]), C(typeof t.preview.dataUrl == "string" && t.preview.dataUrl.length <= ri && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(t.preview.dataUrl), "Invalid inspection preview image."), C([t.preview.width, t.preview.height].every((n) => Number.isInteger(n) && n > 0 && n <= 640), "Invalid inspection preview size.")), t;
}
const Bi = bt, Nt = "1", le = Object.freeze({ bytes: 65536, depth: 10, nodes: 4096, array: 256, keys: 128, string: 8192 });
class et extends Error {
  constructor(i, t) {
    super(t), this.name = "IntegrationError", this.code = i;
  }
}
const U = (e) => {
  throw new et("INVALID_REFERENCE", e);
};
function me(e, i, t = 256) {
  return (typeof e != "string" || !e.trim() || e !== e.trim() || e.length > t) && U(`${i} needs a non-empty, bounded identifier.`), e;
}
function Xi(e) {
  let i = 0;
  const t = /* @__PURE__ */ new Set();
  function o(r, s) {
    if ((++i > le.nodes || s > le.depth) && U("The saved view exceeds its JSON limits."), r === null || typeof r == "boolean") return r;
    if (typeof r == "string")
      return r.length > le.string && U("A saved-view value is too long."), r;
    if (typeof r == "number")
      return Number.isFinite(r) || U("A saved-view number must be finite."), r;
    (!r || typeof r != "object" || t.has(r)) && U("The saved view must be acyclic plain JSON.");
    const d = Array.isArray(r), l = Object.getPrototypeOf(r);
    (d ? l !== Array.prototype : l !== Object.prototype && l !== null) && U("The saved view must contain only plain objects and arrays.");
    const a = Reflect.ownKeys(r);
    a.some((u) => typeof u != "string" || ["__proto__", "prototype", "constructor"].includes(u)) && U("The saved view contains an unsupported JSON key."), (d ? r.length > le.array || a.length !== r.length + 1 : a.length > le.keys) && U("The saved view exceeds its collection limits."), t.add(r);
    const c = d ? [] : {};
    for (const u of a) {
      if (d && u === "length") continue;
      d && (!/^(0|[1-9]\d*)$/.test(u) || +u >= r.length) && U("Saved-view arrays cannot contain additional properties."), u.length > 256 && U("A saved-view key is too long.");
      const g = Object.getOwnPropertyDescriptor(r, u);
      (!g.enumerable || !Object.hasOwn(g, "value")) && U("Saved views cannot contain accessors or hidden properties."), c[u] = o(g.value, s + 1);
    }
    return t.delete(r), c;
  }
  const n = o(e, 0);
  return new TextEncoder().encode(JSON.stringify(n)).byteLength > le.bytes && U("The saved view exceeds 64 KiB."), n;
}
function tt(e, i, t) {
  (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).some((o) => !i.includes(o))) && U(`${t} contains unsupported fields.`);
}
const Dt = (e, i) => (tt(e, ["id", "revision"], i), { id: me(e.id, `${i} identity`), revision: me(e.revision, `${i} revision`) });
function Zi(e, i) {
  const t = Xi(e);
  if (t?.version !== Nt) throw new et("UNSUPPORTED_REFERENCE_VERSION", "This saved view uses an unsupported reference version. Keep the original record and use a compatible integration.");
  tt(t, ["version", "adapter", "product", "model", "snapshot"], "The saved view"), tt(t.adapter, ["id", "version", "coordinateFrame"], "The viewer adapter");
  const o = { id: me(t.adapter.id, "Adapter identity"), version: me(t.adapter.version, "Adapter version"), coordinateFrame: me(t.adapter.coordinateFrame, "Coordinate frame") }, n = Dt(t.product, "Product"), r = Dt(t.model, "Model");
  if ((!t.snapshot || typeof t.snapshot != "object" || Array.isArray(t.snapshot)) && U("The saved view needs an object snapshot."), i && (n.id !== i.productId || n.revision !== i.productRevision || r.id !== i.modelId || r.revision !== i.modelRevision))
    throw new et("IDENTITY_MISMATCH", "This saved view belongs to another product or model version. Keep its original reference.");
  return { version: Nt, adapter: o, product: n, model: r, snapshot: t.snapshot };
}
const Q = (e) => typeof e == "string" ? e.trim() : "";
function en(e) {
  if (!Q(e?.productId) || !Q(e?.productTitle)) throw new TypeError("A request needs a product identity.");
  const i = {
    productId: Q(e.productId),
    productTitle: Q(e.productTitle),
    modelId: Q(e.modelId),
    modelRevision: Q(e.modelRevision)
  };
  Object.hasOwn(e, "productRevision") && (i.productRevision = me(e.productRevision, "Product revision"));
  for (const t of ["part", "document", "chapter"]) {
    const o = e[t];
    if (o) {
      if (!Q(o.id) || !Q(o.title)) throw new TypeError(`Invalid ${t} context.`);
      if (t !== "document" && (!i.modelId || !i.modelRevision)) throw new TypeError("Part and chapter context need an exact model revision.");
      if (i[t] = { id: Q(o.id), title: Q(o.title) }, t === "chapter") {
        if (!Q(o.tourId)) throw new TypeError("A chapter needs its tour identity.");
        i[t].tourId = Q(o.tourId);
      }
    }
  }
  if (e.drawing !== void 0 && (i.drawing = si(e.drawing, i)), e.inspection !== void 0 && (i.inspection = Bi(e.inspection, { model: { id: i.modelId, revision: i.modelRevision } })), Object.hasOwn(e, "viewerReference")) {
    if (e.inspection !== void 0) throw new TypeError("Keep external viewer references separate from Annora inspection state.");
    i.viewerReference = Zi(e.viewerReference, i);
  }
  return i;
}
const it = "inquiry-intent-v1", li = Object.freeze([
  Object.freeze({ value: "quotation", label: "Request a quotation" }),
  Object.freeze({ value: "application-review", label: "Application review and consultation" })
]), ui = (e) => e?.intent !== "application-review", ze = (e) => typeof e == "string" && /^\d+$/.test(e) && +e >= 1 && +e <= 1e5, io = (e) => li.find((i) => i.value === e?.intent)?.label || "Not specified", pi = [
  ["application", "Application", "Describe the task, installation or process.", ""],
  ["quantity", "Quantity", "", "units"],
  ["targetWeeks", "Requested timing", "A request, not a confirmed delivery date.", "weeks"],
  ["stroke", "Required stroke", "Your required travel, in millimeters.", "mm"],
  ["load", "Required load", "Include the unit and operating conditions.", ""],
  ["notes", "Notes or questions", "", ""],
  ["name", "Name", "", ""],
  ["company", "Company", "", ""],
  ["email", "Email", "", ""]
], Pt = Object.freeze(pi.map(([e]) => e)), Me = Object.freeze({
  id: "kinetic-inquiry",
  version: "kinetic-inquiry-v1",
  fields: Object.freeze(pi.map(([e, i, t, o]) => Object.freeze({
    id: e,
    label: i,
    hint: t,
    unit: o,
    enabled: !0,
    required: ["application", "quantity"].includes(e)
  })))
});
function Ct(e) {
  if (!e || typeof e.id != "string" || !e.id.trim() || typeof e.version != "string" || !e.version.trim() || !Array.isArray(e.fields) || e.fields.length !== Pt.length) throw new TypeError("The saved inquiry profile is invalid.");
  if (new Set(e.fields.map((t) => t.id)).size !== Pt.length) throw new TypeError("Each inquiry field needs a unique identity.");
  const i = e.fields.map((t) => {
    const o = Me.fields.find((n) => n.id === t.id);
    if (!o || typeof t.label != "string" || !t.label.trim() || t.label.length > 100 || typeof t.hint != "string" || t.hint.length > 400 || t.unit !== o.unit || typeof t.enabled != "boolean" || t.required !== o.required || o.required && !t.enabled) throw new TypeError("The saved inquiry field configuration is invalid.");
    return { id: t.id, label: t.label.trim(), hint: t.hint.trim(), enabled: t.enabled, required: t.required, unit: t.unit };
  });
  return { id: e.id.trim(), version: e.version.trim(), fields: i };
}
const tn = (e, i) => (e?.inquiryProfile?.fields || Me.fields).map((t) => t.id === "quantity" ? { ...t, required: ui(i) } : t), no = (e, i, t) => tn(e, t).find((o) => o.id === i) || Me.fields.find((o) => o.id === i);
function nn(e, i) {
  const t = (a) => typeof a == "string", o = (a) => t(a) && a.trim().length > 0, n = (a) => a === void 0 || t(a), r = (a) => a !== null && typeof a == "object" && !Array.isArray(a), s = (a, c) => Array.isArray(a) && a.every(c), d = (a) => new Set(a.map((c) => c.id)).size === a.length;
  if (!r(e) || e.id !== i.roomReleaseId || e.productId !== i.productId || e.modelRevision !== i.modelRevision || !Number.isSafeInteger(e.version) || e.version < 0 || !["bundled", "demo", "preview"].includes(e.source) || !o(e.createdAt) || !Number.isFinite(Date.parse(e.createdAt))) return !1;
  const l = e.content;
  return !r(l) || l.id !== i.productId || l.modelId !== i.modelId || !["title", "shortTitle", "eyebrow", "tagline", "description", "summary", "demoNotice", "roomRevision"].every((a) => t(l[a])) || !r(l.source) || !["label", "author", "license", "url", "note"].every((a) => t(l.source[a])) || !s(l.highlights, (a) => r(a) && t(a.label) && t(a.value)) || !s(l.specGroups, (a) => r(a) && o(a.id) && t(a.title) && s(a.facts, (c) => r(c) && t(c.label) && t(c.value) && t(c.source) && ["note", "nodeId", "status"].every((u) => n(c[u])))) || !s(l.questions, (a) => r(a) && ["id", "title", "description", "actionLabel"].every((c) => o(a[c])) && r(a.target) && (a.target.kind === "part" ? o(a.target.nodeId) : a.target.kind === "chapter" && o(a.target.tourId) && o(a.target.chapterId))) || !s(l.documents, (a) => r(a) && ["id", "title", "revision", "assetId"].every((c) => o(a[c])) && ["description", "type", "date", "fileName", "nodeId"].every((c) => n(a[c]))) || !d(l.documents) || l.partContent !== void 0 && !s(l.partContent, (a) => r(a) && o(a.nodeId) && t(a.title) && t(a.description) && s(a.documentIds, (c) => o(c) && l.documents.some((u) => u.id === c))) ? !1 : e.presentation === void 0 || r(e.presentation) && ["engineering", "linework", "flat"].includes(e.presentation.defaultRenderStyle);
}
const jt = 12, fi = Object.freeze([
  Object.freeze({ value: "question", label: "Ask a question" }),
  Object.freeze({ value: "change", label: "Request a change" }),
  Object.freeze({ value: "review", label: "Request technical review" })
]), Ae = (e) => typeof e == "string" ? e.trim() : "", oo = (e) => fi.find((i) => i.value === e)?.label || "Question", on = (e) => e?.context?.drawing?.regionLabel || e?.context?.part?.title || e?.context?.document?.title || e?.context?.chapter?.title || e?.context?.productTitle || "Product reference", _e = (e) => JSON.stringify([
  e.productId,
  e.modelId,
  e.modelRevision,
  e.roomReleaseId || null,
  e.inquiryProfileVersion || null,
  ...e.productRevision ? [{ productRevision: e.productRevision }] : []
]);
function sn(e, i) {
  if (!Array.isArray(e) || e.length > jt)
    throw new h("VALIDATION", `Keep this inquiry within ${jt} referenced requests.`, { requestItems: "Review the request list." });
  const t = e.map((o) => {
    if (!o || !Ae(o.id) || Ae(o.id).length > 128)
      throw new h("VALIDATION", "Each request needs its own valid identity.", { requestItems: "Review the request list." });
    if (!fi.some((r) => r.value === o.purpose))
      throw new h("VALIDATION", "Choose a purpose for each request.", { requestItems: "Choose a listed purpose." });
    if (typeof o.notes != "string" || o.notes.length > 2e3)
      throw new h("VALIDATION", "Keep each request within 2,000 characters.", { requestItems: "Check the request notes." });
    const n = W(o.context);
    if (_e(n) !== _e(i))
      throw new h("INCOMPATIBLE_CONTEXT", "This reference belongs to another product, model revision or product release. Your request list is unchanged.");
    return { id: Ae(o.id), purpose: o.purpose, notes: Ae(o.notes), context: n };
  });
  if (new Set(t.map((o) => o.id)).size !== t.length)
    throw new h("VALIDATION", "Each referenced request needs a unique identity.", { requestItems: "Review the request list." });
  return t;
}
function rn(e = []) {
  const i = e.filter((t) => !Ae(t.notes));
  return i.length ? {
    requestItems: "Describe each referenced request, or remove it before reviewing.",
    ...Object.fromEntries(i.map((t) => [`requestItem-${t.id}`, "Add what you want to ask, change or review."]))
  } : {};
}
class h extends Error {
  constructor(i, t, o = {}) {
    super(t), this.name = "ProjectError", this.code = i, this.fields = o;
  }
}
const I = (e) => JSON.parse(JSON.stringify(e)), k = (e) => typeof e == "string" ? e.trim() : "", hi = ["name", "email", "company", "application", "quantity", "targetWeeks", "stroke", "load", "notes"], an = () => Object.fromEntries(hi.map((e) => [e, ""])), vi = Object.freeze([
  Object.freeze({ value: "discuss", label: "Help define scope" }),
  Object.freeze({ value: "product", label: "Whole product" }),
  Object.freeze({ value: "part", label: "Selected component" })
]);
function so(e, i) {
  return e?.quoteScope === "part" ? `Selected component${i?.part ? ` · ${i.part.title}` : ""}` : vi.find((t) => t.value === e?.quoteScope)?.label || "Not specified";
}
const dn = () => `DRAFT-${globalThis.crypto.randomUUID()}`, se = (e) => JSON.stringify([e.productId, e.modelId, e.modelRevision, e.roomReleaseId || null, e.inquiryProfileVersion || null, ...e.productRevision ? [{ productRevision: e.productRevision }] : [], ...e.drawing ? [Ue(e)] : []]);
function W(e) {
  let i;
  try {
    i = en(e);
  } catch (t) {
    throw new h("VALIDATION", t.message);
  }
  if (!i.modelId || !i.modelRevision) throw new h("VALIDATION", "An inquiry needs the exact model and revision.");
  if (e.roomReleaseId !== void 0 || e.inquiryProfile !== void 0 || e.roomSnapshot !== void 0) {
    if (!k(e.roomReleaseId) || !k(e.inquiryProfileVersion)) throw new h("VALIDATION", "A versioned inquiry needs its product release and inquiry profile.");
    let t;
    try {
      t = Ct(e.inquiryProfile);
    } catch (r) {
      throw new h("VALIDATION", r.message);
    }
    if (t.version !== e.inquiryProfileVersion) throw new h("VALIDATION", "The inquiry profile does not match its saved version.");
    const o = e.roomSnapshot;
    let n;
    try {
      n = Ct(o?.inquiryProfile);
    } catch {
      throw new h("VALIDATION", "The saved product release has an invalid inquiry profile.");
    }
    if (!nn(o, { ...i, roomReleaseId: e.roomReleaseId }) || JSON.stringify(n) !== JSON.stringify(t) || JSON.stringify(o).length > 2e5)
      throw new h("VALIDATION", "The saved product release is incomplete or does not match this inquiry.");
    i.roomReleaseId = k(e.roomReleaseId), i.inquiryProfileVersion = k(e.inquiryProfileVersion), i.inquiryProfile = t, i.roomSnapshot = I(o);
  }
  if (i.document && e.document.revision !== void 0) {
    if (!k(e.document.revision)) throw new h("VALIDATION", "A linked document needs its revision.");
    i.document.revision = k(e.document.revision);
  }
  if (i.document && i.roomSnapshot) {
    const t = i.roomSnapshot.content.documents.find((o) => o.id === i.document.id);
    if (!t || t.revision !== i.document.revision || t.title !== i.document.title)
      throw new h("VALIDATION", "The linked document does not match its saved product version.");
  }
  if (i.drawing && i.roomSnapshot) {
    const t = i.roomSnapshot.content.documents.find((o) => o.id === i.drawing.id);
    if (!t || t.title !== i.drawing.title || t.revision !== i.drawing.revision || t.assetId !== i.drawing.assetId)
      throw new h("VALIDATION", "The drawing does not match its saved product version.");
  }
  return i;
}
function nt(e, i = dn()) {
  return { id: i, revision: 0, inquiryRulesVersion: it, context: W(e), values: { ...an(), intent: "quotation", quoteScope: "discuss" }, requirements: [], updatedAt: null };
}
function Fe(e) {
  if (!e || !k(e.id) || !Number.isSafeInteger(e.revision) || e.revision < 0) throw new h("VALIDATION", "This draft has no valid identity or revision.");
  const i = Object.fromEntries(hi.map((s) => [s, k(e.values?.[s])]));
  if (e.values?.quantity !== void 0 && typeof e.values.quantity != "string") throw new h("VALIDATION", "Quantity must be a whole number or left unknown.", { quantity: "Enter a whole quantity from 1 to 100,000." });
  if (Object.hasOwn(e.values || {}, "intent") && (i.intent = k(e.values.intent), !li.some((s) => s.value === i.intent)))
    throw new h("VALIDATION", "Choose an inquiry intent.", { intent: "Choose quotation or application review." });
  const t = e.inquiryRulesVersion ?? (i.intent ? it : void 0);
  if (t !== void 0 && t !== it) throw new h("VALIDATION", "This inquiry uses an unsupported rule version.");
  if (Object.hasOwn(e.values || {}, "quoteScope") && (i.quoteScope = k(e.values.quoteScope), i.quoteScope && !vi.some((s) => s.value === i.quoteScope)))
    throw new h("VALIDATION", "Choose a quotation scope.", { quoteScope: "Choose a listed scope or leave it open." });
  if (!Array.isArray(e.requirements) || e.requirements.length > 30) throw new h("VALIDATION", "Keep the inquiry within 30 confirmed requirements.", { requirements: "Check the requirement list." });
  const o = e.requirements.map((s) => {
    if (!s || !k(s.id) || !k(s.label) || !["customer", "model-reference"].includes(s.source)) throw new h("VALIDATION", "A requirement needs a label and source.", { requirements: "Check each requirement and its source." });
    const d = { id: k(s.id), label: k(s.label), value: k(s.value), unit: k(s.unit), source: s.source, confirmed: s.confirmed === !0 };
    if (s.part) {
      if (!k(s.part.id) || !k(s.part.title)) throw new h("VALIDATION", "A linked requirement needs a valid part.");
      d.part = { id: k(s.part.id), title: k(s.part.title) };
    }
    if ([d.id, d.label, d.value, d.unit, d.part?.title || ""].some((l) => l.length > 1e3)) throw new h("VALIDATION", "Keep requirement details within 1,000 characters.");
    return d;
  });
  if (new Set(o.map((s) => s.id)).size !== o.length) throw new h("VALIDATION", "Each requirement needs a unique identity.");
  if (Object.values(i).some((s) => s.length > 4e3)) throw new h("VALIDATION", "Keep individual fields within 4,000 characters.");
  const n = W(e.context), r = Object.hasOwn(e, "requestItems") ? { requestItems: sn(e.requestItems, n) } : {};
  return { id: k(e.id), revision: e.revision, ...t !== void 0 ? { inquiryRulesVersion: t } : {}, context: n, values: i, requirements: o, ...r, updatedAt: e.updatedAt || null };
}
function wi(e) {
  const { values: i, requirements: t } = e, o = {};
  return i.quoteScope === "part" && !e.context.part && (o.quoteScope = "Attach a component reference or choose another scope."), i.application ? i.application.length > 2e3 && (o.application = "Keep the application within 2,000 characters.") : o.application = "Describe the application or question to review.", (ui(i) || i.quantity) && !ze(i.quantity) && (o.quantity = "Enter a whole quantity from 1 to 100,000."), i.targetWeeks && (!/^\d+$/.test(i.targetWeeks) || +i.targetWeeks < 1 || +i.targetWeeks > 104) && (o.targetWeeks = "Enter 1–104 weeks, or leave it open."), i.email && (i.email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(i.email)) && (o.email = "Enter a valid email, or leave it blank for this demo."), i.name.length > 120 && (o.name = "Keep the name within 120 characters."), i.company.length > 160 && (o.company = "Keep the company within 160 characters."), i.notes.length > 2e3 && (o.notes = "Keep the notes within 2,000 characters."), i.stroke && (!/^\d+(\.\d+)?$/.test(i.stroke) || +i.stroke <= 0 || +i.stroke > 1e5) && (o.stroke = "Enter a positive stroke in millimeters, or leave it open."), i.load.length > 200 && (o.load = "Keep the load detail within 200 characters."), t.some((n) => !n.confirmed) && (o.requirements = "Confirm each attached requirement, or remove it from the inquiry."), { ...o, ...rn(e.requestItems) };
}
function xe(e) {
  return Array.isArray(e) ? `[${e.map(xe).join(",")}]` : e && typeof e == "object" ? `{${Object.keys(e).sort().map((i) => `${JSON.stringify(i)}:${xe(e[i])}`).join(",")}}` : JSON.stringify(e);
}
const y = (e, i) => xe(e) === xe(i);
function mi(e) {
  return xe(e);
}
function Y(e) {
  return { ...I(e), token: mi(e) };
}
function P(e, i) {
  if (!e || e.kind !== i || typeof e.token != "string") throw new h("STALE_REVIEW", "Review the details before confirming.");
  const { token: t, ...o } = e;
  if (t !== mi(o)) throw new h("STALE_REVIEW", "The reviewed details changed. Review them again before confirming.");
  return I(o);
}
function Lt(e) {
  const i = Fe(e), t = wi(i);
  if (Object.keys(t).length) throw new h("VALIDATION", "Check the highlighted inquiry details.", t);
  if (i.revision < 1) throw new h("STALE_REVIEW", "Save the draft before reviewing it.");
  return Y({ kind: "inquiry", draft: i });
}
function cn(e, i) {
  const t = e?.quotes?.find((o) => o.id === i);
  if (!t) throw new h("NOT_FOUND", "This quotation is no longer available.");
  return t;
}
function gi(e, i) {
  const t = cn(e, i);
  if (e.quotes.at(-1)?.id !== t.id) throw new h("STALE_REVIEW", "Open the latest quotation before requesting the next step.");
  return t;
}
function ln(e, i, t) {
  const o = gi(e, i), n = { quantity: k(t?.quantity), targetWeeks: k(t?.targetWeeks), notes: k(t?.notes) }, r = {};
  if ((!/^\d+$/.test(n.quantity) || +n.quantity < 1 || +n.quantity > 1e5) && (r.quantity = "Enter a whole quantity from 1 to 100,000."), n.targetWeeks && (!/^\d+$/.test(n.targetWeeks) || +n.targetWeeks < 1 || +n.targetWeeks > 104) && (r.targetWeeks = "Enter 1–104 weeks, or leave it open."), n.notes.length > 2e3 && (r.notes = "Keep the question within 2,000 characters."), !Object.keys(r).length && +n.quantity === o.quantity && (n.targetWeeks ? +n.targetWeeks : null) === o.requestedWeeks && !n.notes && (r.notes = "Describe what you want to change, or update quantity or timing."), Object.keys(r).length) throw new h("VALIDATION", "Check the requested changes.", r);
  return Y({ kind: "revision", projectId: e.id, projectRevision: e.revision, quoteId: o.id, quoteVersion: o.version, values: n, ...e.context.drawing || e.context.inspection || e.context.viewerReference ? { context: I(L(e, o)) } : {} });
}
function un(e, i, t) {
  const o = gi(e, i);
  ii(e);
  const n = k(t?.intent), r = k(t?.message), s = {};
  if (["discussion", "engineering-review"].includes(n) || (s.intent = "Choose a next step."), r ? r.length > 2e3 && (s.message = "Keep the message within 2,000 characters.") : s.message = "Add what you would like to discuss or review.", Object.keys(s).length) throw new h("VALIDATION", "Check the next-step request.", s);
  return Y({ kind: "next-step", projectId: e.id, projectRevision: e.revision, quoteId: o.id, quoteVersion: o.version, intent: n, message: r, ...e.context.drawing || e.context.inspection || e.context.viewerReference ? { context: I(L(e, o)) } : {} });
}
const pn = /^[a-f0-9]{64}$/i, Ce = /^[a-zA-Z0-9][a-zA-Z0-9._:-]*$/, Ii = (e) => JSON.parse(JSON.stringify(e)), ee = (e) => typeof e == "string" && e.trim().length > 0, qe = (e, i) => Array.isArray(e) && e.length === i && e.every(Number.isFinite), z = (e, i, t, o = "error") => ({ code: e, path: i, message: t, severity: o });
class ot extends TypeError {
  constructor(i) {
    super(i.map((t) => `${t.path}: ${t.message}`).join(`
`)), this.name = "DrawingPackageError", this.issues = i;
  }
}
function fn(e, i) {
  const t = `${e.id}-pdf`, o = `${e.id}-step`;
  return {
    ...Ii(e),
    schemaVersion: 2,
    modelRevision: e.modelRevision || i.modelRevision,
    mappingRevision: e.mappingRevision || `legacy-${e.revision}`,
    pairing: e.pairing || { status: "unverified", evidence: "Legacy drawing metadata. Confirm the source PDF and STEP pairing before publication." },
    assets: [
      { id: t, kind: "pdf", file: e.pdfFile, sha256: e.assetRevision },
      { id: o, kind: "step", file: e.stepFile, sha256: e.stepSha256 }
    ],
    sheets: (e.sheets || []).map((n) => ({
      ...n,
      assetId: t,
      format: "pdf",
      pdfPage: n.pdfPage || 1,
      coordinateFrame: "page-top-left",
      rotation: 0,
      regions: (n.regions || []).map((r) => ({ ...r, mappingStatus: r.mappingStatus || "confirmed" }))
    }))
  };
}
function hn(e) {
  if (!ee(e)) return !1;
  try {
    const i = new URL(e, "https://drawing-package.invalid/");
    return ["http:", "https:", "blob:"].includes(i.protocol) && !i.username && !i.password;
  } catch {
    return !1;
  }
}
function vn(e) {
  if (!ee(e)) return !1;
  try {
    const i = new URL(e);
    return ["http:", "https:"].includes(i.protocol) && !i.username && !i.password;
  } catch {
    return !1;
  }
}
function wn(e) {
  const i = [], t = (d, l, a) => i.push(z(d, l, a));
  e.schemaVersion !== 2 && t("schema-version", "schemaVersion", "Expected drawing package schema version 2.");
  for (const d of ["id", "modelId", "modelRevision", "title", "revision", "mappingRevision", "sourceURL", "units", "status"])
    ee(e[d]) || t("required", d, "A nonempty value is required.");
  Ce.test(e.id || "") || t("invalid-id", "id", "Use a stable identifier."), ["mm", "cm", "m", "in", "unknown"].includes(e.units) || t("units", "units", "Use mm, cm, m, in or unknown; do not infer missing source units."), vn(e.sourceURL) || t("source-url", "sourceURL", "Use an absolute HTTP(S) source URL without credentials."), (!["source-derived", "human-confirmed", "unverified"].includes(e.pairing?.status) || !ee(e.pairing?.evidence)) && t("pairing-evidence", "pairing", "Pairing needs an explicit status and evidence.");
  const o = Array.isArray(e.assets) ? e.assets : [], n = /* @__PURE__ */ new Map();
  o.length || t("assets", "assets", "At least one original source asset is required."), o.forEach((d, l) => {
    const a = `assets[${l}]`;
    if (!d || typeof d != "object" || Array.isArray(d)) {
      t("asset", a, "An asset object is required.");
      return;
    }
    (!Ce.test(d.id || "") || n.has(d.id)) && t("asset-id", `${a}.id`, "Asset IDs must be unique stable identifiers."), n.set(d.id, d), ["pdf", "svg", "step"].includes(d.kind) || t("asset-kind", `${a}.kind`, "Use pdf, svg or step."), pn.test(d.sha256 || "") || t("source-identity", `${a}.sha256`, "An exact SHA-256 source identity is required."), (!ee(d.file) || d.file.startsWith("/") || d.file.split(/[\\/]/).includes("..") || /[?#]/.test(d.file)) && t("asset-file", `${a}.file`, "Use a file path relative to this package directory."), d.url !== void 0 && !hn(d.url) && t("asset-url", `${a}.url`, "Use a local or HTTP(S) asset URL.");
  }), o.forEach((d, l) => {
    if (!d?.sourceAssetId) return;
    const a = /* @__PURE__ */ new Set([d.id]);
    let c = d;
    for (; c.sourceAssetId; ) {
      if (a.has(c.sourceAssetId) || !n.has(c.sourceAssetId)) {
        t("derived-source", `assets[${l}].sourceAssetId`, "Derived assets must resolve to an original asset without cycles.");
        break;
      }
      a.add(c.sourceAssetId), c = n.get(c.sourceAssetId);
    }
  });
  const r = Array.isArray(e.sheets) ? e.sheets : [], s = /* @__PURE__ */ new Set();
  return r.length || t("sheets", "sheets", "At least one drawing sheet is required."), r.forEach((d, l) => {
    const a = `sheets[${l}]`;
    if (!d || typeof d != "object" || Array.isArray(d)) {
      t("sheet", a, "A sheet object is required.");
      return;
    }
    const c = d.viewBox;
    (!Ce.test(d.id || "") || s.has(d.id)) && t("sheet-id", `${a}.id`, "Sheet IDs must be unique stable identifiers."), s.add(d.id), ee(d.title) || t("sheet-title", `${a}.title`, "A sheet title is required.");
    const u = n.get(d.assetId);
    (!u || u.kind !== d.format || !["pdf", "svg"].includes(d.format)) && t("sheet-asset", `${a}.assetId`, "The sheet must reference an asset with the matching PDF or SVG format."), d.format === "pdf" && (!Number.isInteger(d.pdfPage) || d.pdfPage < 1) && t("pdf-page", `${a}.pdfPage`, "PDF pages use positive one-based page numbers."), d.coordinateFrame !== "page-top-left" && t("coordinate-frame", `${a}.coordinateFrame`, "Use unrotated page-top-left coordinates.");
    const g = qe(c, 4) && c[2] > 0 && c[3] > 0;
    g || t("view-box", `${a}.viewBox`, "Use finite x, y, width and height values with positive dimensions."), d.format === "pdf" && g && (c[0] !== 0 || c[1] !== 0) && t("pdf-origin", `${a}.viewBox`, "PDF coordinates start at the unrotated page top-left [0, 0]."), [0, 90, 180, 270].includes(d.rotation) || t("rotation", `${a}.rotation`, "Use 0, 90, 180 or 270 degrees clockwise.");
    const A = /* @__PURE__ */ new Set();
    Array.isArray(d.regions) || t("regions", `${a}.regions`, "Regions must be an array."), (Array.isArray(d.regions) ? d.regions : []).forEach((R, v) => {
      const f = `${a}.regions[${v}]`;
      if (!R || typeof R != "object" || Array.isArray(R)) {
        t("region", f, "A semantic region object is required.");
        return;
      }
      const w = R.bounds;
      (!Ce.test(R.id || "") || A.has(R.id)) && t("region-id", `${f}.id`, "Region IDs must be unique within the sheet."), A.add(R.id), ee(R.label) || t("region-label", `${f}.label`, "A customer-readable detail name is required."), ["confirmed", "needs-review", "missing"].includes(R.mappingStatus) || t("mapping-status", `${f}.mappingStatus`, "Use confirmed, needs-review or missing."), R.mappingStatus === "confirmed" && !ee(R.partId) && t("part-id", `${f}.partId`, "Confirmed regions must reference a real model part ID.");
      const p = qe(w, 4) && w[2] > 0 && w[3] > 0;
      if (!p && !(w === null && R.mappingStatus === "missing") ? t("region-bounds", `${f}.bounds`, "Use finite x, y, width and height values with positive dimensions.") : p && g && (w[0] < c[0] || w[1] < c[1] || w[0] + w[2] > c[0] + c[2] + 1e-7 || w[1] + w[3] > c[1] + c[3] + 1e-7) && t("region-outside", `${f}.bounds`, "The semantic region must stay inside its source page."), R.focusPoint !== void 0 && !qe(R.focusPoint, 3) && t("focus-point", `${f}.focusPoint`, "A focus point must contain three finite model-space coordinates."), R.camera !== void 0)
        if (!R.camera || typeof R.camera != "object") t("camera", `${f}.camera`, "Authored camera data must be an object.");
        else {
          for (const m of ["direction", "halfSize"]) qe(R.camera[m], 3) || t("camera-required", `${f}.camera.${m}`, "Authored detail cameras need a direction and framing halfSize.");
          for (const [m, q] of Object.entries(R.camera))
            ["target", "direction", "halfSize", "focusPoint", "position", "up"].includes(m) ? (!qe(q, 3) || ["direction", "up"].includes(m) && Math.hypot(...q) === 0 || m === "halfSize" && q.some((b) => b <= 0)) && t("camera-vector", `${f}.camera.${m}`, "Use a finite, non-degenerate model-space vector.") : t("camera-field", `${f}.camera.${m}`, "Only authored target, position, direction, up, halfSize or focusPoint vectors are supported.");
        }
    });
  }), i;
}
function At(e, i = {}) {
  if (!e || typeof e != "object" || Array.isArray(e)) throw new ot([z("package", "$", "A drawing package object is required.")]);
  const t = e.schemaVersion === 1 ? fn(e, i) : Ii(e);
  !t.modelRevision && i.modelRevision && (t.modelRevision = i.modelRevision), Array.isArray(t.assets) && (t.assets = t.assets.map((n) => n && typeof n == "object" ? {
    ...n,
    sha256: typeof n.sha256 == "string" ? n.sha256.toLowerCase() : n.sha256,
    ...i.assetURLs?.[n.id] || i.assetURLs?.[n.file] ? { url: i.assetURLs[n.id] || i.assetURLs[n.file] } : {}
  } : n));
  const o = wn(t);
  if (o.length) throw new ot(o);
  return t;
}
function mn(e, { partIds: i, modelRevision: t } = {}) {
  let o;
  try {
    o = At(e);
  } catch (s) {
    if (s instanceof ot) return { valid: !1, issues: s.issues };
    throw s;
  }
  const n = [];
  t ? o.modelRevision !== t && n.push(z("model-version", "modelRevision", "The package targets a different model revision. Reconfirm its associations.")) : n.push(z("model-version-required", "modelRevision", "Validate against the exact imported model revision before publication.")), o.pairing.status === "unverified" && n.push(z("pairing-unverified", "pairing", "Confirm evidence that these source documents and geometry belong together.")), o.units === "unknown" && n.push(z("units-unverified", "units", "Source units have not been verified.", "warning")), o.status === "unreviewed-reference" && n.push(z("reference-only", "status", "This is an unreviewed reference, not a manufacturing-approved drawing.", "warning")), o.unplacedMappings?.length && n.push(z("unplaced-mappings", "unplacedMappings", "Place or explicitly remove all details whose original sheet is no longer present."));
  const r = i ? new Set(i) : null;
  return r || n.push(z("part-registry", "modelId", "Validate against the exact imported model part registry before publication.")), o.sheets.forEach((s, d) => s.regions.forEach((l, a) => {
    const c = `sheets[${d}].regions[${a}]`;
    l.mappingStatus !== "confirmed" && n.push(z("mapping-unconfirmed", `${c}.mappingStatus`, "Confirm the model part and authored source region before publication.")), r && !r.has(l.partId) && n.push(z("unknown-part", `${c}.partId`, "The selected part does not exist in this model revision."));
  })), { valid: !n.some((s) => s.severity === "error"), issues: n };
}
function gn(e, i, t = null) {
  const o = e?.sheets?.find((s) => s.id === i);
  if (!o) return null;
  const n = t === null ? null : o.regions.find((s) => s.id === t);
  if (t !== null && !n) return null;
  const r = e.assets.find((s) => s.id === o.assetId);
  return r ? { package: e, sheet: o, region: n, asset: r } : null;
}
const ve = (e) => typeof e == "string" ? e.trim() : "", V = (e) => {
  throw new h("DRAWING_REFERENCE_INVALID", e);
};
function Oe(e, i) {
  const t = W(e);
  (!t.drawing || i?.kind !== "annora-drawing-release" || !["demo", "bundled"].includes(i.source) || !ve(i.id) || !Number.isInteger(i.version) || i.version < 1) && V("Choose a published drawing release. Drafts and previews cannot change a customer project.");
  let o;
  try {
    o = At(i.packageSnapshot);
  } catch {
    V("This drawing release has an invalid source package.");
  }
  o.pairing.status !== "human-confirmed" && V("A person must confirm the source pairing before this release can replace a project reference."), (!Array.isArray(i.partIds) || !mn(o, { partIds: i.partIds, modelRevision: i.modelRevision }).valid) && V("Resolve every missing or uncertain drawing association before adopting this release."), (i.productId !== t.productId || i.modelId !== t.modelId || o.modelId !== t.modelId || i.modelRevision !== t.modelRevision || o.modelRevision !== t.modelRevision || i.sourceRevision !== o.revision || i.mappingRevision !== o.mappingRevision) && V("The proposed reference does not match this published product and model version.");
  const n = t.drawing, s = o.sheets.filter((u) => u.id === n.sheetId).flatMap((u) => u.regions.filter((g) => g.id === n.regionId).map((g) => ({ sheet: u, region: g })));
  s.length !== 1 && V("Select exactly one available detail from the published sheet.");
  const { sheet: d, region: l } = s[0], a = o.assets.find((u) => u.id === d.assetId);
  (l.mappingStatus !== "confirmed" || !i.partIds.includes(l.partId)) && V("Confirm this detail and its part before adoption.");
  const c = {
    id: o.id,
    title: o.title,
    revision: o.revision,
    assetId: a.id,
    assetRevision: a.sha256,
    partId: l.partId,
    sheetId: d.id,
    sheetTitle: d.title,
    regionId: l.id,
    regionLabel: l.label,
    sourceURL: o.sourceURL,
    mappingRevision: o.mappingRevision,
    ...n.revisionLabel !== void 0 ? { revisionLabel: o.revisionLabel } : {},
    ...i.presentationSnapshot !== void 0 ? {
      presentationSnapshot: I(i.presentationSnapshot),
      ...i.presentationSnapshot ? { presentationRevision: i.presentationSnapshot.revision } : {}
    } : {}
  };
  return (!y(n, c) || t.part?.id !== l.partId) && V("The selected detail, part, source hash or association version differs from the published release."), t;
}
function Vt(e, i, t, o = null) {
  const n = Oe(i?.context, t), r = G(e);
  (!e.context?.drawing || e.context.productId !== n.productId || e.context.modelId !== n.modelId) && V("Use a published reference for the same product and model family.");
  const s = de(r) !== de(n), d = ve(i.note), l = i.quoteDraftAction || "keep";
  if (!s && !(l === "replace" && o && !y(L(e, o), r)) && V("This project already uses the selected drawing reference."), !d || d.length > 2e3) throw new h("VALIDATION", "Explain the reference change in 1–2,000 characters.", { note: "Explain why this project should use the new drawing reference." });
  if (!["keep", "replace"].includes(l)) throw new h("VALIDATION", "Choose whether to retain or replace the existing quotation draft.");
  return {
    kind: "drawing-revision-proposal",
    status: "proposed",
    projectId: e.id,
    projectRevision: e.revision,
    fromContext: I(r),
    context: n,
    referenceChanged: s,
    release: I(t),
    note: d,
    quoteDraftAction: l,
    quoteDraft: o ? I(o) : null
  };
}
function $t(e, i) {
  return Y({ ...I(e), kind: "drawing-revision", status: "reviewed", reviewedAt: i });
}
function In(e) {
  if (e.lastDrawingReviewToken !== void 0 && !ve(e.lastDrawingReviewToken) && V("The drawing review receipt is incomplete."), e.activeDrawingContext === void 0 && e.drawingRevisions === void 0) return;
  (!e.context.drawing || !Array.isArray(e.drawingRevisions) || !e.drawingRevisions.length) && V("This project has no complete drawing-reference history.");
  let i = e.context, t = 1;
  const o = /* @__PURE__ */ new Set();
  for (const n of e.drawingRevisions) {
    (!ve(n.id) || o.has(n.id) || n.status !== "adopted" || !ve(n.reviewToken) || !ve(n.note) || !Number.isFinite(Date.parse(n.createdAt)) || !Number.isFinite(Date.parse(n.reviewedAt)) || !Number.isInteger(n.projectRevision) || n.projectRevision <= t || n.projectRevision > e.revision || !["keep", "replace"].includes(n.quoteDraftAction) || !y(n.fromContext, i)) && V("The drawing-reference history is inconsistent.");
    const r = Oe(n.context, n.release);
    (r.productId !== e.context.productId || r.modelId !== e.context.modelId || de(r) === de(i)) && V("A drawing transition must stay with this product and explicitly change its reference."), o.add(n.id), i = r, t = n.projectRevision;
  }
  y(i, e.activeDrawingContext) || V("The active drawing reference does not match the last confirmed adoption.");
}
function We(e, i) {
  return (e.drawingRevisions || []).filter((t) => t.projectRevision <= i).at(-1)?.context || e.context;
}
function ue(e, i, t) {
  if (!i.context) {
    t && !y(t, e.context) && V("This later record is missing its pinned drawing reference.");
    return;
  }
  const o = W(i.context), n = [e.context, ...(e.drawingRevisions || []).map((r) => r.context)];
  (!y(o, i.context) || !n.some((r) => y(r, o)) || t && !y(t, o)) && V("A saved commercial record has a different drawing reference from its reviewed source.");
}
const yn = "kinetic-01";
function qn(e) {
  return e?.drawing ? {
    intent: "quotation",
    name: "Alex Morgan",
    email: "alex@example.com",
    company: "Example Engineering Co.",
    application: `Please review ${e.drawing.regionLabel.toLowerCase()} on ${e.productTitle}. The selected part and drawing revision are attached for reference.`,
    quantity: "20",
    targetWeeks: "6",
    stroke: "",
    load: "",
    notes: "Please confirm the required dimensions, tolerances and material before preparing a quotation. Viewed geometry is reference context only."
  } : {
    intent: "quotation",
    name: "Alex Morgan",
    email: "alex@example.com",
    company: "Example Automation Co.",
    application: "Explore a crank-slider mechanism for a compact inspection fixture. We need to understand the guide arrangement and mounting interfaces.",
    quantity: "20",
    targetWeeks: "6",
    stroke: "70",
    load: "To discuss after reviewing the fixture layout",
    notes: "Please review load, cycle rate and mounting before confirming suitability."
  };
}
const Rn = (e) => {
  let i = 2166136261;
  for (let t = 0; t < e.length; t++) i = Math.imul(i ^ e.charCodeAt(t), 16777619);
  return `customer-note-${(i >>> 0).toString(16)}`;
}, yi = (e, i = []) => [
  { id: "load-cycle", label: "Confirm application load and required cycle rate.", owner: "Customer / engineering", status: "Open" },
  { id: "mounting", label: "Review mounting interfaces, tolerances and application fit.", owner: "Engineering", status: "Open" },
  { id: "timing", label: "Confirm achievable lead time after technical review.", owner: "Sales", status: "Open" },
  { id: "shipping", label: "Confirm freight, tax and any application-specific work.", owner: "Sales / customer", status: "Unpriced" },
  ...[...new Set([e.notes, ...i].filter(Boolean))].map((t) => ({ id: Rn(t), label: t, owner: "Sales / engineering", status: "Unanswered" }))
];
function Ut({ id: e, version: i, createdAt: t, values: o, previousQuoteId: n = null, changeId: r = null, replyId: s = null, additionalQuestions: d = [] }) {
  const l = Number(o.quantity), a = l >= 30 ? 175 : 185, c = [
    { label: "Illustrative crank-slider assembly", quantity: l, unitPrice: a, amount: l * a },
    { label: "Example setup allowance", quantity: 1, unitPrice: 250, amount: 250 },
    { label: "Freight and applicable tax", quantity: null, unitPrice: null, amount: null },
    { label: "Application-specific engineering", quantity: null, unitPrice: null, amount: null }
  ];
  return {
    id: e,
    version: i,
    createdAt: t,
    quantity: l,
    unitPrice: a,
    currency: "USD",
    lineItems: c,
    subtotal: l * a + 250,
    total: null,
    requestedWeeks: o.targetWeeks ? Number(o.targetWeeks) : null,
    proposedLeadTime: "6–8 weeks after technical review",
    scope: "Illustrative crank-slider assembly; application-specific work is not priced.",
    assumptions: [
      "Invented example prices: $185 per unit, or $175 at 30 units or more, plus a $250 setup allowance.",
      "This mechanism study is not a manufactured product offer. Geometry and visual finishes do not establish application suitability.",
      "Requested timing is not approved. Freight, tax and application-specific engineering remain unpriced."
    ],
    openItems: yi(o, d),
    source: "sample",
    previousQuoteId: n,
    changeId: r,
    replyId: s
  };
}
function bn({ id: e, createdAt: i, change: t, quote: o, inquiry: n }) {
  const r = Number(t.values.quantity), s = r >= 30 ? 175 : 185, d = [
    { label: "Quantity and sample price", requested: `${r} units`, response: `${r} units at $${s.toFixed(2)} each in the revised example. This is an invented allowance, not a supplier offer.`, status: "Included in example" },
    { label: "Delivery timing", requested: t.values.targetWeeks ? `${t.values.targetWeeks} weeks` : "To discuss", response: "Planning alternative: 6–8 weeks after technical review. Requested timing and expedite availability are not confirmed.", status: "Alternative proposed" },
    ...t.values.notes ? [{ label: "Your question", requested: t.values.notes, response: "Preserved for sales and engineering review. The demonstration does not answer free-text questions.", status: "Unanswered" }] : []
  ];
  return { id: e, changeId: t.id, quoteId: o.id, quoteVersion: o.version, createdAt: i, topics: d, openItems: yi(n.values, [t.values.notes]), source: "sample" };
}
const _t = 1, He = (e) => e && typeof e == "object" && !Array.isArray(e), pe = (e) => typeof e == "string" && e.trim().length > 0 && e.length <= 320 && !/[\u0000-\u001f]/.test(e), qi = (e, i) => Object.assign(new TypeError(i), { code: e }), F = (e, i) => {
  if (!e) throw qi("INVALID_TECHNICAL_REFERENCE", i);
};
function Ri(e, { model: i, nodeId: t } = {}) {
  F(He(e) && e.version === _t, "This technical step uses an unsupported reference version."), F(JSON.stringify(e).length <= 24e3, "Keep one technical reference within the supported size.");
  const o = e.context;
  F(He(o) && pe(o.modelId) && pe(o.modelRevision), "A technical step needs its exact model version."), F(He(o.part) && pe(o.part.id) && pe(o.part.title), "Choose the part linked to this drawing detail."), F(!i || o.modelId === i.id && o.modelRevision === i.revision, "This technical reference belongs to another model version."), F(!t || o.part.id === t, "The technical detail and story step must select the same part.");
  const n = si(o.drawing, o);
  if (F(pe(n.mappingRevision), "A technical step needs its confirmed association version."), F(/^[a-f0-9]{64}$/i.test(n.assetRevision), "A technical step needs the exact source file hash."), F(Object.hasOwn(n, "presentationSnapshot"), "Choose an exact overview version or explicitly use the original drawing."), F(Number.isInteger(e.pdfPage) && e.pdfPage >= 1 && e.pdfPage <= 1e4, "Choose the exact source drawing page."), F([0, 90, 180, 270].includes(e.rotation), "Choose a supported drawing page rotation."), F(e.viewId === null || pe(e.viewId), "Choose an available technical view or the original drawing."), e.viewId !== null) {
    const s = n.presentationSnapshot?.sheets.find((d) => d.sheetId === n.sheetId)?.views.find((d) => d.id === e.viewId);
    F(
      s && s.targets.some((d) => d.regionId === n.regionId && d.confirmed),
      "The selected overview view must contain this confirmed drawing detail."
    );
  }
  return {
    version: _t,
    context: {
      modelId: o.modelId,
      modelRevision: o.modelRevision,
      part: { id: o.part.id, title: o.part.title },
      drawing: n
    },
    pdfPage: e.pdfPage,
    rotation: e.rotation,
    viewId: e.viewId
  };
}
function Ft(e) {
  const i = Ri(e), { context: t } = i, o = t.drawing;
  return JSON.stringify([
    i.version,
    t.modelId,
    t.modelRevision,
    t.part.id,
    o.id,
    o.revision,
    o.assetId,
    o.assetRevision,
    o.mappingRevision,
    o.sheetId,
    o.regionId,
    o.partId,
    o.sourceURL,
    o.presentationRevision ?? null,
    o.presentationSnapshot,
    i.pdfPage,
    i.rotation,
    i.viewId
  ]);
}
function An(e, { model: i, nodeId: t, technicalReferences: o = [], historical: n = !1 } = {}) {
  const r = Ri(e, { model: i, nodeId: t });
  if (n) return r;
  const s = Ft(r);
  if (!o.some((l) => {
    if (l?.available === !1 || l?.nodeId !== r.context.part.id) return !1;
    try {
      return Ft(l.technical) === s;
    } catch {
      return !1;
    }
  })) throw qi(
    "TECHNICAL_SOURCE_UNAVAILABLE",
    "This exact drawing, association or overview is unavailable. Choose a prepared reference and review the step again."
  );
  return r;
}
const Sn = 1, st = 8, Wt = (e) => e && typeof e == "object" && !Array.isArray(e), oe = (e, i, t = !0) => typeof e == "string" && e.length <= i && (!t || !!e.trim());
function Qt(e, { model: i, parts: t = [], technicalReferences: o = [], historical: n = !1 } = {}) {
  if (e === void 0) return [];
  const r = [], s = (l, a) => r.push({ path: `presentation.story${l}`, section: "presentation", message: a, severity: "error" });
  if (!Wt(e) || e.version !== Sn || !Array.isArray(e.steps))
    return s("", "This story has an unsupported structure."), r;
  oe(e.title, 100) || s(".title", "Give the product story a title within 100 characters."), (e.steps.length < 1 || e.steps.length > st) && s(".steps", `Use one to ${st} story steps.`), new Set(e.steps.map((l) => l?.id)).size !== e.steps.length && s(".steps", "Each story step needs a unique identity.");
  const d = new Set(t.map((l) => l.id));
  for (const [l, a] of e.steps.entries()) {
    const c = `.steps.${l}`;
    if (!Wt(a)) {
      s(c, "This story step is missing.");
      continue;
    }
    if ((!oe(a.id, 160) || !oe(a.title, 100) || !oe(a.caption, 320)) && s(c, "Add a short title and explanation to this step."), oe(a.nodeId, 256) ? !n && !d.has(a.nodeId) && s(`${c}.nodeId`, "Choose a part from this prepared model.") : s(c, "A story step needs a bounded part identity."), a.kind === "technical") {
      try {
        An(a.technical, { model: i, nodeId: a.nodeId, technicalReferences: o, historical: n });
      } catch (u) {
        s(`${c}.technical`, u.message);
      }
      (a.tourId !== void 0 || a.chapterId !== void 0) && s(c, "A technical reference cannot also start a prepared action.");
    } else a.technical !== void 0 && s(c, "Only a technical step can contain a drawing reference.");
    if (a.kind === "chapter") {
      const u = i?.tour?.chapters?.find((g) => g.id === a.chapterId);
      !oe(a.tourId, 256) || !oe(a.chapterId, 256) ? s(c, "An action needs its original tour and chapter identities.") : !n && (a.tourId !== i?.tour?.id || !u || u.duration < 2 || u.duration > 3) && s(`${c}.chapterId`, "Choose an approved 2–3 second action from this model."), !n && u && ![u.selectedId, ...u.highlightIds || []].includes(a.nodeId) && s(`${c}.nodeId`, "Choose a subject shown by this prepared action."), a.inspection !== void 0 && s(c, "An authored action uses its prepared camera; remove the unrelated saved view.");
    } else if (a.kind === "inspection" || a.kind === "technical" && a.inspection !== void 0) {
      try {
        const u = bt(a.inspection, { model: { id: i.id, revision: i.revision } });
        if (!u.view || u.preview || u.view.selectedId !== a.nodeId)
          throw new Error();
        if (!n && (!d.has(u.view.selectedId) || !d.has(u.view.scopeId))) throw new Error();
        if (!n && u.view.mode === "operate" && u.view.operation.clipId !== i.operationClipId) throw new Error();
      } catch {
        s(`${c}.inspection`, "Capture a settled view of the selected part in this model revision.");
      }
      (a.tourId !== void 0 || a.chapterId !== void 0) && s(c, "A held view cannot also refer to an action.");
    } else a.kind !== "technical" && s(`${c}.kind`, "Choose a held view, prepared action or technical reference.");
  }
  return r;
}
const ce = 1, $ = (e) => typeof e == "string" ? e.trim() : "", ge = (e) => Number.isSafeInteger(e) && e >= 0, Se = (e) => typeof e == "string" && Number.isFinite(Date.parse(e)), H = (e, i = {}, t = "VALIDATION") => {
  throw new h(t, e, i);
}, zt = (e) => ({ id: e.modelId, revision: e.modelRevision }), rt = (e) => e.inquiry?.requestItems || [];
function Tn(e) {
  if (e == null) return null;
  if (e.kind === "quotation" && $(e.quoteId) && ge(e.quoteVersion) && e.quoteVersion > 0)
    return { kind: "quotation", quoteId: $(e.quoteId), quoteVersion: e.quoteVersion };
  if (e.kind === "clarification" && $(e.messageId)) return { kind: "clarification", messageId: $(e.messageId) };
  H("Choose an existing quotation or open clarification.", { nextAction: "Choose an available next action." });
}
function En(e, i = {}) {
  const t = e.context, o = [], n = i.model || zt(t), r = n.id !== t.modelId || n.revision !== t.modelRevision, s = t.roomSnapshot?.presentation?.story;
  for (const l of Array.isArray(s?.steps) ? s.steps : []) {
    const a = Qt({ version: s.version, title: s.title, steps: [l] }, {
      model: n,
      parts: i.parts || [],
      historical: !i.model
    });
    o.push({
      id: `story:${l.id}`,
      source: "released-story",
      sourceId: l.id,
      title: l.title || "Unavailable story step",
      kind: l.kind,
      step: I(l),
      available: !r && !a.length,
      reason: r || a.length ? "This saved story step is not compatible with the available model or source." : ""
    });
  }
  const d = [
    ...rt(e).filter((l) => l.context?.inspection).map((l) => ({
      id: `request:${l.id}`,
      sourceId: l.id,
      title: on(l),
      caption: l.notes,
      context: l.context
    })),
    ...t.inspection ? [{
      id: "inquiry-inspection",
      sourceId: e.inquiry.id,
      title: t.part?.title || "Saved inquiry view",
      caption: e.inquiry.values.application,
      context: t
    }] : []
  ];
  for (const l of d) {
    let a = null, c = "";
    try {
      if (r || _e(l.context) !== _e(t)) throw new Error();
      const u = bt(l.context.inspection, { model: zt(t) });
      u.view ? (delete u.preview, a = {
        id: l.id,
        title: l.title.slice(0, 100),
        caption: (l.caption || "Review this saved component view.").slice(0, 320),
        kind: "inspection",
        nodeId: u.view.selectedId,
        inspection: u
      }, Qt({ version: 1, title: "Saved project views", steps: [a] }, {
        model: n,
        parts: i.parts || [],
        historical: !i.model
      }).length && (c = "The saved view is not compatible with the available model or source.")) : c = "This saved tour position is not a prepared follow-up view. Choose a released story step.";
    } catch {
      c = "The saved view belongs to an unavailable or incompatible model revision.";
    }
    o.push({
      id: l.id,
      source: "saved-inspection",
      sourceId: l.sourceId,
      title: l.title,
      kind: "inspection",
      step: a,
      available: !c,
      reason: c
    });
  }
  return o;
}
function kn(e, i) {
  const t = e?.nextAction, o = t?.kind === "quotation" ? `Review quotation v${t.quoteVersion}` : "Reply to the clarification";
  if (!i || i.id !== e?.projectId) return { available: !1, reason: "This project is not available in this browser.", label: o, action: t };
  if (t?.kind === "quotation") {
    const n = i.quotes.find((r) => r.id === t.quoteId && r.version === t.quoteVersion);
    return { available: !!n, reason: n ? "" : "The exact quotation referenced by this follow-up is unavailable.", label: o, action: t };
  }
  if (t?.kind === "clarification") {
    const n = i.messages.some((s) => s.id === t.messageId), r = n && ne(i)?.id === t.messageId;
    return { available: r, reason: r ? "" : n ? "This clarification is no longer awaiting a reply. Its original discussion remains in the project." : "The original clarification is unavailable.", label: o, action: t };
  }
  return { available: !1, reason: "This follow-up has no supported next action.", label: "Next action unavailable", action: t };
}
function xn(e, i = `FOLLOW-UP-DRAFT-${globalThis.crypto.randomUUID()}`) {
  return {
    schemaVersion: ce,
    id: i,
    revision: 0,
    projectId: e.id,
    projectRevision: e.revision,
    context: W(e.context),
    title: "Your project follow-up",
    introduction: "",
    stepIds: [],
    requestItemIds: [],
    nextAction: null,
    updatedAt: null
  };
}
function St(e) {
  (e?.schemaVersion !== ce || !$(e.id) || $(e.id).length > 160 || !ge(e.revision) || !$(e.projectId) || !ge(e.projectRevision) || e.projectRevision < 1) && H("This follow-up has no valid project identity or revision.");
  for (const [i, t] of [["title", 100], ["introduction", 1200]])
    (typeof e[i] != "string" || e[i].length > t) && H(`Keep ${i} within ${t} characters.`, { [i]: `Use up to ${t} characters.` });
  for (const [i, t] of [["stepIds", st], ["requestItemIds", 12]])
    (!Array.isArray(e[i]) || e[i].length > t || e[i].some((o) => !$(o) || $(o) !== o || o.length > 300) || new Set(e[i]).size !== e[i].length) && H("Keep each follow-up selection unique and within its limit.", { [i]: `Choose up to ${t} distinct items.` });
  return e.updatedAt !== null && !Se(e.updatedAt) && H("This follow-up has an invalid saved date."), {
    schemaVersion: ce,
    id: $(e.id),
    revision: e.revision,
    projectId: $(e.projectId),
    projectRevision: e.projectRevision,
    context: W(e.context),
    title: $(e.title),
    introduction: $(e.introduction),
    stepIds: [...e.stepIds],
    requestItemIds: [...e.requestItemIds],
    nextAction: Tn(e.nextAction),
    updatedAt: e.updatedAt
  };
}
function at(e, i, t = "STALE_REVIEW") {
  (e.id !== i.projectId || e.revision !== i.projectRevision || !y(e.context, i.context)) && H("This project changed. Reopen the current project and review the follow-up again. Your saved work has not been replaced.", {}, t);
}
function dt(e, i) {
  const t = St(i), o = {};
  at(e, t), t.revision < 1 && H("Save the follow-up before reviewing it.", {}, "STALE_REVIEW"), t.title || (o.title = "Name this follow-up.");
  const n = En(e), r = t.stepIds.map((a) => n.find((c) => c.id === a));
  r.length ? r.some((a) => !a?.available) && (o.stepIds = "A selected source is unavailable. Remove it or choose another saved source.") : o.stepIds = "Choose at least one released story step or saved view.";
  const s = t.requestItemIds.map((a) => rt(e).find((c) => c.id === a));
  (s.some((a) => !a) || rt(e).length && !s.length) && (o.requestItemIds = "Choose the existing customer requests this follow-up addresses.");
  const d = kn({ projectId: e.id, nextAction: t.nextAction }, e);
  d.available || (o.nextAction = d.reason), Object.keys(o).length && H("Review the highlighted follow-up details.", o);
  const l = {
    projectId: e.id,
    projectRevision: e.revision,
    context: I(e.context),
    title: t.title,
    introduction: t.introduction,
    story: { version: 1, title: t.title, steps: r.map((a) => ({ ...I(a.step), id: a.id })) },
    sources: r.map(({ id: a, source: c, sourceId: u, step: g }) => ({ id: a, source: c, sourceId: u, step: I(g) })),
    agenda: I(s),
    nextAction: I(t.nextAction)
  };
  return Y({ kind: "follow-up", draft: t, snapshot: l });
}
function bi(e, { id: i, version: t, createdAt: o }) {
  const n = P(e, "follow-up");
  return (!$(i) || !ge(t) || t < 1 || !Se(o)) && H("A follow-up release needs its identity, version and confirmation time."), { schemaVersion: ce, id: i, version: t, ...I(n.snapshot), createdAt: o, reviewToken: e.token, delivery: "demo-only" };
}
function On(e) {
  return { schemaVersion: ce, followUpId: e.id, revision: 0, stepId: e.story.steps[0].id, mode: "paused", updatedAt: null };
}
function Ai(e, i) {
  return (!ge(i?.revision) || !e.story.steps.some((t) => t.id === i.stepId) || !["paused", "exploring", "complete"].includes(i.mode)) && H("Choose a valid step in this follow-up revision."), {
    schemaVersion: ce,
    followUpId: e.id,
    revision: i.revision,
    stepId: i.stepId,
    mode: i.mode,
    updatedAt: i.updatedAt ?? null
  };
}
function Nn(e) {
  for (const n of ["followUpDrafts", "followUps", "followUpProgress"])
    if (e[n] !== void 0 && !Array.isArray(e[n])) throw new Error("Invalid follow-up collection.");
  const i = e.followUpDrafts || [], t = e.followUps || [], o = e.followUpProgress || [];
  if (new Set(i.map((n) => n.id)).size !== i.length || new Set(i.map((n) => n.projectId)).size !== i.length || new Set(t.map((n) => n.id)).size !== t.length || new Set(t.map((n) => n.reviewToken)).size !== t.length || new Set(o.map((n) => n.followUpId)).size !== o.length) throw new Error("Duplicate follow-up identity.");
  for (const n of i) {
    const r = e.projects.find((s) => s.id === n.projectId);
    if (!r || !y(St(n), n) || n.revision < 1 || !Se(n.updatedAt) || n.projectRevision > r.revision || !y(n.context, r.context)) throw new Error("Invalid follow-up draft.");
  }
  for (const n of t) {
    const r = e.projects.find((u) => u.id === n.projectId);
    if (!r || n.schemaVersion !== ce || !$(n.id) || !Se(n.createdAt) || !ge(n.version) || n.version < 1 || n.delivery !== "demo-only" || !$(n.reviewToken) || !y(n.context, r.context) || n.projectRevision > r.revision) throw new Error("Invalid follow-up release.");
    const s = JSON.parse(n.reviewToken), d = { ...s, token: n.reviewToken };
    if (P(d, "follow-up"), !y(bi(d, n), n)) throw new Error("Follow-up snapshot changed.");
    const l = s.snapshot.nextAction, a = {
      ...r,
      revision: n.projectRevision,
      messages: r.messages.filter((u) => u.projectRevision <= n.projectRevision),
      quotes: r.quotes.filter((u) => !u.issuedProjectRevision || u.issuedProjectRevision <= n.projectRevision)
    };
    if (!y(dt(a, s.draft), d)) throw new Error("Follow-up sources changed.");
    if (l.kind === "quotation" && !r.quotes.some((u) => u.id === l.quoteId && u.version === l.quoteVersion)) throw new Error("Missing pinned quotation.");
    if (t.filter((u) => u.projectId === r.id).map((u) => u.version).sort((u, g) => u - g).some((u, g) => u !== g + 1)) throw new Error("Invalid follow-up version history.");
  }
  for (const n of o) {
    const r = t.find((s) => s.id === n.followUpId);
    if (!r || n.revision < 1 || !Se(n.updatedAt) || !y(Ai(r, n), n)) throw new Error("Invalid follow-up progress.");
  }
}
function Dn({ read: e, change: i, findProject: t, now: o, makeId: n }) {
  const r = (d, l) => {
    const a = (d.followUps || []).find((c) => c.id === l);
    if (!a) throw new h("NOT_FOUND", "This follow-up is not saved in this browser. Open the project to choose an available follow-up.");
    return a;
  };
  return {
    supportsFollowUps: !0,
    async getFollowUpDraft(d) {
      const { store: l } = e(), a = t(l, d);
      return I((l.followUpDrafts || []).find((c) => c.projectId === d) || xn(a, n("FOLLOW-UP-DRAFT")));
    },
    async saveFollowUpDraft(d) {
      const l = St(d);
      return i((a) => {
        const c = t(a, l.projectId);
        at(c, l, "CONFLICT");
        const u = (a.followUpDrafts || []).find((A) => A.projectId === l.projectId);
        if (u ? u.id !== l.id || u.revision !== l.revision : l.revision !== 0)
          throw new h("CONFLICT", "Another editor changed this follow-up. Reopen the saved draft before continuing. Your current input has not been submitted.");
        if (u && y(u, l)) return u;
        const g = { ...l, revision: l.revision + 1, updatedAt: o() };
        return a.followUpDrafts = [...(a.followUpDrafts || []).filter((A) => A.projectId !== l.projectId), g], g;
      });
    },
    async reviewFollowUp(d) {
      const { store: l } = e(), a = t(l, d), c = (l.followUpDrafts || []).find((u) => u.projectId === d);
      if (!c) throw new h("STALE_REVIEW", "Save the follow-up before reviewing it.");
      return dt(a, c);
    },
    async publishFollowUp(d, { confirmed: l = !1 } = {}) {
      if (!l) throw new h("CONFIRMATION_REQUIRED", "Review the follow-up and explicitly confirm this local version.");
      const a = P(d, "follow-up");
      return i((c) => {
        const u = (c.followUps || []).find((v) => v.reviewToken === d.token);
        if (u) return u;
        const g = t(c, a.draft.projectId);
        at(g, a.draft);
        const A = (c.followUpDrafts || []).find((v) => v.projectId === g.id);
        if (!A || !y(A, a.draft) || !y(dt(g, A), d))
          throw new h("STALE_REVIEW", "The saved follow-up changed after review. Review the current draft again before confirming.");
        const R = bi(d, {
          id: n("FOLLOW-UP"),
          version: (c.followUps || []).filter((v) => v.projectId === g.id).length + 1,
          createdAt: o()
        });
        return c.followUps = [...c.followUps || [], R], R;
      });
    },
    async listFollowUps(d) {
      const { store: l } = e();
      return t(l, d), I((l.followUps || []).filter((a) => a.projectId === d));
    },
    async getFollowUp(d) {
      return I(r(e().store, d));
    },
    async getFollowUpProgress(d) {
      const { store: l } = e(), a = r(l, d);
      return I((l.followUpProgress || []).find((c) => c.followUpId === d) || On(a));
    },
    async saveFollowUpProgress(d, l) {
      return i((a) => {
        const c = r(a, d), u = Ai(c, l), g = (a.followUpProgress || []).find((R) => R.followUpId === d);
        if ((g?.revision || 0) !== u.revision)
          throw new h("CONFLICT", "Your saved place changed in another tab. Reopen this follow-up before saving a new position.");
        if (g && g.stepId === u.stepId && g.mode === u.mode) return g;
        const A = { ...u, revision: u.revision + 1, updatedAt: o() };
        return a.followUpProgress = [...(a.followUpProgress || []).filter((R) => R.followUpId !== d), A], A;
      });
    }
  };
}
const D = (e) => typeof e == "string" ? e.trim() : "", x = (e, i = {}) => {
  throw new h("VALIDATION", e, i);
}, Si = (e) => {
  (!e?.id || !Number.isSafeInteger(e.revision)) && x("Open a saved project first.");
}, Ti = (e) => Array.isArray(e) && e.every((i) => D(i) === i && i) && new Set(e).size === e.length, Mt = (e) => typeof e == "string" && Number.isFinite(Date.parse(e)), Pn = Object.freeze([
  { value: "included", label: "Included" },
  { value: "optional", label: "Optional" },
  { value: "excluded", label: "Excluded" },
  { value: "needs-clarification", label: "Needs clarification" }
]);
function Ke(e) {
  (!e || !D(e.id) || e.version !== 1 || e.kind !== "scope-packages" || !D(e.title) || !D(e.disclaimer) || !Array.isArray(e.options) || e.options.length !== 2) && x("Choose two approved demonstration scope packages with a clear source and disclaimer.");
  const i = { id: D(e.id), version: 1, kind: "scope-packages", title: D(e.title), disclaimer: D(e.disclaimer), context: W(e.context), options: e.options.map((t) => ((!D(t.id) || !D(t.title) || !D(t.description) || !["available", "withdrawn"].includes(t.status) || !Ti(t.requestItemIds) || !Array.isArray(t.facts) || t.facts.length > 8 || t.facts.some((o) => !D(o.label) || !D(o.value))) && x("Each approved package needs an identity, description, availability and source-linked details."), { id: D(t.id), title: D(t.title), description: D(t.description), status: t.status, facts: t.facts.map((o) => ({ label: D(o.label), value: D(o.value) })), requestItemIds: [...t.requestItemIds] })) };
  return (i.options[0].id === i.options[1].id || [i.id, i.title, i.disclaimer, ...i.options.flatMap((t) => [t.id, t.title, t.description, ...t.facts.flatMap((o) => [o.label, o.value])])].some((t) => t.length > 2e3)) && x("Keep package identities distinct and descriptions concise."), i;
}
function Ei(e, i) {
  Si(e);
  const t = Ke(i);
  y(t.context, e.context) || x("Approved packages must retain the original inquiry product and release.");
  const o = new Set((e.inquiry.requestItems || []).map((n) => n.id));
  if (t.options.some((n) => n.requestItemIds.some((r) => !o.has(r))) && x("A package refers to a detail outside this inquiry."), e.approvedOptionSet) throw new h("CONFLICT", "This project already has an immutable approved package comparison.");
  return Y({ kind: "option-set", projectId: e.id, projectRevision: e.revision, optionSet: t });
}
function ct(e, i) {
  if (Si(e), !e.approvedOptionSet) throw new h("UNSUPPORTED_OPTIONS", "No approved package comparison is available for this project.");
  const t = Ke(e.approvedOptionSet), o = i?.choice, n = D(i?.notes), r = o === "help-me-decide" ? null : D(i?.optionId);
  if (["option", "help-me-decide"].includes(o) || x("Choose a package or ask for help deciding.", { choice: "Choose a preference before reviewing." }), n.length > 2e3 && x("Keep the preference note within 2,000 characters.", { notes: "Shorten your note." }), o === "option" && !t.options.some((s) => s.id === r && s.status === "available") && x("This package is missing or withdrawn. Choose an available package.", { optionId: "Choose an available package." }), !y(t.context, e.context)) throw new h("STALE_REVIEW", "The approved package source no longer matches this inquiry.");
  return Y({ kind: "option-preference", projectId: e.id, projectRevision: e.revision, optionSetId: t.id, optionSetVersion: t.version, choice: o, optionId: r, notes: n, context: I(e.context) });
}
function ki(e, i) {
  return [
    ...(e.inquiry.requestItems || []).map((t) => ({ id: `request:${t.id}`, requestItemId: t.id, context: I(t.context) })),
    ...i ? [{ id: "preference", requestItemId: null, context: I(e.context) }] : []
  ];
}
function Cn(e, i) {
  if (!e.approvedOptionSet) return;
  const t = e.optionPreferences?.at(-1) || null;
  return { optionSet: I(e.approvedOptionSet), preference: I(t), entries: ki(e, t).map((o) => ({ ...o, disposition: "needs-clarification", lineIds: [], rationale: "" })) };
}
function xi(e) {
  (!e || !Array.isArray(e.entries) || e.entries.length > 13) && x("Keep every scope decision attached to its original request.");
  const i = Ke(e.optionSet), t = e.preference === null ? null : I(e.preference);
  t !== null && (!t?.id || !Number.isSafeInteger(t.version) || !["option", "help-me-decide"].includes(t.choice)) && x("The quotation preference snapshot is invalid.");
  const o = e.entries.map((n) => ((!D(n.id) || n.requestItemId !== null && !D(n.requestItemId) || !Pn.some((r) => r.value === n.disposition) || !Ti(n.lineIds) || n.lineIds.length > 30 || D(n.rationale).length > 2e3) && x("Check the scope disposition, linked lines and explanation."), { id: D(n.id), requestItemId: n.requestItemId, context: W(n.context), disposition: n.disposition, lineIds: [...n.lineIds], rationale: D(n.rationale) }));
  return new Set(o.map((n) => n.id)).size !== o.length && x("Each requested detail needs exactly one scope decision."), { optionSet: i, preference: t, entries: o };
}
function Qe(e, i, { requireResolved: t = !0, current: o = !0 } = {}) {
  const n = {};
  if (!e.approvedOptionSet && !i.scopeSelection) return n;
  if (!i.scopeSelection || !e.approvedOptionSet) return { scopeSelection: "This adapter must retain the approved comparison and quote scope metadata." };
  let r;
  try {
    r = xi(i.scopeSelection);
  } catch (a) {
    return { scopeSelection: a.message };
  }
  y(r.optionSet, e.approvedOptionSet) || (n.scopeSelection = "The approved package snapshot changed. Reopen the project.");
  const s = r.preference;
  s && !(e.optionPreferences || []).some((a) => y(a, s)) && (n.scopeSelection = "The preference does not match a confirmed event in this project."), o && !y(s, e.optionPreferences?.at(-1) || null) && (n.scopeSelection = "Review and explicitly adopt the latest customer preference before issuing this quotation."), t && !s && (n.scopeSelection = "Wait for a confirmed preference or Help me decide before issuing the scoped quotation.");
  const d = ki(e, s), l = new Set((i.values?.lineItems || i.lineItems || []).map((a) => a.id));
  (r.entries.length !== d.length || d.some((a) => !r.entries.some((c) => c.id === a.id && c.requestItemId === a.requestItemId && y(c.context, a.context)))) && (n.scopeSelection = "Keep every original requested detail and its exact source in the quotation.");
  for (const a of r.entries) {
    const c = `scopeSelection.entries.${a.id}`;
    a.lineIds.some((u) => !l.has(u)) ? n[c] = "A linked quote line was removed. Choose its replacement or explicitly change this scope decision." : ["included", "optional"].includes(a.disposition) && !a.lineIds.length ? n[c] = "Link at least one quotation line to this scope decision." : ["excluded", "needs-clarification"].includes(a.disposition) && a.lineIds.length ? n[c] = "An excluded or unresolved request cannot be included through a quotation line." : a.disposition === "excluded" && !a.rationale ? n[c] = "Explain why this request is excluded." : t && a.disposition === "needs-clarification" && (n[c] = "Resolve this requested detail or explicitly exclude it with an explanation before issuing.");
  }
  return n;
}
function jn(e, i) {
  const t = Qe(e, i, { requireResolved: !1 });
  if (t.scopeSelection) throw new h("SCOPE_REVIEW_REQUIRED", t.scopeSelection, { scopeSelection: t.scopeSelection });
}
function Ln(e, i = []) {
  if (!e.approvedOptionSet) {
    (e.optionSetApproval || e.optionPreferences?.length || e.quotes.some((r) => r.scopeSelection) || i.some((r) => r.scopeSelection)) && x("Scope history has no approved comparison.");
    return;
  }
  const t = Ke(e.approvedOptionSet), o = e.optionSetApproval;
  (!y(t, e.approvedOptionSet) || !y(t.context, e.context) || !o || !Number.isSafeInteger(o.projectRevision) || o.projectRevision < 2 || o.projectRevision > e.revision || !Mt(o.createdAt)) && x("The approved comparison has invalid provenance.");
  const n = P({ ...JSON.parse(o.reviewToken), token: o.reviewToken }, "option-set");
  (n.projectId !== e.id || n.projectRevision !== o.projectRevision - 1 || !y(n.optionSet, t)) && x("The approved comparison changed after confirmation."), Ei({ ...e, approvedOptionSet: void 0 }, t), Array.isArray(e.optionPreferences) || x("The preference history is missing.");
  for (const [r, s] of e.optionPreferences.entries()) {
    (!s.id || s.version !== r + 1 || s.projectId !== e.id || !Number.isSafeInteger(s.projectRevision) || s.projectRevision <= o.projectRevision || s.projectRevision > e.revision || !Mt(s.createdAt) || r && s.projectRevision <= e.optionPreferences[r - 1].projectRevision) && x("Preference history is invalid.");
    const d = ct({ ...e, revision: s.projectRevision - 1 }, s), l = P({ ...JSON.parse(s.reviewToken), token: s.reviewToken }, "option-preference");
    (!y(d, { ...l, token: s.reviewToken }) || !y({ ...l, id: s.id, version: s.version, projectRevision: s.projectRevision, createdAt: s.createdAt, reviewToken: s.reviewToken, kind: void 0 }, { ...s, kind: void 0 })) && x("A confirmed preference snapshot changed.");
  }
  new Set(e.optionPreferences.map((r) => r.id)).size !== e.optionPreferences.length && x("Preference identities must remain unique.");
  for (const r of e.quotes) {
    if (!r.scopeSelection) {
      r.source === "seller-demo" && r.issuedProjectRevision > o.projectRevision && x("An issued quotation lost its scope metadata.");
      continue;
    }
    const s = Qe(e, r, { current: !1 }), d = e.optionPreferences.filter((a) => a.projectRevision < r.issuedProjectRevision).at(-1) || null;
    y(r.scopeSelection.preference, d) || x("An issued quotation did not retain the preference current at its review."), (Object.keys(s).length || r.scopeSelection.preference.projectRevision >= r.issuedProjectRevision) && x("An issued quotation changed its reviewed scope.");
    const l = P({ ...JSON.parse(r.reviewToken), token: r.reviewToken }, "issue-quote");
    y(l.draft.scopeSelection, r.scopeSelection) || x("An issued scope snapshot differs from its review.");
  }
  for (const r of i)
    if (r.scopeSelection) {
      const s = Qe(e, r, { current: !1, requireResolved: !1 });
      s.scopeSelection && x(s.scopeSelection);
    } else r.projectRevision >= o.projectRevision && x("A scoped quotation draft lost its comparison metadata.");
}
function Vn({ read: e, change: i, findProject: t, now: o, makeId: n }) {
  return {
    supportsOptionScope: !0,
    async approveOptionSet(r, { confirmed: s = !1 } = {}) {
      if (!s) throw new h("CONFIRMATION_REQUIRED", "Review the comparison and explicitly confirm the approved packages.");
      const d = P(r, "option-set");
      return i((l) => {
        const a = t(l, d.projectId);
        if (a.optionSetApproval?.reviewToken === r.token) return a;
        if (a.revision !== d.projectRevision) throw new h("STALE_REVIEW", "The project changed. Review the package sources again.");
        if (!y(Ei(a, d.optionSet), r)) throw new h("STALE_REVIEW", "The comparison changed after review.");
        const c = o();
        return a.approvedOptionSet = I(d.optionSet), a.optionSetApproval = { projectRevision: a.revision + 1, createdAt: c, reviewToken: r.token }, a.optionPreferences = [], a.revision++, a.updatedAt = c, a;
      });
    },
    async reviewOptionPreference(r, s) {
      return ct(t(e().store, r), s);
    },
    async confirmOptionPreference(r, { confirmed: s = !1 } = {}) {
      if (!s) throw new h("CONFIRMATION_REQUIRED", "Review your preference and explicitly confirm it.");
      const d = P(r, "option-preference");
      return i((l) => {
        const a = t(l, d.projectId);
        if ((a.optionPreferences || []).some((A) => A.reviewToken === r.token)) return a;
        if (a.revision !== d.projectRevision || !y(ct(a, d), r)) throw new h("STALE_REVIEW", "The project or available packages changed. Review your preference again.");
        const { kind: c, ...u } = d, g = o();
        return a.optionPreferences = [...a.optionPreferences || [], { ...u, id: n("PREFERENCE"), version: (a.optionPreferences || []).length + 1, projectRevision: a.revision + 1, createdAt: g, reviewToken: r.token }], a.revision++, a.updatedAt = g, a;
      });
    }
  };
}
const $n = { "question-add": wt, "question-reply": gt, "question-resolution": It, "question-reopen": yt };
function Un({ read: e, change: i, findProject: t, now: o, makeId: n }) {
  const r = (s, d, { confirmed: l = !1 } = {}) => {
    if (!l) throw new h("CONFIRMATION_REQUIRED", "Review the exact question and explicitly confirm this action.");
    const a = P(d, s);
    return i((c) => {
      const u = t(c, a.projectId);
      if (u.questions?.some((v) => v.events.some((f) => f.reviewToken === d.token))) return u;
      if (u.revision !== a.projectRevision || !y($n[s](u, { ...a, kind: a.action }), d))
        throw new h("STALE_REVIEW", "The project or question changed after review. Your input is still available; reopen the latest question and review again.");
      const g = o();
      let A;
      s === "question-add" ? (A = {
        id: n("QUESTION"),
        projectId: u.id,
        requestItemId: a.requestItemId,
        requestItem: I(a.requestItem),
        context: I(a.context),
        body: a.body,
        blocking: a.blocking,
        scopeEntryId: a.scopeEntryId,
        createdAt: g,
        events: []
      }, u.questionPolicy ||= { version: 1 }, u.questions ||= [], u.questions.push(A)) : A = u.questions.find((v) => v.id === a.questionId);
      const R = {
        id: n("QUESTION-EVENT"),
        questionId: A.id,
        version: A.events.length + 1,
        kind: a.action || "opened",
        authorRole: a.authorRole,
        body: a.body,
        projectRevision: u.revision + 1,
        createdAt: g,
        reviewToken: d.token
      };
      return A.events.push(R), u.questionEventIndex ||= [], u.questionEventIndex.push({ id: R.id, questionId: A.id, projectRevision: R.projectRevision }), u.revision++, u.updatedAt = g, u;
    });
  };
  return {
    supportsQuestions: !0,
    async reviewQuestion(s, d) {
      return wt(t(e().store, s), d);
    },
    async reviewQuestionReply(s, d) {
      return gt(t(e().store, s), d);
    },
    async reviewQuestionResolution(s, d) {
      return It(t(e().store, s), d);
    },
    async reviewQuestionReopen(s, d) {
      return yt(t(e().store, s), d);
    },
    async confirmQuestion(s, d) {
      return r("question-add", s, d);
    },
    async confirmQuestionReply(s, d) {
      return r("question-reply", s, d);
    },
    async confirmQuestionResolution(s, d) {
      return r("question-resolution", s, d);
    },
    async confirmQuestionReopen(s, d) {
      return r("question-reopen", s, d);
    }
  };
}
const Ye = (e) => JSON.parse(JSON.stringify(e));
function _n(e, i = {}) {
  const t = Ye(e);
  return delete t.reviewToken, {
    productId: e.productId,
    productTitle: e.content.title,
    modelId: e.content.modelId,
    modelRevision: e.modelRevision,
    roomReleaseId: e.id,
    inquiryProfileVersion: e.inquiryProfile.version,
    inquiryProfile: Ye(e.inquiryProfile),
    roomSnapshot: t,
    ...Ye(i)
  };
}
function Fn({
  drawing: e,
  sheetId: i,
  regionId: t,
  modelRevision: o,
  model: n = {},
  presentationSnapshot: r
}) {
  if (!o?.trim())
    throw new TypeError("An exact prepared model revision is required.");
  const s = At(e, { modelRevision: o });
  if (s.modelRevision !== o)
    throw new TypeError(
      "The drawing and prepared model versions do not match."
    );
  let d;
  if (r !== void 0 && (d = Rt(r), (d && zi(d, s))?.some((b) => b.severity !== "warning")))
    throw new TypeError("The overview does not match this drawing source or its confirmed associations.");
  const l = s.sheets.filter((q) => !i || q.id === i).flatMap(
    (q) => q.regions.filter((b) => b.id === t).map((b) => ({ sheet: q, region: b }))
  );
  if (l.length !== 1)
    throw new TypeError("Select one available detail on a drawing sheet.");
  const { sheet: a, region: c } = l[0], { asset: u } = gn(s, a.id, c.id);
  if (c.mappingStatus !== "confirmed")
    throw new TypeError(
      "Confirm this drawing association before starting an inquiry."
    );
  if (n.parts && !n.parts.some((q) => q.id === c.partId))
    throw new TypeError("This detail is not linked to an available part.");
  const g = n.title || s.title, A = n.shortTitle || g, R = n.parts?.find((q) => q.id === c.partId)?.title || c.partId, v = s.statusLabel || "Reference drawing · unreviewed", f = s.statusNote || "Reference drawing only. Manufacturing tolerances and approval have not been supplied.", w = {
    id: "drawing-detail-inquiry",
    version: "drawing-detail-inquiry-v1",
    fields: Me.fields.map((q) => ({
      ...q,
      enabled: !["stroke", "load"].includes(q.id),
      ...q.id === "application" ? {
        label: "Question or application",
        hint: "Describe what needs review. The selected drawing detail stays attached."
      } : {},
      ...q.id === "notes" ? {
        label: "Requirements to discuss",
        hint: "Add required material, tolerances or other details. Nothing is inferred from viewed geometry."
      } : {}
    }))
  }, p = {
    id: `drawing-preview:${s.id}:${s.revision}:${u.sha256}:${s.mappingRevision}`,
    productId: s.modelId,
    modelRevision: o,
    version: 1,
    source: "bundled",
    createdAt: "2026-11-01T00:00:00.000Z",
    inquiryProfile: w,
    content: {
      id: s.modelId,
      modelId: s.modelId,
      title: g,
      shortTitle: A,
      eyebrow: "3D / Drawings preview",
      tagline: "One part. The same drawing reference.",
      description: `${v}. ${f}`,
      summary: c.note || "A selected detail links the prepared model to its pinned source drawing.",
      demoNotice: "Fictional inquiry saved in this browser. Nothing is sent to a manufacturer.",
      roomRevision: "drawing-preview-room-v1",
      source: {
        label: "Paired STEP and drawing source",
        author: n.sourceLabel || "Published source",
        license: n.attribution || "See source attribution",
        url: s.sourceURL,
        note: f
      },
      highlights: [{ label: "Drawing status", value: v }],
      specGroups: [
        {
          id: "drawing-reference",
          title: "Drawing reference",
          facts: [
            {
              label: "Status",
              value: v,
              source: "Published source drawing and review"
            },
            {
              label: "Source version",
              value: s.revisionLabel || s.revision,
              source: "Pinned document version; not a manufacturer-issued revision"
            },
            {
              label: "Association version",
              value: s.mappingRevision,
              source: "Authored part and drawing associations"
            }
          ]
        }
      ],
      questions: [],
      documents: [
        {
          id: s.id,
          title: s.title,
          revision: s.revision,
          assetId: u.id,
          description: f,
          type: "Reference drawing",
          nodeId: c.partId
        }
      ],
      partContent: [
        {
          nodeId: c.partId,
          title: R,
          description: c.note || "The selected detail is linked to this source part.",
          documentIds: [s.id]
        }
      ]
    }
  }, m = _n(p, {
    part: { id: c.partId, title: R },
    drawing: {
      id: s.id,
      title: s.title,
      revision: s.revision,
      ...s.revisionLabel ? { revisionLabel: s.revisionLabel } : {},
      assetId: u.id,
      assetRevision: u.sha256,
      partId: c.partId,
      sheetId: a.id,
      sheetTitle: a.title,
      regionId: c.id,
      regionLabel: c.label,
      sourceURL: s.sourceURL,
      ...e.schemaVersion === 2 ? { mappingRevision: s.mappingRevision } : {},
      ...r !== void 0 ? {
        presentationSnapshot: d,
        ...d ? { presentationRevision: d.revision } : {}
      } : {}
    }
  });
  return nt(m, "drawing-context-validation").context;
}
const ae = (e) => typeof e == "string" ? e.trim() : "", O = (e) => {
  throw new h("IMPACT_REVIEW_REQUIRED", e);
}, we = (e) => e?.drawing ? de(e) : null, Wn = (e, i) => e?.drawing && i?.drawing && y([e.modelId, e.modelRevision, ...Ue(e)], [i.modelId, i.modelRevision, ...Ue(i)]), lt = (e) => Number.isSafeInteger(e) && e > 0, Kt = (e) => typeof e == "string" && Number.isFinite(Date.parse(e)), Qn = ["question", "scope"];
function Oi(e) {
  return [
    ...(e.inquiry.requestItems || []).map((i) => ({ id: `scope:request:${i.id}`, kind: "scope", recordId: i.id, label: i.context.drawing?.regionLabel || i.context.part?.title || "Requested scope", originalContext: I(i.context) })),
    ...(e.questions || []).map((i) => ({ id: `question:${i.id}`, kind: "question", recordId: i.id, label: i.body, originalContext: I(i.context) }))
  ];
}
function Tt(e, i = e.revision) {
  const t = /* @__PURE__ */ new Map();
  for (const o of e.impactReviews || [])
    if (!(o.projectRevision > i))
      for (const n of o.review.decisions) {
        const r = o.review.findings.find((s) => s.id === n.id);
        t.set(r.id, {
          ...I(Object.fromEntries(["id", "kind", "recordId", "label", "originalContext"].map((s) => [s, r[s]]))),
          context: I(n.context),
          decision: n.decision,
          reason: n.reason,
          lineIds: I(n.lineIds),
          reviewId: o.id,
          reviewedProjectRevision: o.projectRevision,
          authorRole: "seller"
        });
      }
  return [...t.values()];
}
function Et(e) {
  if (!e.impactPolicy) return;
  const i = e.impactReviews.at(-1);
  return { version: 1, reviewId: i.id, projectRevision: i.projectRevision, entries: Tt(e) };
}
function Jt(e, i) {
  const t = e?.packageSnapshot;
  return (!t || e.modelId !== i.modelId || e.modelRevision !== i.modelRevision || e.productId !== i.productId) && O("Review a published source for this exact product and model version. A changed CAD model needs a separately compatible capture."), t.sheets.flatMap((o) => o.regions.map((n) => {
    const r = Fn({
      drawing: t,
      sheetId: o.id,
      regionId: n.id,
      modelRevision: e.modelRevision,
      model: {
        id: i.modelId,
        title: i.productTitle || i.roomSnapshot?.content.title || t.title,
        shortTitle: i.roomSnapshot?.content.shortTitle || i.productTitle || t.title,
        parts: e.partIds.map((s) => ({ id: s, title: i.part?.id === s ? i.part.title : s }))
      },
      ...e.presentationSnapshot !== void 0 ? { presentationSnapshot: I(e.presentationSnapshot) } : {}
    });
    return Oe(r, e);
  }));
}
function je(e, i, t, o) {
  (!e.context?.drawing || !o || o.projectId !== e.id || o.revision < 1) && O("Prepare and save the quotation draft before reviewing a source change and its affected scope.");
  const n = Jt(t, e.context), r = i?.context ? Oe(i.context, t) : n.find((a) => a.drawing.regionId === G(e).drawing.regionId) || n[0];
  r || O("This published source has no confirmed detail to review.");
  const s = G(e), d = new Map(Tt(e).map((a) => [a.id, a])), l = [];
  for (const a of Oi(e)) {
    const c = d.get(a.id), u = c ? c.context : a.originalContext;
    if (!u?.drawing || u.productId !== t.productId || u.modelId !== t.modelId || u.drawing.id !== t.packageSnapshot.id) continue;
    const g = Jt(t, u).filter((m) => m.part.id === u.part.id), A = a.kind === "scope" && c && c.lineIds.some((m) => !o.values.lineItems.some((q) => q.id === m)), R = c && e.impactReviews?.find((m) => m.id === c.reviewId), v = c?.decision === "retained" && y(R?.review.release, t);
    if ((g.some((m) => we(m) === we(u)) || v) && !A) continue;
    const f = g.filter((m) => m.drawing.sheetId === u.drawing.sheetId && m.drawing.regionId === u.drawing.regionId), w = g.length ? f.length === 1 ? "changed" : "ambiguous" : "missing", p = f.length === 1 ? f[0] : null;
    l.push({
      ...a,
      fromContext: I(u),
      candidateContext: p,
      candidates: g,
      classification: w,
      reason: A ? "A previously reviewed quotation line was removed. Confirm the current scope-to-line association." : w === "changed" ? "The source or association edition changed. Inspect the new detail before using it." : w === "missing" ? "No confirmed detail for this part is available in the selected source." : "The saved detail has no unique matching sheet and region. Choose and inspect the replacement manually.",
      lineIds: I(c?.lineIds || o.scopeSelection?.entries.find((m) => m.requestItemId === a.recordId)?.lineIds || [])
    });
  }
  return !l.length && we(s) === we(r) && O("This source has no changed dependent references to review."), {
    kind: "drawing-impact-proposal",
    projectId: e.id,
    projectRevision: e.revision,
    fromContext: I(s),
    context: I(r),
    release: I(t),
    quoteDraft: I(o),
    findings: l
  };
}
function ut(e, i, t) {
  const o = ae(i?.note);
  (!o || o.length > 2e3) && O("Explain why this project should use the reviewed source in 1–2,000 characters."), (!Array.isArray(i?.decisions) || i.decisions.length !== e.findings.length || new Set(i.decisions.map((s) => s.id)).size !== i.decisions.length) && O("Review every affected question and quotation scope once.");
  const n = new Set(e.quoteDraft.values.lineItems.map((s) => s.id)), r = e.findings.map((s) => {
    const d = i.decisions.find((g) => g.id === s.id), l = d?.decision, a = ae(d?.reason);
    (!["confirmed", "retained", "omitted"].includes(l) || !a || a.length > 2e3) && O("Choose an outcome and give a reason for each affected reference."), l === "omitted" && s.kind !== "scope" && O("Keep a question’s source history; a question cannot be omitted by a source change.");
    let c = l === "retained" ? s.fromContext : l === "confirmed" ? Oe(d.context, e.release) : null;
    c && (c.modelId !== s.originalContext.modelId || c.modelRevision !== s.originalContext.modelRevision || c.part.id !== s.originalContext.part.id) && O("The reviewed detail must belong to the same saved part and model version.");
    const u = Array.isArray(d.lineIds) ? [...d.lineIds] : [];
    return (new Set(u).size !== u.length || u.some((g) => !n.has(g)) || s.kind === "scope" && l !== "omitted" && !u.length || (s.kind === "question" || l === "omitted") && u.length) && O("Link each retained or adopted scope to valid quotation lines; omitted scope has no quoted lines."), { id: s.id, decision: l, context: I(c), reason: a, lineIds: u, authorRole: "seller" };
  });
  return Y({ ...I(e), kind: "drawing-impact", note: o, decisions: r, reviewedAt: t });
}
function Ni(e) {
  (!e || e.version !== 1 || !ae(e.reviewId) || !lt(e.projectRevision) || !Array.isArray(e.entries) || e.entries.length > 64 || new Set(e.entries.map((i) => i.id)).size !== e.entries.length) && O("Keep the quotation’s reviewed drawing references and individual decisions intact.");
  for (const i of e.entries)
    (!Qn.includes(i.kind) || i.id !== (i.kind === "question" ? `question:${i.recordId}` : `scope:request:${i.recordId}`) || !ae(i.label) || i.authorRole !== "seller" || !ae(i.reason) || !ae(i.reviewId) || !lt(i.reviewedProjectRevision) || i.reviewedProjectRevision > e.projectRevision || !["confirmed", "retained", "omitted"].includes(i.decision) || !Array.isArray(i.lineIds) || new Set(i.lineIds).size !== i.lineIds.length || (i.decision === "omitted" ? i.context !== null || i.kind !== "scope" || i.lineIds.length : !i.context)) && O("A reviewed drawing reference is incomplete."), (!y(W(i.originalContext), i.originalContext) || i.context && !y(W(i.context), i.context)) && O("A reviewed source identity changed.");
  return I(e);
}
function Te(e, i, { current: t = !0, requireLines: o = !0 } = {}) {
  if (!e.impactPolicy) return i.impactScope ? { impactScope: "This project has no confirmed source impact review." } : {};
  if (!i.impactScope) return { impactScope: "Review and apply the affected drawing references before issuing this quotation." };
  const n = {};
  let r;
  try {
    r = Ni(i.impactScope);
  } catch (a) {
    return { impactScope: a.message };
  }
  const s = e.impactReviews.find((a) => a.id === r.reviewId), d = s ? { version: 1, reviewId: s.id, projectRevision: s.projectRevision, entries: Tt(e, s.projectRevision) } : null;
  if ((!y(d, r) || t && !y(Et(e), r)) && (n.impactScope = "The quotation must use the exact confirmed source-impact decisions. Review the latest evidence."), t && o) {
    const a = G(e), c = new Set(r.entries.map((u) => u.id));
    for (const u of Oi(e)) u.originalContext.drawing?.id === a.drawing?.id && !c.has(u.id) && !Wn(u.originalContext, a) && (n[`impactScope.${u.id}`] = "This new record still refers to an earlier drawing. Review its source impact before issuing this quotation.");
  }
  const l = new Set((i.values?.lineItems || i.lineItems || []).map((a) => a.id));
  for (const a of r.entries) o && a.kind === "scope" && a.decision !== "omitted" && (!a.lineIds.length || a.lineIds.some((c) => !l.has(c))) && (n[`impactScope.${a.id}`] = "A reviewed scope lost its quoted line. Review the source impact again.");
  return n;
}
function zn(e, i) {
  const t = Te(e, i, { requireLines: !1 });
  if (Object.keys(t).length) throw new h("IMPACT_REVIEW_REQUIRED", "Review the drawing impact before saving or issuing this quotation.", t);
}
function Di(e, i = []) {
  if (!e.impactPolicy) {
    (e.impactReviews !== void 0 || e.impactReviewIndex !== void 0 || [...e.quotes, ...i].some((s) => s.impactScope !== void 0)) && O("Drawing-impact evidence requires its reviewed project history.");
    return;
  }
  (!y(e.impactPolicy, { version: 1 }) || !Array.isArray(e.impactReviews) || !e.impactReviews.length || e.impactReviews.length > 40) && O("The source-impact review history is incomplete."), y(e.impactReviewIndex, e.impactReviews.map((s) => ({ id: s.id, projectRevision: s.projectRevision, reviewToken: s.reviewToken }))) || O("The source-impact history index identifies a missing or changed review.");
  let t = 0;
  const o = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set();
  for (const s of e.impactReviews) {
    (!ae(s.id) || o.has(s.id) || n.has(s.reviewToken) || !lt(s.projectRevision) || s.projectRevision <= t || s.projectRevision > e.revision || !Kt(s.createdAt)) && O("The source-impact review order is invalid.");
    const d = P({ ...s.review, token: s.reviewToken }, "drawing-impact");
    (s.projectRevision !== d.projectRevision + 1 || d.projectId !== e.id || !Kt(d.reviewedAt)) && O("The source-impact receipt does not match this project."), y(d.fromContext, We(e, d.projectRevision)) || O("The impact review started from a different project source.");
    const l = {
      ...I(e),
      revision: d.projectRevision,
      impactReviews: e.impactReviews.filter((c) => c.projectRevision < s.projectRevision),
      questions: (e.questions || []).filter((c) => c.events[0].projectRevision <= d.projectRevision).map((c) => ({ ...I(c), events: c.events.filter((u) => u.projectRevision <= d.projectRevision) })),
      activeDrawingContext: I(d.fromContext)
    }, a = je(l, d, d.release, d.quoteDraft);
    y(ut(a, d, d.reviewedAt), { ...d, token: s.reviewToken }) || O("A source-impact decision changed after review."), we(d.fromContext) !== we(d.context) && !e.drawingRevisions?.some((c) => c.reviewToken === s.reviewToken && c.projectRevision === s.projectRevision && y(c.context, d.context)) && O("The source-impact adoption lost its drawing-reference receipt."), o.add(s.id), n.add(s.reviewToken), t = s.projectRevision;
  }
  const r = e.impactReviews[0].projectRevision;
  for (const s of e.quotes) {
    if (!s.impactScope && s.issuedProjectRevision < r) continue;
    (!s.impactScope || s.impactScope.projectRevision >= s.issuedProjectRevision || Object.keys(Te(e, s, { current: !1 })).length) && O("An issued quotation lost its reviewed source-impact snapshot.");
    const d = P({ ...JSON.parse(s.reviewToken), token: s.reviewToken }, "issue-quote");
    y(d.draft.impactScope, s.impactScope) || O("Issued drawing-impact evidence differs from its quotation review.");
    const l = {
      ...e,
      revision: s.issuedProjectRevision - 1,
      activeDrawingContext: We(e, s.issuedProjectRevision - 1),
      impactReviews: e.impactReviews.filter((c) => c.projectRevision < s.issuedProjectRevision),
      questions: (e.questions || []).filter((c) => c.events[0].projectRevision < s.issuedProjectRevision)
    };
    Object.keys(Te(l, s)).length && O("An issued quotation contains a source-dependent record that was not individually reviewed.");
    const a = e.impactReviews.filter((c) => c.projectRevision < s.issuedProjectRevision).at(-1);
    s.impactScope.reviewId !== a.id && O("An issued quotation used obsolete source-impact evidence.");
  }
  for (const s of i) (s.impactScope && Object.keys(Te(e, s, { current: !1, requireLines: !1 })).length || !s.impactScope && s.projectRevision >= r) && O("A saved quotation lost its source-impact evidence.");
}
function Mn({ read: e, change: i, findProject: t, now: o, makeId: n, drawingRelease: r, sellerProjection: s, enabled: d }) {
  const l = () => {
    if (!d) throw new h("UNSUPPORTED_IMPACT", "This adapter has not opted into reviewed drawing-impact references.");
  };
  return {
    supportsDrawingImpact: d,
    async proposeDrawingImpact(a, c) {
      l();
      const u = await r(c), { store: g } = e(), A = t(g, a);
      return je(A, c, u, g.quoteDrafts.find((R) => R.projectId === a));
    },
    async reviewDrawingImpact(a, c) {
      l();
      const u = await r(c), { store: g } = e(), A = t(g, a), R = g.quoteDrafts.find((v) => v.projectId === a);
      if (c.projectRevision !== A.revision || !y(c.quoteDraft, R)) throw new h("STALE_REVIEW", "The project or quotation changed while you inspected this source. Keep your decisions and check the latest impact again.");
      return ut(je(A, c, u, R), c, o());
    },
    async confirmDrawingImpact(a, { confirmed: c = !1 } = {}) {
      if (l(), !c) throw new h("CONFIRMATION_REQUIRED", "Review each affected reference and explicitly confirm the source change.");
      const u = P(a, "drawing-impact"), g = await r(u);
      return i((A) => {
        const R = t(A, u.projectId);
        if (R.impactReviews?.some((m) => m.reviewToken === a.token)) return s(A, R);
        const v = A.quoteDrafts.find((m) => m.projectId === R.id);
        if (R.revision !== u.projectRevision || !y(v, u.quoteDraft)) throw new h("STALE_REVIEW", "The project or quotation draft changed after impact review. Check the latest source impact before applying your decisions.");
        const f = ut(je(R, u, g, v), u, u.reviewedAt);
        if (!y(f, a)) throw new h("STALE_REVIEW", "The exact source or impact decisions changed after review. Review them again.");
        const w = o(), p = R.revision + 1;
        return de(u.fromContext) !== de(u.context) && (R.activeDrawingContext = I(u.context), R.drawingRevisions ||= [], R.drawingRevisions.push({ id: n("DRAWING-ADOPTION"), status: "adopted", projectRevision: p, fromContext: I(u.fromContext), context: I(u.context), release: I(g), note: u.note, quoteDraftAction: "keep", reviewedAt: u.reviewedAt, createdAt: w, reviewToken: a.token })), R.impactPolicy ||= { version: 1 }, R.impactReviews ||= [], R.impactReviews.push({ id: n("IMPACT"), projectRevision: p, createdAt: w, reviewToken: a.token, review: I(u) }), R.impactReviewIndex ||= [], R.impactReviewIndex.push({ id: R.impactReviews.at(-1).id, projectRevision: p, reviewToken: a.token }), R.revision = p, R.updatedAt = w, v.context = I(u.context), v.projectRevision = p, v.impactScope = Et(R), v.revision++, v.updatedAt = w, Di(R, [v]), s(A, R);
      });
    }
  };
}
const T = (e) => typeof e == "string" ? e.trim() : "", ie = (e) => /^\d+(\.\d{1,2})?$/.test(e) && Number.isFinite(+e) && +e <= 1e8, Gt = (e) => Math.round((e + Number.EPSILON) * 100) / 100, Ht = (e) => T(e).split(`
`).map(T).filter(Boolean);
function pt(e) {
  return Array.isArray(e) ? `[${e.map(pt).join(",")}]` : e && typeof e == "object" ? `{${Object.keys(e).sort().map((i) => `${JSON.stringify(i)}:${pt(e[i])}`).join(",")}}` : JSON.stringify(e);
}
const Je = (e) => ({ ...I(e), token: pt(e) }), Kn = (e) => T(e?.context?.productTitle) || T(e?.context?.part?.title) || "Product", Ne = (e) => {
  if (!e?.id || !Number.isSafeInteger(e.revision)) throw new h("VALIDATION", "Open a saved customer project first.");
}, Jn = (e, i) => {
  const t = Number.isFinite(e.quantity) && e.quantity > 0, o = e.unitPrice ?? (e.unitPrice === void 0 && t && Number.isFinite(e.amount) ? e.amount / e.quantity : null);
  return { id: e.id || `line-${i + 1}`, label: e.label, quantity: t ? String(e.quantity) : "", unitPrice: o === null ? "" : String(o) };
};
function Be(e, i) {
  Ne(e);
  const t = e.quotes.at(-1), o = ke(e), n = e.changes.filter((r) => r.quoteId === t?.id).at(-1) || o;
  return {
    id: i,
    revision: 0,
    projectId: e.id,
    projectRevision: e.revision,
    previousQuoteId: t?.id || null,
    changeId: n?.id || null,
    ...e.approvedOptionSet ? { scopeSelection: t?.scopeSelection ? I(t.scopeSelection) : Cn(e) } : {},
    ...e.questionPolicy ? { questionScope: t ? I(t.questionScope || { version: 1, projectRevision: t.issuedProjectRevision || 1, questions: [] }) : Vi(e) } : {},
    ...e.impactPolicy ? { impactScope: Et(e) } : {},
    ...e.context.drawing || e.context.inspection || e.context.viewerReference ? { context: I(G(e)) } : {},
    replyDraft: o ? { kind: "change-response", body: "", changeId: o.id, resolutions: $e(o).map((r) => ({ topic: r, status: "needs-info", response: "" })) } : null,
    values: {
      quantity: String(t?.quantity ?? e.inquiry.values.quantity),
      scope: t?.scope || e.inquiry.values.application,
      proposedLeadTime: t?.proposedLeadTime || "To be confirmed after technical review",
      assumptions: t?.assumptions.join(`
`) || `Application suitability, load and mounting require engineering review.
Fictional demonstration only; not a manufacturer offer.`,
      exclusions: (t?.exclusions || ["Freight, tax and application-specific engineering remain unpriced."]).join(`
`),
      validity: t?.validity || "To be agreed",
      lineItems: t ? t.lineItems.map(Jn) : [
        { id: "assembly", label: `${Kn(e)} — illustrative allowance`, quantity: e.inquiry.values.quantity, unitPrice: "" },
        { id: "setup", label: "Setup allowance", quantity: "1", unitPrice: "" },
        { id: "freight", label: "Freight and applicable tax", quantity: "1", unitPrice: "" }
      ]
    },
    updatedAt: null
  };
}
function Ie(e) {
  if (!e || !T(e.id) || !T(e.projectId) || !Number.isSafeInteger(e.revision) || e.revision < 0 || !Number.isSafeInteger(e.projectRevision) || e.projectRevision < 1)
    throw new h("VALIDATION", "This quotation draft has no valid identity or revision.");
  const i = Object.fromEntries(["quantity", "scope", "proposedLeadTime", "assumptions", "exclusions", "validity"].map((o) => [o, T(e.values?.[o])]));
  if (Object.values(i).some((o) => o.length > 8e3)) throw new h("VALIDATION", "Keep quotation fields within 8,000 characters.");
  if (!Array.isArray(e.values?.lineItems) || e.values.lineItems.length > 30) throw new h("VALIDATION", "Keep the quotation within 30 line items.");
  if (i.lineItems = e.values.lineItems.map((o) => ({ id: T(o.id), label: T(o.label), quantity: T(o.quantity), unitPrice: T(o.unitPrice) })), i.lineItems.some((o) => !o.id || Object.values(o).some((n) => n.length > 1e3)) || new Set(i.lineItems.map((o) => o.id)).size !== i.lineItems.length)
    throw new h("VALIDATION", "Each quotation line needs a unique identity and concise details.");
  for (const o of ["previousQuoteId", "changeId"]) if (e[o] !== null && !T(e[o])) throw new h("VALIDATION", "The quotation draft has invalid version references.");
  let t = null;
  if (e.replyDraft !== void 0 && e.replyDraft !== null) {
    if (!Array.isArray(e.replyDraft.resolutions) || e.replyDraft.resolutions.length > 3) throw new h("VALIDATION", "Keep one response per change topic.");
    if (t = { kind: T(e.replyDraft.kind), body: T(e.replyDraft.body), changeId: e.replyDraft.changeId || null, resolutions: e.replyDraft.resolutions.map((o) => ({ topic: T(o.topic), status: T(o.status), response: T(o.response) })) }, t.body.length > 4e3 || t.resolutions.some((o) => o.response.length > 2e3 || !["quantity", "timing", "notes"].includes(o.topic) || !["accepted", "alternative", "needs-info"].includes(o.status)) || new Set(t.resolutions.map((o) => o.topic)).size !== t.resolutions.length || t.changeId !== null && t.changeId !== e.changeId || !["reply", "clarification", "change-response"].includes(t.kind)) throw new h("VALIDATION", "Check the saved reply draft.");
  }
  return {
    id: T(e.id),
    revision: e.revision,
    projectId: T(e.projectId),
    projectRevision: e.projectRevision,
    previousQuoteId: e.previousQuoteId,
    changeId: e.changeId,
    replyDraft: t,
    values: i,
    updatedAt: e.updatedAt || null,
    ...e.context !== void 0 ? { context: W(e.context) } : {},
    ...e.impactScope !== void 0 ? { impactScope: Ni(e.impactScope) } : {},
    ...e.questionScope !== void 0 ? { questionScope: oi(e.questionScope) } : {},
    ...e.scopeSelection !== void 0 ? { scopeSelection: xi(e.scopeSelection) } : {}
  };
}
function Gn(e) {
  const { values: i } = Ie(e), t = {};
  ze(i.quantity) || (t.quantity = "Enter a whole quantity from 1 to 100,000 before issuing a quotation."), i.scope || (t.scope = "Describe what this quotation includes."), i.proposedLeadTime || (t.proposedLeadTime = "State the proposed lead time, or say it remains to be confirmed."), i.lineItems.length || (t.lineItems = "Add at least one line item.");
  for (const [o, n] of i.lineItems.entries())
    n.label || (t[`lineItems.${o}.label`] = "Name this item."), (!ie(n.quantity) || +n.quantity <= 0 || +n.quantity > 1e5) && (t[`lineItems.${o}.quantity`] = "Enter a positive quantity up to 100,000."), n.unitPrice && !ie(n.unitPrice) && (t[`lineItems.${o}.unitPrice`] = "Enter a non-negative price with up to two decimal places, or leave it unpriced."), ie(n.quantity) && ie(n.unitPrice) && +n.quantity * +n.unitPrice > 1e8 && (t[`lineItems.${o}.unitPrice`] = "Keep the line amount within 100 million.");
  return t;
}
function Hn(e, i) {
  const t = Ie(e), { values: o } = t, n = i.changes.find((c) => c.id === t.changeId), r = o.lineItems.map((c) => ({
    id: c.id,
    label: c.label,
    quantity: ie(c.quantity) ? +c.quantity : null,
    unitPrice: c.unitPrice && ie(c.unitPrice) ? +c.unitPrice : null,
    amount: c.unitPrice && ie(c.unitPrice) && ie(c.quantity) ? Gt(+c.quantity * +c.unitPrice) : null
  })), s = (n?.values || i.inquiry.values).targetWeeks, d = i.quotes.at(-1)?.openItems || [
    { id: "load-cycle", label: "Confirm application load and required cycle rate.", owner: "Customer / engineering", status: "Open" },
    { id: "mounting", label: "Review mounting interfaces, tolerances and application fit.", owner: "Engineering", status: "Open" },
    ...i.inquiry.values.notes ? [{ id: "customer-notes", label: i.inquiry.values.notes, owner: "Sales / engineering", status: "Unanswered" }] : []
  ], l = new Set((i.messages || []).flatMap((c) => c.resolutions?.some((u) => u.topic === "notes" && u.status !== "needs-info") ? [i.changes.find((u) => u.id === c.changeId)?.values.notes] : [])), a = d.filter((c) => !c.id.startsWith("unpriced-") && !l.has(c.label));
  for (const c of r.filter((u) => u.amount === null)) a.some((u) => u.label === c.label) || a.push({ id: `unpriced-${c.id}`, label: c.label, owner: "Sales / customer", status: "Unpriced" });
  return {
    ...i.context.drawing || i.context.inspection || i.context.viewerReference ? { context: I(L(i, t)) } : {},
    version: i.quotes.length + 1,
    quantity: ze(o.quantity) ? +o.quantity : null,
    unitPrice: r[0]?.unitPrice ?? null,
    currency: "USD",
    lineItems: r,
    subtotal: Gt(r.reduce((c, u) => c + (u.amount ?? 0), 0)),
    total: null,
    requestedWeeks: s ? +s : null,
    proposedLeadTime: o.proposedLeadTime,
    scope: o.scope,
    assumptions: Ht(o.assumptions),
    exclusions: Ht(o.exclusions),
    validity: o.validity,
    openItems: a,
    ...t.scopeSelection ? { scopeSelection: I(t.scopeSelection) } : {},
    ...t.questionScope ? { questionScope: I(t.questionScope) } : {},
    ...t.impactScope ? { impactScope: I(t.impactScope) } : {},
    previousQuoteId: t.previousQuoteId,
    changeId: t.changeId,
    replyId: null,
    source: "seller-demo"
  };
}
function Pi(e, i) {
  const t = T(i?.body), o = i?.kind, n = i?.changeId || null, r = {};
  ["reply", "clarification", "change-response"].includes(o) || (r.kind = "Choose a reply type."), (!t || t.length > 4e3) && (r.body = "Write a message of 1–4,000 characters.");
  const s = n && e.changes.find((l) => l.id === n);
  n && !s && (r.changeId = "Choose a change request in this project."), o === "change-response" && !s && (r.changeId = "Choose the change request to answer.");
  const d = (Array.isArray(i?.resolutions) ? i.resolutions : []).map((l) => ({ topic: T(l.topic), status: T(l.status), response: T(l.response) }));
  if (d.length && o !== "change-response" && (r.resolutions = "Only a change response can resolve requested terms."), d.length && (!s || d.length > 3 || new Set(d.map((l) => l.topic)).size !== d.length || d.some((l) => !$e(s).includes(l.topic) || !["accepted", "alternative", "needs-info"].includes(l.status) || !l.response || l.response.length > 2e3)) && (r.resolutions = "Give each requested change one clear outcome and explanation."), o === "change-response" && s && !$e(s).every((l) => d.some((a) => a.topic === l)) && (r.resolutions = "Respond to quantity, timing and any written question."), Object.keys(r).length) throw new h("VALIDATION", "Check the reply details.", r);
  return { kind: o, body: t, changeId: n, resolutions: d };
}
function Ci(e, i) {
  Ne(e);
  const t = Pi(e, i);
  if (["clarification", "change-response"].includes(t.kind) && ne(e)) throw new h("CONFLICT", "Wait for the customer to answer the outstanding question before requesting or resolving further changes.");
  return Je({ kind: "seller-reply", projectId: e.id, projectRevision: e.revision, values: t });
}
function Yn(e, i, t = null) {
  Ne(e);
  const o = Ie(i), n = { ...Gn(o), ...Qe(e, o), ...Ve(e, o), ...Te(e, o) };
  if (Object.keys(n).length) throw new h("VALIDATION", "Check the quotation details.", n);
  if (o.revision < 1 || o.projectId !== e.id || o.projectRevision !== e.revision || o.previousQuoteId !== (e.quotes.at(-1)?.id || null)) throw new h("STALE_REVIEW", "Save and review the latest quotation draft before issuing it.");
  if (e.context.drawing && !y(L(e, o), G(e))) throw new h("DRAWING_REVIEW_REQUIRED", "This quotation draft uses an earlier drawing reference. Explicitly review and replace it before issuing a new quotation.");
  if ((e.context.inspection || e.context.viewerReference) && !e.context.drawing && !y(o.context, e.context)) throw new h("STALE_REVIEW", "Keep the saved inquiry view attached to this quotation.");
  const r = t || o.replyDraft, s = r ? Pi(e, r) : null;
  if (ne(e)) throw new h("CONFLICT", "Wait for the customer clarification before issuing a quotation.");
  const d = ke(e);
  if (d && (o.changeId !== d.id || !s || s.kind !== "change-response" || s.changeId !== d.id || s.resolutions.some((l) => l.status === "needs-info")))
    throw new h("VALIDATION", "Resolve each requested change in the reviewed reply before issuing the new quotation.", { resolutions: "Answer each change, or request clarification first." });
  return Je({ kind: "issue-quote", projectId: e.id, projectRevision: e.revision, draft: o, reply: s });
}
function Bn(e, i) {
  Ne(e);
  const t = T(i?.body), o = T(i?.replyTo), n = ne(e);
  if (!t || t.length > 4e3) throw new h("VALIDATION", "Add a reply of 1–4,000 characters.", { body: "Add your answer." });
  if (!n || n.id !== o) throw new h("STALE_REVIEW", "Open the current clarification before replying.");
  return Je({ kind: "customer-reply", projectId: e.id, projectRevision: e.revision, body: t, replyTo: o });
}
function Xn(e, i) {
  Ne(e);
  const t = T(i?.body), o = T(i?.nextStepId), n = e.nextSteps.find((r) => r.id === o);
  if (ii(e), !t || t.length > 4e3) throw new h("VALIDATION", "Describe the agreed next step in 1–4,000 characters.", { body: "Describe what happens next." });
  if (!n || n.quoteId !== e.quotes.at(-1)?.id) throw new h("STALE_REVIEW", "Choose a next-step request for the current quotation.");
  if (ke(e) || ne(e)) throw new h("CONFLICT", "Resolve the outstanding customer questions before confirming the next step.");
  if ((e.messages || []).some((r) => r.nextStepId === o && r.kind === "next-step-confirmation")) throw new h("CONFLICT", "This next-step request is already confirmed.");
  return Je({ kind: "acknowledge-next-step", projectId: e.id, projectRevision: e.revision, body: t, nextStepId: o });
}
const Zn = "annora.product-room.projects.v1", ft = 2, eo = () => ({ schemaVersion: ft, revision: 0, drafts: [], projects: [], quoteDrafts: [] }), J = (e) => Array.isArray(e), N = (e) => typeof e == "string" && e.length > 0, fe = (e) => Number.isSafeInteger(e) && e >= 0, K = (e) => typeof e == "string" && Number.isFinite(Date.parse(e)), Re = (e) => new Set(e.map((i) => i.id)).size === e.length, Ee = (e) => Object.hasOwn(e, "inquiryRulesVersion") ? { inquiryRulesVersion: e.inquiryRulesVersion } : {}, Le = (e) => Object.hasOwn(e, "requestItems") ? { requestItems: I(e.requestItems) } : {}, Yt = (e) => J(e) && e.every((i) => N(i.id) && N(i.label) && N(i.owner) && N(i.status)), he = (e, i) => {
  if (!e?.context.drawing && (e?.context.inspection || i.context?.inspection || e?.context.viewerReference || i.context?.viewerReference) && !y(i.context, e?.context)) throw new Error("A saved record changed its inquiry view.");
};
function to(e) {
  if (e == null) return eo();
  try {
    const i = JSON.parse(e);
    if (i.schemaVersion === 1) {
      if (Object.hasOwn(i, "quoteDrafts") || (i.projects || []).some((t) => Object.hasOwn(t, "messages"))) throw new Error();
      i.schemaVersion = ft, i.quoteDrafts = [];
      for (const t of i.projects || []) t.messages = [];
    }
    if (i.schemaVersion !== ft || !fe(i.revision) || !J(i.drafts) || !J(i.projects) || !Re(i.drafts) || !Re(i.projects) || !J(i.quoteDrafts) || !Re(i.quoteDrafts)) throw new Error();
    for (const t of i.drafts) {
      const o = Fe(t);
      if (t.revision < 1 || !K(t.updatedAt) || !y(o, t)) throw new Error();
    }
    if (new Set(i.drafts.map((t) => se(t.context))).size !== i.drafts.length) throw new Error();
    for (const t of i.projects) {
      if (!N(t.id) || !fe(t.revision) || t.revision < 1 || !K(t.createdAt) || !K(t.updatedAt)) throw new Error();
      if (!t.inquiry || !N(t.inquiry.id) || !N(t.inquiry.reviewToken) || !K(t.inquiry.createdAt)) throw new Error();
      const o = Fe({ id: t.inquiry.id, revision: 1, ...Ee(t.inquiry), ...Le(t.inquiry), context: t.context, values: t.inquiry.values, requirements: t.inquiry.requirements });
      if (Object.keys(wi(o)).length || !y(Ee(o), Ee(t.inquiry)) || !y(Le(o), Le(t.inquiry)) || !y(o.context, t.context) || !y(o.values, t.inquiry.values) || !y(o.requirements, t.inquiry.requirements)) throw new Error();
      if (Object.hasOwn(t.inquiry, "requestItems")) {
        const n = JSON.parse(t.inquiry.reviewToken);
        if (n.kind !== "inquiry" || !y(n.draft?.requestItems, t.inquiry.requestItems)) throw new Error();
      }
      In(t);
      for (const n of ["quotes", "changes", "replies", "nextSteps", "messages"]) if (!J(t[n]) || !Re(t[n])) throw new Error();
      for (const [n, r] of t.quotes.entries()) {
        if (t.context.drawing && ue(t, r, We(t, r.issuedProjectRevision || 1)), he(t, r), !N(r.id) || r.version !== n + 1 || !K(r.createdAt) || !fe(r.quantity) || r.quantity < 1 || r.unitPrice !== null && (!Number.isFinite(r.unitPrice) || r.unitPrice < 0) || !Number.isFinite(r.subtotal) || r.total !== null || r.currency !== "USD" || !["sample", "seller-demo"].includes(r.source) || !N(r.scope) || !N(r.proposedLeadTime) || !J(r.assumptions) || !r.assumptions.every((s) => typeof s == "string") || !Yt(r.openItems)) throw new Error();
        if (r.requestedWeeks !== null && (!fe(r.requestedWeeks) || r.requestedWeeks < 1)) throw new Error();
        if (!J(r.lineItems) || !r.lineItems.every((s) => N(s.label) && (s.amount === null || Number.isFinite(s.amount) && s.amount >= 0))) throw new Error();
        if (Math.round(r.lineItems.reduce((s, d) => s + (d.amount ?? 0), 0) * 100) / 100 !== r.subtotal) throw new Error();
        if (n === 0 && (r.previousQuoteId !== null || r.changeId !== null || r.replyId !== null)) throw new Error();
        if (n > 0 && r.source === "sample") {
          const s = t.changes.find((l) => l.id === r.changeId), d = t.replies.find((l) => l.id === r.replyId);
          if (r.previousQuoteId !== t.quotes[n - 1].id || !s || !d || s.quoteId !== r.previousQuoteId || d.changeId !== s.id || d.quoteId !== s.quoteId) throw new Error();
        }
        if (r.source === "seller-demo") {
          if (!fe(r.issuedProjectRevision) || r.issuedProjectRevision < 2 || r.issuedProjectRevision > t.revision || !N(r.reviewToken) || !J(r.exclusions) || !r.exclusions.every((s) => typeof s == "string") || typeof r.validity != "string" || r.replyId !== null) throw new Error();
          if (r.previousQuoteId !== (t.quotes[n - 1]?.id || null) || r.changeId !== null && !t.changes.some((s) => s.id === r.changeId && s.quoteId === r.previousQuoteId)) throw new Error();
          if (!r.lineItems.length || !Re(r.lineItems) || r.lineItems.some((s) => !N(s.id) || !Number.isFinite(s.quantity) || s.quantity <= 0 || s.unitPrice !== null && (!Number.isFinite(s.unitPrice) || s.unitPrice < 0) || s.amount !== (s.unitPrice === null ? null : Math.round((s.quantity * s.unitPrice + Number.EPSILON) * 100) / 100))) throw new Error();
          if (r.unitPrice !== r.lineItems[0].unitPrice) throw new Error();
        }
      }
      for (const n of t.changes) {
        he(t, n);
        const r = t.quotes.find((s) => s.id === n.quoteId);
        if (t.context.drawing && r && ue(t, n, L(t, r)), !N(n.id) || !r || r.version !== n.quoteVersion || !K(n.createdAt) || !N(n.reviewToken) || !n.values || !/^\d+$/.test(n.values.quantity) || +n.values.quantity < 1 || typeof n.values.targetWeeks != "string" || typeof n.values.notes != "string") throw new Error();
      }
      for (const n of t.replies) {
        he(t, n);
        const r = t.changes.find((s) => s.id === n.changeId);
        if (t.context.drawing && r && ue(t, n, L(t, r)), !N(n.id) || !r || n.quoteId !== r.quoteId || n.quoteVersion !== r.quoteVersion || !K(n.createdAt) || n.source !== "sample" || !J(n.topics) || !n.topics.every((s) => ["label", "requested", "response", "status"].every((d) => typeof s[d] == "string")) || !Yt(n.openItems)) throw new Error();
      }
      if (new Set(t.replies.map((n) => n.changeId)).size !== t.replies.length) throw new Error();
      for (const [n, r] of t.messages.entries()) {
        if (he(t, r), t.context.drawing) {
          const s = r.replyTo ? t.messages.find((d) => d.id === r.replyTo) : r.changeId ? t.changes.find((d) => d.id === r.changeId) : r.nextStepId ? t.nextSteps.find((d) => d.id === r.nextStepId) : null;
          ue(t, r, s ? L(t, s) : We(t, r.projectRevision));
        }
        if (!fe(r.projectRevision) || r.projectRevision < 2 || r.projectRevision > t.revision || n > 0 && r.projectRevision <= t.messages[n - 1].projectRevision || !N(r.id) || !["seller", "buyer"].includes(r.authorRole) || !["reply", "clarification", "change-response", "customer-reply", "next-step-confirmation"].includes(r.kind) || !N(r.body) || r.body.length > 4e3 || !K(r.createdAt) || !N(r.reviewToken) || r.delivery !== "demo-only" || !J(r.resolutions)) throw new Error();
        for (const s of ["changeId", "replyTo", "nextStepId"]) if (r[s] !== null && !N(r[s])) throw new Error();
        if (r.authorRole === "buyer" != (r.kind === "customer-reply")) throw new Error();
        if (r.kind === "customer-reply" && (r.nextStepId !== null || ne({ ...t, messages: t.messages.slice(0, n) })?.id !== r.replyTo)) throw new Error();
        if (r.kind === "next-step-confirmation" && (r.replyTo !== null || !t.nextSteps.some((s) => s.id === r.nextStepId && (!s.projectRevision || s.projectRevision < r.projectRevision)))) throw new Error();
        if (["reply", "clarification", "change-response"].includes(r.kind)) {
          if (r.replyTo !== null || r.nextStepId !== null) throw new Error();
          Ci({ ...t, messages: t.messages.slice(0, n) }, r);
        } else if (r.resolutions.length || r.changeId !== null) throw new Error();
      }
      if (new Set(t.messages.filter((n) => n.kind === "customer-reply").map((n) => n.replyTo)).size !== t.messages.filter((n) => n.kind === "customer-reply").length) throw new Error();
      if (new Set(t.messages.filter((n) => n.kind === "next-step-confirmation").map((n) => n.nextStepId)).size !== t.messages.filter((n) => n.kind === "next-step-confirmation").length) throw new Error();
      for (const n of t.nextSteps) {
        he(t, n);
        const r = t.quotes.find((s) => s.id === n.quoteId);
        if (t.context.drawing && r && ue(t, n, L(t, r)), !N(n.id) || !r || r.version !== n.quoteVersion || !K(n.createdAt) || !N(n.reviewToken) || !N(n.message) || !["discussion", "engineering-review"].includes(n.intent) || n.delivery !== "demo-only") throw new Error();
      }
    }
    for (const t of i.quoteDrafts) {
      const o = Ie(t), n = i.projects.find((r) => r.id === t.projectId);
      if (n?.context.drawing && ue(n, t), he(n, t), !n || t.revision < 1 || !K(t.updatedAt) || !y(o, { ...t, replyDraft: t.replyDraft ?? null }) || t.projectRevision > n.revision || t.previousQuoteId !== (n.quotes.at(-1)?.id || null) || t.changeId !== null && !n.changes.some((r) => r.id === t.changeId && r.quoteId === t.previousQuoteId)) throw new Error();
    }
    if (new Set(i.quoteDrafts.map((t) => t.projectId)).size !== i.quoteDrafts.length) throw new Error();
    Nn(i);
    for (const t of i.projects) Ln(t, i.quoteDrafts.filter((o) => o.projectId === t.id));
    for (const t of i.projects) Ui(t, i.quoteDrafts.filter((o) => o.projectId === t.id));
    for (const t of i.projects) Di(t, i.quoteDrafts.filter((o) => o.projectId === t.id));
    return i;
  } catch {
    throw new h("STORAGE_CORRUPT", "Saved project data could not be read. It has not been changed. Use a different browser profile for a fresh demo, or recover the stored data before continuing.");
  }
}
function j(e, i) {
  const t = e.projects.find((o) => o.id === i);
  if (!t) throw new h("NOT_FOUND", "This project is not saved in this browser. Open My projects to choose an available project.");
  return t;
}
function Xe(e) {
  if (e.context.productId !== yn) throw new h("UNSUPPORTED_PRODUCT", "The commercial example is available for the crank-slider mechanism only.");
}
function Bt(e, i) {
  if (e.revision !== i.projectRevision) throw new h("STALE_REVIEW", "This project changed after your review. Reopen it and review the latest details.");
  const t = e.quotes.at(-1);
  if (!t || t.id !== i.quoteId || t.version !== i.quoteVersion) throw new h("STALE_REVIEW", "A newer quotation is available. Review the latest version first.");
  return t;
}
function be(e, i) {
  if (e.revision !== i.projectRevision) throw new h("STALE_REVIEW", "This project changed after your review. Reopen it and review the latest details.");
}
function B(e, i) {
  return e.revision++, e.updatedAt = i, e;
}
function ro(e = {}) {
  const i = e.key || Zn;
  function t(v) {
    e.commercialProduct?.id === v.context.productId && e.commercialProduct.modelRevision === v.context.modelRevision || e.drawingWorkflow === !0 && v.context.drawing || Xe(v);
  }
  const o = e.now || (() => (/* @__PURE__ */ new Date()).toISOString()), n = e.makeId || ((v) => `${v}-DEMO-${globalThis.crypto.randomUUID().slice(0, 8).toUpperCase()}`), r = Object.hasOwn(e, "locks") ? e.locks : globalThis.navigator?.locks;
  let s;
  function d() {
    try {
      if (s ||= e.storage || globalThis.localStorage, !s || typeof s.getItem != "function" || typeof s.setItem != "function") throw new Error();
      return s;
    } catch {
      throw new h("STORAGE_UNAVAILABLE", "Browser storage is unavailable. Keep this page open and enable storage before saving. Nothing has been submitted.");
    }
  }
  function l() {
    let v;
    try {
      v = d().getItem(i);
    } catch (f) {
      throw f instanceof h ? f : new h("STORAGE_UNAVAILABLE", "Saved projects could not be read. Nothing has been changed.");
    }
    return { raw: v, store: to(v) };
  }
  function a(v, f) {
    const w = JSON.stringify(v);
    try {
      const p = d();
      if (p.getItem(i) !== f) throw new h("CONFLICT", "Another tab changed this project. Reopen the latest saved record before continuing.");
      if (p.setItem(i, w), p.getItem(i) !== w) throw new h("CONFLICT", "Another tab changed the saved data. Reload the project to check its latest state.");
    } catch (p) {
      throw p instanceof h ? p : new h("STORAGE_UNAVAILABLE", "The change could not be saved in this browser. Your input is still available; try again after allowing storage or freeing space.");
    }
  }
  function c(v) {
    const f = () => {
      const { raw: w, store: p } = l(), m = JSON.stringify(p), q = v(p);
      return JSON.stringify(p) !== m && (p.revision++, a(p, w)), I(q);
    };
    return r?.request ? r.request(`annora:${i}`, f) : Promise.resolve().then(f);
  }
  function u(v, f) {
    const w = v.quoteDrafts.find((m) => m.projectId === f.id);
    let p = w ? Ie(w) : null;
    if (p) {
      const m = f.changes.filter((b) => b.quoteId === p.previousQuoteId).at(-1), q = p.replyDraft && (p.replyDraft.body || p.replyDraft.resolutions.some((b) => b.response));
      if (m && p.changeId !== m.id && !q) {
        const b = Be(f, p.id);
        p.changeId = m.id, p.replyDraft = b.replyDraft;
      }
      p.projectRevision = f.revision, w.projectRevision !== f.revision && (p.rebasedFromRevision = w.projectRevision), f.context.drawing && !y(L(f, p), G(f)) && (p.drawingReferenceStale = !0);
    }
    return { ...f, quoteDraft: p };
  }
  function g(v, f, w, p = "seller") {
    const m = f.replyTo ? v.messages.find((E) => E.id === f.replyTo) : f.changeId ? v.changes.find((E) => E.id === f.changeId) : f.nextStepId ? v.nextSteps.find((E) => E.id === f.nextStepId) : null, q = m ? L(v, m) : G(v), b = { ...v.context.drawing || v.context.inspection || v.context.viewerReference ? { context: I(q) } : {}, id: n("MSG"), projectRevision: v.revision + 1, authorRole: p, kind: f.kind, body: f.body, changeId: f.changeId || null, replyTo: f.replyTo || null, nextStepId: f.nextStepId || null, resolutions: I(f.resolutions || []), createdAt: o(), reviewToken: w, delivery: "demo-only" };
    return v.messages.push(b), b;
  }
  async function A(v) {
    if (e.drawingWorkflow !== !0 || typeof e.getDrawingRelease != "function") throw new h("DRAWING_RELEASE_UNAVAILABLE", "This host must provide the published drawing repository before project references can change.");
    const f = v?.releaseId || v?.release?.id;
    if (!N(f)) throw new h("VALIDATION", "Choose a published drawing release.");
    let w;
    try {
      w = await e.getDrawingRelease(f);
    } catch {
      throw new h("DRAWING_RELEASE_UNAVAILABLE", "This published release is no longer available. Reopen the drawing workspace.");
    }
    if (!w || w.id !== f || v.release && !y(v.release, w)) throw new h("STALE_REVIEW", "The proposed source does not match the saved published release. Choose it again.");
    return w;
  }
  const R = {
    mode: "demo",
    evidenceScope: Object.freeze({ schemaVersion: 1, namespace: i, storage: "browser-local" }),
    supportsRequestItems: !0,
    supportedViewerReferenceVersions: Object.freeze(["1"]),
    ...Dn({ read: l, change: c, findProject: j, now: o, makeId: n }),
    ...Vn({ read: l, change: c, findProject: j, now: o, makeId: n }),
    ...Un({ read: l, change: c, findProject: j, now: o, makeId: n }),
    ...Mn({ read: l, change: c, findProject: j, now: o, makeId: n, drawingRelease: A, sellerProjection: u, enabled: e.drawingWorkflow === !0 && typeof e.getDrawingRelease == "function" }),
    async proposeDrawingRevision(v, f) {
      const w = await A(f), { store: p } = l(), m = j(p, v);
      if (t(m), m.impactPolicy || e.requireDrawingImpact === !0) throw new h("IMPACT_REVIEW_REQUIRED", "Review affected questions and scope through drawing impact before changing this project source.");
      return Vt(m, f, w, p.quoteDrafts.find((q) => q.projectId === v));
    },
    async reviewDrawingRevision(v, f) {
      return $t(await R.proposeDrawingRevision(v, f), o());
    },
    async confirmDrawingRevision(v, { confirmed: f = !1 } = {}) {
      if (!f) throw new h("CONFIRMATION_REQUIRED", "Review the source change and explicitly confirm adoption.");
      const w = P(v, "drawing-revision"), p = await A(w);
      return c((m) => {
        const q = j(m, w.projectId);
        if (t(q), q.lastDrawingReviewToken === v.token || q.drawingRevisions?.some((ye) => ye.reviewToken === v.token)) return u(m, q);
        if (q.impactPolicy || e.requireDrawingImpact === !0) throw new h("IMPACT_REVIEW_REQUIRED", "Review affected questions and scope before adopting another source.");
        be(q, w);
        const b = m.quoteDrafts.find((ye) => ye.projectId === q.id) || null;
        if (!y(b, w.quoteDraft)) throw new h("STALE_REVIEW", "The quotation draft changed after reference review. Review the change again.");
        const E = Vt(q, w, p, b), De = $t(E, w.reviewedAt);
        if (!y(De, v)) throw new h("STALE_REVIEW", "The project reference or reviewed source changed. Review it again.");
        const _ = o();
        return w.referenceChanged && (q.activeDrawingContext = I(w.context), q.drawingRevisions ||= [], q.drawingRevisions.push({ id: n("DRAWING-ADOPTION"), status: "adopted", projectRevision: q.revision + 1, fromContext: I(w.fromContext), context: I(w.context), release: I(p), note: w.note, quoteDraftAction: w.quoteDraftAction, reviewedAt: w.reviewedAt, createdAt: _, reviewToken: v.token })), q.lastDrawingReviewToken = v.token, B(q, _), w.quoteDraftAction === "replace" && b && (m.quoteDrafts = m.quoteDrafts.filter((ye) => ye.projectId !== q.id), m.quoteDrafts.push({ ...Be(q, n("QD")), revision: 1, updatedAt: _ })), u(m, q);
      });
    },
    async listProjects() {
      return I(l().store.projects).sort((v, f) => f.updatedAt.localeCompare(v.updatedAt));
    },
    async getProject(v) {
      return I(j(l().store, v));
    },
    async listSellerProjects() {
      const { store: v } = l();
      return I(v.projects.map((f) => u(v, f))).sort((f, w) => w.updatedAt.localeCompare(f.updatedAt));
    },
    async getSellerProject(v) {
      const { store: f } = l();
      return I(u(f, j(f, v)));
    },
    async getQuoteDraft(v) {
      const { store: f } = l(), w = j(f, v);
      return t(w), I(u(f, w).quoteDraft || Be(w, n("QD")));
    },
    async saveQuoteDraft(v) {
      const f = Ie(v);
      return c((w) => {
        const p = j(w, f.projectId);
        t(p);
        const m = w.quoteDrafts.find((b) => b.projectId === p.id);
        if (jn(p, f), $i(p, f), zn(p, f), p.context.drawing && !y(L(p, f), G(p))) throw new h("DRAWING_REVIEW_REQUIRED", "This quotation draft uses an earlier drawing reference. Review and explicitly replace it before saving or issuing a new version.");
        if ((p.context.inspection || p.context.viewerReference) && !p.context.drawing && !y(f.context, p.context)) throw new h("VALIDATION", "Keep the saved inquiry view attached to this quotation.");
        if (m && p.context.drawing && !y(L(p, f), L(p, m))) throw new h("DRAWING_REVIEW_REQUIRED", "A quotation draft reference can change only through explicit drawing-reference review.");
        if (f.projectRevision !== p.revision || f.previousQuoteId !== (p.quotes.at(-1)?.id || null)) throw new h("CONFLICT", "The customer project changed. Reopen it before saving the quotation draft. Your input is still available.");
        if (m ? m.id !== f.id || m.revision !== f.revision : f.revision !== 0) throw new h("CONFLICT", "This quotation draft changed or was issued in another tab. Reopen the latest draft.");
        if (f.changeId !== null && !p.changes.some((b) => b.id === f.changeId && b.quoteId === f.previousQuoteId)) throw new h("VALIDATION", "The draft change request does not match its quotation.");
        if (m && y(m, f)) return m;
        const q = { ...f, revision: f.revision + 1, updatedAt: o() };
        return w.quoteDrafts = w.quoteDrafts.filter((b) => b.projectId !== p.id), w.quoteDrafts.push(q), q;
      });
    },
    async issueQuote(v) {
      const f = P(v, "issue-quote");
      return c((w) => {
        const p = j(w, f.projectId);
        if (t(p), p.quotes.some((b) => b.reviewToken === v.token)) return u(w, p);
        be(p, f), Yn(p, f.draft, f.reply);
        const m = w.quoteDrafts.find((b) => b.id === f.draft.id);
        if (!m || !y(m, f.draft)) throw new h("STALE_REVIEW", "The saved quotation draft changed after review. Review the latest draft.");
        f.reply && g(p, f.reply, v.token);
        const q = o();
        return p.quotes.push({ ...Hn(m, p), id: n("QT"), createdAt: q, issuedProjectRevision: p.revision + 1, reviewToken: v.token }), w.quoteDrafts = w.quoteDrafts.filter((b) => b.id !== m.id), B(p, q), u(w, p);
      });
    },
    async sendReply(v) {
      const f = P(v, "seller-reply");
      return c((w) => {
        const p = j(w, f.projectId);
        if (t(p), p.messages.some((q) => q.reviewToken === v.token)) return p;
        be(p, f), Ci(p, f.values);
        const m = g(p, f.values, v.token);
        return B(p, m.createdAt);
      });
    },
    async sendCustomerReply(v) {
      const f = P(v, "customer-reply");
      return c((w) => {
        const p = j(w, f.projectId);
        if (t(p), p.messages.some((q) => q.reviewToken === v.token)) return p;
        be(p, f), Bn(p, f);
        const m = g(p, { ...f, kind: "customer-reply" }, v.token, "buyer");
        return B(p, m.createdAt);
      });
    },
    async acknowledgeNextStep(v) {
      const f = P(v, "acknowledge-next-step");
      return c((w) => {
        const p = j(w, f.projectId);
        if (t(p), p.messages.some((q) => q.reviewToken === v.token)) return p;
        be(p, f), Xn(p, f);
        const m = g(p, { ...f, kind: "next-step-confirmation" }, v.token);
        return B(p, m.createdAt);
      });
    },
    async createSampleInquiry(v) {
      return c((f) => {
        const w = f.projects.find((E) => E.demoSeed === "seller-inbox" && E.context.productId === v.productId && E.context.modelRevision === v.modelRevision && (E.context.roomReleaseId || null) === (v.roomReleaseId || null) && (!v.drawing || se(E.context) === se(v)));
        if (w) return u(f, w);
        const p = o(), m = nt(v, n("DRAFT"));
        m.revision = 1, m.values = qn(v), m.updatedAt = p;
        const q = Lt(m), b = { id: n("PRJ"), revision: 1, context: m.context, inquiry: { id: n("RFQ"), ...Ee(m), values: m.values, requirements: m.requirements, createdAt: p, reviewToken: q.token }, quotes: [], changes: [], replies: [], nextSteps: [], messages: [], createdAt: p, updatedAt: p, demoSeed: "seller-inbox" };
        return t(b), f.projects.push(b), u(f, b);
      });
    },
    async listDrafts() {
      return I(l().store.drafts).sort((v, f) => (f.updatedAt || "").localeCompare(v.updatedAt || ""));
    },
    async getDraft(v) {
      const f = nt(v, n("DRAFT")), w = l().store.drafts.find((p) => se(p.context) === se(f.context));
      return I(w || f);
    },
    async saveDraft(v) {
      const f = Fe(v);
      return c((w) => {
        const p = w.drafts.find((q) => se(q.context) === se(f.context));
        if (p && (p.id !== f.id || p.revision !== f.revision)) throw new h("CONFLICT", "This draft changed in another tab. Reopen it before saving again.");
        if (!p && f.revision !== 0) throw new h("CONFLICT", "This draft has already been submitted or removed. Start a new inquiry.");
        if (p && y(p, f)) return p;
        const m = { ...f, revision: f.revision + 1, updatedAt: o() };
        return w.drafts = w.drafts.filter((q) => q.id !== f.id), w.drafts.push(m), m;
      });
    },
    async submitInquiry(v) {
      const f = P(v, "inquiry");
      return Lt(f.draft), c((w) => {
        const p = w.projects.find((E) => E.inquiry.reviewToken === v.token);
        if (p) return p;
        const m = w.drafts.find((E) => E.id === f.draft.id);
        if (!m || !y(m, f.draft)) throw new h("STALE_REVIEW", "The saved inquiry changed after review. Review the latest draft before submitting.");
        const q = o(), b = {
          id: n("PRJ"),
          revision: 1,
          context: I(m.context),
          inquiry: { id: n("RFQ"), ...Ee(m), ...Le(m), values: I(m.values), requirements: I(m.requirements), createdAt: q, reviewToken: v.token },
          quotes: [],
          changes: [],
          replies: [],
          nextSteps: [],
          messages: [],
          createdAt: q,
          updatedAt: q
        };
        return w.projects.push(b), w.drafts = w.drafts.filter((E) => E.id !== m.id), b;
      });
    },
    async createSampleQuote(v) {
      return c((f) => {
        const w = j(f, v);
        if (Xe(w), w.impactPolicy) throw new h("IMPACT_REVIEW_REQUIRED", "Prepare and review the source impact in Studio before issuing this quotation.");
        if (w.questionPolicy) throw new h("QUESTION_REVIEW_REQUIRED", "Prepare and review the question evidence in Studio before issuing this quotation.");
        if (w.approvedOptionSet) throw new h("SCOPE_REVIEW_REQUIRED", "Prepare and review the mapped scope in Studio before issuing a quotation for this project.");
        if (w.quotes.length) return w;
        if (!ze(w.inquiry.values.quantity)) throw new h("VALIDATION", "Quantity is unknown. Prepare a seller quotation with an explicit quantity before issuing it.", { quantity: "Confirm a whole quantity from 1 to 100,000." });
        const p = o();
        if (f.quoteDrafts.some((q) => q.projectId === w.id)) throw new h("CONFLICT", "A seller quotation draft is already in progress. Open Studio to review it.");
        const m = Ut({ id: n("QT"), version: 1, createdAt: p, values: w.inquiry.values });
        return (w.context.inspection || w.context.viewerReference) && (m.context = I(w.context)), w.quotes.push(m), B(w, p);
      });
    },
    async requestRevision(v) {
      const f = P(v, "revision");
      return c((w) => {
        const p = j(w, f.projectId);
        if (t(p), p.changes.some((b) => b.reviewToken === v.token)) return p;
        const m = Bt(p, f);
        if (ln(p, m.id, f.values), ke(p) || ne(p)) throw new h("CONFLICT", "A change request already awaits a reply for this quotation.");
        const q = o();
        return p.changes.push({ id: n("CHG"), projectRevision: p.revision + 1, quoteId: m.id, quoteVersion: m.version, values: I(f.values), ...p.context.drawing || p.context.inspection || p.context.viewerReference ? { context: I(L(p, m)) } : {}, createdAt: q, reviewToken: v.token }), B(p, q);
      });
    },
    async simulateReply(v, f) {
      return c((w) => {
        const p = j(w, v);
        if (Xe(p), p.impactPolicy) throw new h("IMPACT_REVIEW_REQUIRED", "Prepare and review the source impact in Studio before issuing this quotation.");
        if (p.questionPolicy) throw new h("QUESTION_REVIEW_REQUIRED", "Prepare and review the question evidence in Studio before issuing a revised quotation.");
        if (p.approvedOptionSet) throw new h("SCOPE_REVIEW_REQUIRED", "Prepare and review the mapped scope in Studio before issuing a quotation for this project.");
        if (p.replies.some((_) => _.changeId === f)) return p;
        const m = p.changes.find((_) => _.id === f);
        if (!m) throw new h("NOT_FOUND", "Choose a saved change request before opening an example reply.");
        const q = p.quotes.find((_) => _.id === m.quoteId);
        if (q?.id !== p.quotes.at(-1)?.id) throw new h("STALE_REVIEW", "This change request belongs to an older quotation.");
        const b = o(), E = bn({ id: n("REPLY"), createdAt: b, change: m, quote: q, inquiry: p.inquiry }), De = Ut({ id: n("QT"), version: q.version + 1, createdAt: b, values: { ...p.inquiry.values, quantity: m.values.quantity, targetWeeks: m.values.targetWeeks }, additionalQuestions: p.changes.map((_) => _.values.notes), previousQuoteId: q.id, changeId: f, replyId: E.id });
        if (w.quoteDrafts.some((_) => _.projectId === p.id)) throw new h("CONFLICT", "A seller quotation draft is already in progress. Open Studio to review it.");
        return (p.context.drawing || p.context.inspection || p.context.viewerReference) && (E.context = I(L(p, m)), De.context = I(G(p))), p.replies.push(E), p.quotes.push(De), B(p, b);
      });
    },
    async confirmNextStep(v) {
      const f = P(v, "next-step");
      return c((w) => {
        const p = j(w, f.projectId);
        if (t(p), p.nextSteps.some((b) => b.reviewToken === v.token)) return p;
        const m = Bt(p, f);
        if (un(p, m.id, f), ke(p) || ne(p)) throw new h("CONFLICT", "Review the pending change response before confirming a next step.");
        if (p.nextSteps.some((b) => b.quoteId === m.id && (!p.messages.some((E) => E.kind === "next-step-confirmation" && E.nextStepId === b.id) || b.intent === f.intent && b.message === f.message))) throw new h("CONFLICT", "A matching or unanswered next-step request is already saved for this quotation.");
        const q = o();
        return p.nextSteps.push({ id: n("NEXT"), projectRevision: p.revision + 1, quoteId: m.id, quoteVersion: m.version, intent: f.intent, message: f.message, ...p.context.drawing || p.context.inspection || p.context.viewerReference ? { context: I(L(p, m)) } : {}, createdAt: q, delivery: "demo-only", reviewToken: v.token }), B(p, q);
      });
    }
  };
  return Object.freeze(R);
}
export {
  li as I,
  h as P,
  vi as Q,
  fi as R,
  I as a,
  W as b,
  ro as c,
  qn as d,
  on as e,
  oo as f,
  jt as g,
  Pt as h,
  no as i,
  io as j,
  et as k,
  Xi as l,
  tt as m,
  sn as n,
  me as o,
  se as p,
  so as q,
  Lt as r,
  y as s,
  Zi as t,
  it as u,
  P as v,
  nt as w,
  Fe as x,
  bt as y,
  Y as z
};
