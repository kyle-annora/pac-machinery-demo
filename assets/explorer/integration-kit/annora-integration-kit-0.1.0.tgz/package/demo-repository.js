import { c as e } from "./project-repository-BvG_2fpF.js";
function n({ namespace: r, storage: t, ...o } = {}) {
  if (typeof r != "string" || !r.trim() || r.startsWith("annora.product-room.") || r.startsWith("annora.studio."))
    throw new TypeError("Provide a separate integration namespace; existing product workspaces are reserved.");
  if (!t || typeof t.getItem != "function" || typeof t.setItem != "function") throw new TypeError("Provide host-owned browser storage.");
  return e({ ...o, key: r, storage: t });
}
export {
  n as createBrowserDemoRepository
};
