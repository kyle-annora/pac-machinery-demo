import { jsxs as c, jsx as n, Fragment as G } from "react/jsx-runtime";
import * as k from "react";
import lr, { createElement as dr, useId as ae, Children as ur, isValidElement as fr, cloneElement as pr, useState as xe, useRef as ee, useEffect as J } from "react";
import { createRoot as hr } from "react-dom/client";
import { s as M, P as x, n as re, r as mr, a as Ee, b as z, p as K, d as vr, i as H, e as Re, f as wr, R as gr, g as ve, I as Me, h as De, j as $e, q as br, c as yr, Q as qr, k as _, l as Fe, m as ze, o as le, t as Oe } from "./project-repository-BvG_2fpF.js";
import { u as Pt, v as kt, w as jt, x as Vt, y as Ut, z as _t } from "./project-repository-BvG_2fpF.js";
function Ir() {
  return typeof window < "u";
}
function Ye(e) {
  var r;
  return (e == null || (r = e.ownerDocument) == null ? void 0 : r.defaultView) || window;
}
function We(e) {
  return Ir() ? e instanceof HTMLElement || e instanceof Ye(e).HTMLElement : !1;
}
const ue = {
  ...k
}, Le = {};
function Ae(e, r) {
  const i = k.useRef(Le);
  return i.current === Le && (i.current = e(r)), i;
}
const we = ue.useInsertionEffect, Er = (
  // React 17 doesn't have useInsertionEffect.
  we && // Preact replaces useInsertionEffect with useLayoutEffect and fires too late.
  we !== ue.useLayoutEffect ? we : (e) => e()
);
function Rr(e) {
  const r = Ae(Nr).current;
  return r.next = e, Er(r.effect), r.trampoline;
}
function Nr() {
  const e = {
    next: void 0,
    callback: Tr,
    trampoline: (...r) => e.callback?.(...r),
    effect: () => {
      e.callback = e.next;
    }
  };
  return e;
}
function Tr() {
  if (process.env.NODE_ENV !== "production")
    throw (
      /* minify-error-disabled */
      new Error("Base UI: Cannot call an event handler while rendering.")
    );
}
let Ne;
process.env.NODE_ENV !== "production" && (Ne = /* @__PURE__ */ new Set());
function Ke(e, r) {
  return function(...a) {
    if (process.env.NODE_ENV !== "production") {
      const t = a.join(" "), o = `${r}: ${t}`, f = `${e}:${o}`;
      Ne.has(f) || (Ne.add(f), e === "warn" ? console.warn(o) : console.error(o));
    }
  };
}
const Pe = Ke("error", "Base UI"), Cr = () => {
}, xr = typeof document < "u" ? k.useLayoutEffect : Cr;
function Te(e, r) {
  if (e && !r)
    return e;
  if (!e && r)
    return r;
  if (e || r)
    return {
      ...e,
      ...r
    };
}
const He = {};
function Se(e, r, i, a, t) {
  if (!i && !a && !e)
    return fe(r);
  let o = fe(e);
  return r && (o = de(o, r)), i && (o = de(o, i)), a && (o = de(o, a)), o;
}
function Ar(e) {
  if (e.length === 0)
    return He;
  if (e.length === 1)
    return fe(e[0]);
  let r = fe(e[0]);
  for (let i = 1; i < e.length; i += 1)
    r = de(r, e[i]);
  return r;
}
function fe(e) {
  return Ge(e) ? {
    ...e(He)
  } : Sr(e);
}
function de(e, r) {
  return Ge(r) ? r(e) : Dr(e, r);
}
function Sr(e) {
  const r = {
    ...e
  };
  for (const i in r) {
    const a = r[i];
    Qe(i, a) && (r[i] = Je(a));
  }
  return r;
}
function Dr(e, r) {
  if (!r)
    return e;
  for (const i in r) {
    const a = r[i];
    switch (i) {
      case "style": {
        e[i] = Te(e.style, a);
        break;
      }
      case "className": {
        e[i] = Ze(e.className, a);
        break;
      }
      default:
        Qe(i, a) ? e[i] = Or(e[i], a) : e[i] = a;
    }
  }
  return e;
}
function Qe(e, r) {
  const i = e.charCodeAt(0), a = e.charCodeAt(1), t = e.charCodeAt(2);
  return i === 111 && a === 110 && t >= 65 && t <= 90 && (typeof r == "function" || typeof r > "u");
}
function Ge(e) {
  return typeof e == "function";
}
function Or(e, r) {
  return r ? e ? (...i) => {
    const a = i[0];
    if (Xe(a)) {
      const o = a;
      pe(o);
      const f = r(...i);
      return o.baseUIHandlerPrevented || e?.(...i), f;
    }
    const t = r(...i);
    return e?.(...i), t;
  } : Je(r) : e;
}
function Je(e) {
  return e && ((...r) => {
    const i = r[0];
    return Xe(i) && pe(i), e(...r);
  });
}
function pe(e) {
  return e.preventBaseUIHandler = () => {
    e.baseUIHandlerPrevented = !0;
  }, e;
}
function Ze(e, r) {
  return r ? e ? r + " " + e : r : e;
}
function Xe(e) {
  return e != null && typeof e == "object" && "nativeEvent" in e;
}
function Lr(e, r) {
  return function(a, ...t) {
    const o = new URL(e);
    return o.searchParams.set("code", a.toString()), t.forEach((f) => o.searchParams.append("args[]", f)), `${r} error #${a}; visit ${o} for the full message.`;
  };
}
const Pr = Lr("https://base-ui.com/production-error", "Base UI"), er = /* @__PURE__ */ k.createContext(void 0);
process.env.NODE_ENV !== "production" && (er.displayName = "CompositeRootContext");
function kr(e = !1) {
  const r = k.useContext(er);
  if (r === void 0 && !e)
    throw new Error(process.env.NODE_ENV !== "production" ? "Base UI: CompositeRootContext is missing. Composite parts must be placed within <Composite.Root>." : Pr(16));
  return r;
}
function jr(e) {
  const {
    focusableWhenDisabled: r,
    disabled: i,
    composite: a = !1,
    tabIndex: t = 0,
    isNativeButton: o
  } = e, f = a && r !== !1, v = a && r === !1;
  return {
    props: k.useMemo(() => {
      const h = {
        // allow Tabbing away from focusableWhenDisabled elements
        onKeyDown(g) {
          i && r && g.key !== "Tab" && g.preventDefault();
        }
      };
      return a || (h.tabIndex = t, !o && i && (h.tabIndex = r ? t : -1)), (o && (r || f) || !o && i) && (h["aria-disabled"] = i), o && (!r || v) && (h.disabled = i), h;
    }, [a, i, r, f, v, o, t])
  };
}
function ge(e, r, {
  detail: i = 0,
  pointerType: a = ""
} = {}) {
  e.dispatchEvent(new (Ye(e)).PointerEvent("click", {
    bubbles: !0,
    cancelable: !0,
    composed: !0,
    detail: i,
    pointerType: a,
    shiftKey: r.shiftKey,
    ctrlKey: r.ctrlKey,
    altKey: r.altKey,
    metaKey: r.metaKey
  }));
}
function Vr(e = {}) {
  const {
    disabled: r = !1,
    focusableWhenDisabled: i,
    tabIndex: a = 0,
    native: t = !0,
    composite: o
  } = e, f = k.useRef(null), v = kr(!0), E = o ?? v !== void 0, {
    props: h
  } = jr({
    focusableWhenDisabled: i,
    disabled: r,
    composite: E,
    tabIndex: a,
    isNativeButton: t
  });
  process.env.NODE_ENV !== "production" && k.useEffect(() => {
    if (!f.current)
      return;
    const p = se(f.current);
    if (t) {
      if (!p) {
        const s = ue.captureOwnerStack?.() || "";
        Pe(`A component that acts as a button expected a native <button> because the \`nativeButton\` prop is true. Rendering a non-<button> removes native button semantics, which can impact forms and accessibility. Use a real <button> in the \`render\` prop, or set \`nativeButton\` to \`false\`.${s}`);
      }
    } else if (p) {
      const s = ue.captureOwnerStack?.() || "";
      Pe(`A component that acts as a button expected a non-<button> because the \`nativeButton\` prop is false. Rendering a <button> keeps native behavior while Base UI applies non-native attributes and handlers, which can add unintended extra attributes (such as \`role\` or \`aria-disabled\`). Use a non-<button> in the \`render\` prop, or set \`nativeButton\` to \`true\`.${s}`);
    }
  }, [t]);
  const g = k.useCallback(() => {
    const p = f.current;
    se(p) && E && r && h.disabled === void 0 && p.disabled && (p.disabled = !1);
  }, [r, h.disabled, E]);
  xr(g, [g]);
  const I = k.useCallback((p = {}) => {
    const {
      onClick: s,
      onMouseDown: m,
      onKeyUp: l,
      onKeyDown: u,
      onPointerDown: q,
      ...C
    } = p;
    return Se({
      onClick(w) {
        if (r) {
          w.preventDefault();
          return;
        }
        s?.(w);
      },
      onMouseDown(w) {
        r || m?.(w);
      },
      onKeyDown(w) {
        if (r || (pe(w), u?.(w), w.baseUIHandlerPrevented))
          return;
        const A = w.target === w.currentTarget, S = w.currentTarget, j = se(S), Y = !t && Ur(S), U = A && (t ? j : !Y), W = w.key === "Enter", B = w.key === " ", T = S.getAttribute("role"), L = T?.startsWith("menuitem") || T === "option" || T === "gridcell";
        if (A && E && B) {
          if (w.defaultPrevented && L)
            return;
          w.preventDefault(), (!t || j) && (w.preventBaseUIHandler(), ge(S, w));
          return;
        }
        if (!U || t || !B && !W) {
          A && Y && B && w.preventDefault();
          return;
        }
        w.defaultPrevented || (w.preventDefault(), W && (w.preventBaseUIHandler(), ge(S, w)));
      },
      onKeyUp(w) {
        if (!r) {
          if (pe(w), l?.(w), w.target === w.currentTarget && t && E && se(w.currentTarget) && w.key === " ") {
            w.preventDefault();
            return;
          }
          w.baseUIHandlerPrevented || w.target === w.currentTarget && !t && !E && !w.defaultPrevented && w.key === " " && (w.preventBaseUIHandler(), ge(w.currentTarget, w));
        }
      },
      onPointerDown(w) {
        if (r) {
          w.preventDefault();
          return;
        }
        q?.(w);
      }
    }, t ? {
      type: "button"
    } : {
      role: "button"
    }, h, C);
  }, [r, h, E, t]), b = Rr((p) => {
    f.current = p, g();
  });
  return {
    getButtonProps: I,
    buttonRef: b
  };
}
function se(e) {
  return We(e) && e.tagName === "BUTTON";
}
function Ur(e) {
  return We(e) && e.tagName === "A" && !!e.href;
}
function ke(e, r, i, a) {
  const t = Ae(rr).current;
  return Br(t, e, r, i, a) && tr(t, [e, r, i, a]), t.callback;
}
function _r(e) {
  const r = Ae(rr).current;
  return Mr(r, e) && tr(r, e), r.callback;
}
function rr() {
  return {
    callback: null,
    cleanup: null,
    refs: []
  };
}
function Br(e, r, i, a, t) {
  return e.refs[0] !== r || e.refs[1] !== i || e.refs[2] !== a || e.refs[3] !== t;
}
function Mr(e, r) {
  return e.refs.length !== r.length || e.refs.some((i, a) => i !== r[a]);
}
function tr(e, r) {
  if (e.refs = r, r.every((i) => i == null)) {
    e.callback = null;
    return;
  }
  e.callback = (i) => {
    if (e.cleanup && (e.cleanup(), e.cleanup = null), i != null) {
      const a = Array(r.length).fill(null);
      for (let t = 0; t < r.length; t += 1) {
        const o = r[t];
        if (o != null)
          switch (typeof o) {
            case "function": {
              const f = o(i);
              typeof f == "function" && (a[t] = f);
              break;
            }
            case "object": {
              o.current = i;
              break;
            }
          }
      }
      e.cleanup = () => {
        for (let t = 0; t < r.length; t += 1) {
          const o = r[t];
          if (o != null)
            switch (typeof o) {
              case "function": {
                const f = a[t];
                typeof f == "function" ? f() : o(null);
                break;
              }
              case "object": {
                o.current = null;
                break;
              }
            }
        }
      };
    }
  };
}
const $r = parseInt(k.version, 10);
function Fr(e) {
  return $r >= e;
}
function je(e) {
  if (!/* @__PURE__ */ k.isValidElement(e))
    return null;
  const r = e, i = r.props;
  return (Fr(19) ? i?.ref : r.ref) ?? null;
}
const zr = Ke("warn", "Base UI"), X = Object.freeze({});
function Yr(e, r) {
  const i = {};
  for (const a in e) {
    const t = e[a];
    if (r?.hasOwnProperty(a)) {
      const o = r[a](t);
      o != null && Object.assign(i, o);
      continue;
    }
    t === !0 ? i[`data-${a.toLowerCase()}`] = "" : t && (i[`data-${a.toLowerCase()}`] = t.toString());
  }
  return i;
}
function Wr(e, r) {
  return typeof e == "function" ? e(r) : e;
}
function Kr(e, r) {
  return typeof e == "function" ? e(r) : e;
}
function Hr(e, r, i = {}) {
  let a = r.render;
  i.enabled !== !1 && (a = et(a));
  const t = Qr(r, i, a);
  if (i.enabled === !1)
    return null;
  const o = i.state ?? X;
  return rt(e, a, t, o);
}
function Qr(e, r, i) {
  const {
    className: a,
    style: t
  } = e, {
    state: o = X,
    ref: f,
    props: v,
    stateAttributesMapping: E,
    enabled: h = !0
  } = r, g = h ? Wr(a, o) : void 0, I = h ? Kr(t, o) : void 0, b = h ? Yr(o, E) : X, p = h && v ? Gr(v) : void 0, s = h ? Te(b, p) ?? {} : X;
  return typeof document < "u" && (h ? Array.isArray(f) ? s.ref = _r([s.ref, je(i), ...f]) : s.ref = ke(s.ref, je(i), f) : ke(null, null)), h ? (g !== void 0 && (s.className = Ze(s.className, g)), I !== void 0 && (s.style = Te(s.style, I)), s) : X;
}
function Gr(e) {
  return Array.isArray(e) ? Ar(e) : Se(void 0, e);
}
const Jr = /* @__PURE__ */ Symbol.for("react.lazy"), Zr = /^[A-Z][A-Za-z0-9$]*$/, Xr = /[a-z]/;
function et(e) {
  if (e?.$$typeof !== Jr)
    return e;
  const r = k.Children.toArray(e)[0];
  return /* @__PURE__ */ k.isValidElement(r) ? r : e;
}
function rt(e, r, i, a) {
  if (r) {
    if (typeof r == "function")
      return process.env.NODE_ENV !== "production" && tt(r), r(i, a);
    const t = Se(i, r.props);
    if (t.ref = i.ref, process.env.NODE_ENV !== "production" && !/* @__PURE__ */ k.isValidElement(r))
      throw new Error(["Base UI: The `render` prop was provided an invalid React element as `React.isValidElement(render)` is `false`.", "A valid React element must be provided to the `render` prop because it is cloned with props to replace the default element.", "https://base-ui.com/r/invalid-render-prop"].join(`
`));
    return /* @__PURE__ */ k.cloneElement(r, t);
  }
  return nt(e, i);
}
function tt(e) {
  const r = e.name;
  r.length !== 0 && Zr.test(r) && Xr.test(r) && zr(`The \`render\` prop received a function named \`${r}\` that starts with an uppercase letter.`, "This usually means a React component was passed directly as `render={Component}`.", "Base UI calls `render` as a plain function, which can break the Rules of Hooks during reconciliation.", "If this is an intentional render callback, rename it to start with a lowercase letter.", "Use `render={<Component />}` or `render={(props) => <Component {...props} />}` instead.", "https://base-ui.com/r/invalid-render-prop");
}
function nt(e, r) {
  return /* @__PURE__ */ dr("button", {
    type: "button",
    ...r,
    key: r.key
  });
}
const nr = /* @__PURE__ */ k.forwardRef(function(r, i) {
  const {
    render: a,
    className: t,
    disabled: o = !1,
    focusableWhenDisabled: f = !1,
    nativeButton: v = !0,
    style: E,
    ...h
  } = r, {
    getButtonProps: g,
    buttonRef: I
  } = Vr({
    disabled: o,
    focusableWhenDisabled: f,
    native: v
  });
  return Hr("button", r, {
    state: {
      disabled: o
    },
    ref: [i, I],
    props: [h, g]
  });
});
process.env.NODE_ENV !== "production" && (nr.displayName = "Button");
const te = (...e) => e.filter(Boolean).join(" ");
function Z({ name: e = "arrow", className: r = "", ...i }) {
  const a = {
    arrow: "M4 12h15m-6-6 6 6-6 6",
    back: "M20 12H5m6-6-6 6 6 6",
    check: "m5 12 4 4L19 6",
    plus: "M12 5v14M5 12h14",
    close: "m6 6 12 12M6 18 18 6",
    info: "M12 11v6M12 7v.1",
    document: "M14 3H5v18h14V8l-5-5v5h5M8 12h8M8 16h6",
    external: "M13 4h7v7m0-7L9 15M11 4H4v16h16v-7",
    replay: "M4 10a8 8 0 1 1 .7 7M4 4v6h6"
  };
  return /* @__PURE__ */ c(
    "svg",
    {
      ...i,
      className: te("ar-glyph", r),
      width: "18",
      height: "18",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "1.6",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": "true",
      children: [
        e === "info" && /* @__PURE__ */ n("circle", { cx: "12", cy: "12", r: "9" }),
        /* @__PURE__ */ n("path", { d: a[e] || a.arrow })
      ]
    }
  );
}
function P({
  variant: e = "primary",
  pending: r = !1,
  pendingLabel: i = "Saving…",
  disabled: a = !1,
  children: t,
  icon: o,
  className: f = "",
  type: v = "button",
  ...E
}) {
  const h = e === "ghost" ? "quiet" : e, g = ae();
  return /* @__PURE__ */ c(
    nr,
    {
      ...E,
      type: v,
      disabled: a || r,
      focusableWhenDisabled: r,
      "aria-busy": r || void 0,
      "data-pending": r || void 0,
      "data-variant": h,
      "aria-labelledby": r ? `${g}-pending` : E["aria-labelledby"] || (E["aria-label"] ? void 0 : g),
      className: te("ar-button", f),
      children: [
        /* @__PURE__ */ c("span", { className: "ar-button-labels", children: [
          /* @__PURE__ */ n(
            "span",
            {
              id: g,
              className: "ar-button-label",
              "aria-hidden": r || void 0,
              children: t
            }
          ),
          /* @__PURE__ */ c(
            "span",
            {
              id: `${g}-pending`,
              className: "ar-button-pending",
              "aria-hidden": !r,
              children: [
                /* @__PURE__ */ n("span", { className: "ar-spinner", "aria-hidden": "true" }),
                i
              ]
            }
          )
        ] }),
        o && /* @__PURE__ */ n(Z, { name: o, className: "ar-button-icon" })
      ]
    }
  );
}
function ne({
  label: e,
  hint: r,
  error: i,
  optional: a = !1,
  textarea: t = !1,
  options: o,
  unit: f,
  children: v,
  className: E = "",
  id: h,
  ...g
}) {
  const I = ae(), b = ur.count(v) === 1 && fr(v) ? v : null, p = h || b?.props.id || I, s = [
    b?.props["aria-describedby"],
    g["aria-describedby"],
    r && `${p}-hint`,
    i && `${p}-error`,
    f && `${p}-unit`
  ].filter(Boolean).join(" "), m = {
    ...g,
    id: p,
    "aria-invalid": i ? !0 : void 0,
    "aria-describedby": s || void 0,
    className: te("ar-input", b?.props.className)
  };
  let l;
  return b ? l = pr(b, {
    ...m,
    ...b.props,
    id: p,
    className: m.className,
    "aria-describedby": m["aria-describedby"],
    "aria-invalid": m["aria-invalid"]
  }) : v ? l = v : o ? l = /* @__PURE__ */ n("select", { ...m, children: o.map((u) => {
    const [q, C] = Array.isArray(u) ? u : [u.value, u.label];
    return /* @__PURE__ */ n("option", { value: q, children: C }, q);
  }) }) : t ? l = /* @__PURE__ */ n("textarea", { ...m }) : l = /* @__PURE__ */ n("input", { ...m }), /* @__PURE__ */ c("div", { className: te("ar-field", E), children: [
    /* @__PURE__ */ c("label", { htmlFor: p, children: [
      e,
      a && /* @__PURE__ */ n("span", { className: "ar-optional", children: "Optional" })
    ] }),
    /* @__PURE__ */ c("div", { className: te("ar-input-wrap", f && "ar-input-with-unit"), children: [
      l,
      f && /* @__PURE__ */ n("span", { className: "ar-unit", id: `${p}-unit`, children: f })
    ] }),
    r && /* @__PURE__ */ n("p", { className: "ar-help", id: `${p}-hint`, children: r }),
    i && /* @__PURE__ */ c("p", { className: "ar-field-error", id: `${p}-error`, children: [
      /* @__PURE__ */ n(Z, { name: "info" }),
      i
    ] })
  ] });
}
function ir(e, r) {
  if (r?.requestItems?.length && e.supportsRequestItems !== !0)
    throw new x("UNSUPPORTED_REQUEST_ITEMS", "This project store does not support independently referenced requests. Keep the reviewed references until a compatible project store is available.");
}
function oe(e, r) {
  if ([r?.context, ...(r?.requestItems || []).map((a) => a.context)].filter((a) => a?.viewerReference).some((a) => !Array.isArray(e.supportedViewerReferenceVersions) || !e.supportedViewerReferenceVersions.includes(a.viewerReference.version)))
    throw new x("UNSUPPORTED_VIEWER_REFERENCE", "This project store does not support the saved viewer reference. Keep the original view and use a compatible project store.");
}
function he(e, r, i = "UNSUPPORTED_VIEWER_REFERENCE") {
  if ((e?.viewerReference || e?.productRevision) && !M(e, r))
    throw new x(i, "The project store did not preserve the exact product version and saved view. Your original reference is still here; confirmation could not be verified.");
}
function Ve(e, r, i) {
  if (!i?.viewerReference && !i?.productRevision && !r?.context?.viewerReference && !r?.context?.productRevision && !r?.requestItems?.some((t) => t.context?.viewerReference)) return;
  oe(e, r);
  const a = z(r?.context);
  if (!M(a, r.context) || K(a) !== K(i) || i.viewerReference && !a.viewerReference)
    throw new x("INCOMPATIBLE_CONTEXT", "This project store returned a different or incomplete product reference. The saved draft has not been replaced.");
  if (r.revision || he(i, a), r.requestItems?.some((t) => t.context?.viewerReference) && !M(re(r.requestItems, a), r.requestItems))
    throw new x("INCOMPATIBLE_CONTEXT", "The saved request list contains an incomplete viewer reference. Your current input is unchanged.");
}
async function it({ repository: e, draft: r, saveDraft: i = (a) => e.saveDraft(a) }) {
  ir(e, r), oe(e, r);
  const a = await i(r);
  if (he(r?.context, a?.context), Object.hasOwn(r || {}, "requestItems") && !M(a?.requestItems, re(r.requestItems, r.context)))
    throw new x("UNSUPPORTED_REQUEST_ITEMS", "This project store did not preserve the request list. Keep the original references and use a compatible project store before continuing.");
  const t = mr(a);
  if (!e.prepareInquiryReview) return { draft: a, review: t };
  const o = await e.prepareInquiryReview(Ee(a));
  if (!o || typeof o.token != "string" || !o.token.trim() || !M(o.draft, a))
    throw new x("INVALID_REVIEW", "The prepared review does not match this saved draft. Your details are still here; review them again.");
  return { draft: a, review: Ee(o) };
}
async function at({ repository: e, review: r }) {
  ir(e, r?.draft), oe(e, r?.draft);
  const i = await e.submitInquiry(r);
  if (he(r?.draft?.context, i?.context, "INVALID_CONFIRMATION"), Object.hasOwn(r?.draft || {}, "requestItems") && !M(i?.inquiry?.requestItems, r.draft.requestItems))
    throw new x("INVALID_CONFIRMATION", "The project response did not preserve every referenced request. Confirmation could not be verified; keep this reviewed inquiry and check the project store.");
  return i;
}
const O = Ee, ot = (e) => ({ code: e?.code || "INQUIRY_ERROR", message: e?.message || "Your request could not be saved. Your input is still here. Please try again.", fields: O(e?.fields || {}) }), ce = (e) => e && { context: e.context, values: e.values, requirements: e.requirements, requestItems: e.requestItems || null, inquiryRulesVersion: e.inquiryRulesVersion || null }, st = (e) => e.revision === 0 && !e.requirements.length && !e.requestItems?.length && !Object.entries(e.values).some(([r, i]) => !["intent", "quoteScope"].includes(r) && String(i).trim());
function ct({ repository: e, autosaveDelay: r = 500, schedule: i = setTimeout, cancel: a = clearTimeout } = {}) {
  if (!e?.getDraft || !e?.saveDraft || !e?.submitInquiry) throw new TypeError("An inquiry needs a project repository.");
  let t = { draft: null, review: null, project: null, stage: "details", loading: !1, pending: "", saving: !1, dirty: !1, error: null, notice: "", supportsRequestItems: e.supportsRequestItems === !0 }, o = null, f = null, v = Promise.resolve(), E = null, h = null, g = 0, I = 0, b = !1;
  const p = /* @__PURE__ */ new Set(), s = () => {
    if (b) throw new x("DISPOSED", "This inquiry has been closed.");
  }, m = () => O(t);
  function l(d = {}) {
    if (!b) {
      t = { ...t, ...d }, t.dirty = !!(t.draft && (!o || !M(ce(t.draft), ce(o))));
      for (const y of p)
        try {
          y(m());
        } catch {
        }
    }
  }
  function u(d) {
    return l({ error: ot(d) }), d;
  }
  function q() {
    f !== null && a(f), f = null;
  }
  function C() {
    if (s(), !t.draft || t.loading || t.pending || I) throw new x("BUSY_STATE", "Wait for the current inquiry action to finish.");
    if (t.stage !== "details") throw new x("STALE_REVIEW", "Choose Edit details before changing this reviewed inquiry.");
  }
  function w() {
    if (C(), !t.supportsRequestItems) throw new x("UNSUPPORTED_REQUEST_ITEMS", "This project store does not support independently referenced requests.");
  }
  function A() {
    q();
    const d = v.catch(() => {
    }).then(async () => {
      if (b || !t.draft || t.stage === "confirmed") return null;
      const y = O(t.draft), R = g;
      if (o && M(y, o)) return O(o);
      l({ saving: !0 });
      try {
        oe(e, y);
        const N = await e.saveDraft(y);
        if (he(y.context, N?.context), Object.hasOwn(y, "requestItems") && !M(N?.requestItems, re(y.requestItems, y.context)))
          throw new x("UNSUPPORTED_REQUEST_ITEMS", "This project store did not preserve the request list. Your original references are still here; use a compatible project store before continuing.");
        if (!b && R === g && t.draft?.id === N.id) {
          const D = !M(ce(t.draft), ce(y));
          o = O(N), l({ draft: D ? { ...t.draft, revision: N.revision, updatedAt: N.updatedAt } : O(N), error: null });
        }
        return N;
      } catch (N) {
        throw !b && R === g && u(N), N;
      } finally {
        !b && R === g && l({ saving: !1 });
      }
    });
    return v = d, d;
  }
  function S() {
    q(), f = i(() => {
      f = null, A().catch(() => {
      });
    }, r);
  }
  function j(d, y) {
    if (s(), E || t.loading || I) return Promise.reject(new x("BUSY_STATE", "Wait for the current inquiry action to finish."));
    l({ pending: d, error: null });
    const R = Promise.resolve().then(y).catch((N) => {
      throw u(N), N;
    }).finally(() => {
      E === R && (E = null), l({ pending: "" });
    });
    return E = R, R;
  }
  async function Y() {
    s(), q(), I++;
    try {
      return h && await h.catch(() => {
      }), E && await E.catch(() => {
      }), await A(), !0;
    } catch {
      return !1;
    } finally {
      I--;
    }
  }
  function U(d) {
    const y = z(d), R = t.draft;
    if (K(R.context) !== K(y)) throw new x("INCOMPATIBLE_CONTEXT", "This view belongs to another product or version. Your existing draft and saved view are unchanged.");
    const N = !M(R.context.part, y.part), D = R.requirements.filter((F) => !(F.id === "stroke-confirmed" && F.part && N)), V = N && R.values.quoteScope === "part";
    l({
      draft: { ...R, context: O(y), requirements: D, values: V ? { ...R.values, quoteScope: "discuss" } : R.values },
      review: null,
      notice: V ? "View updated. Choose the requested scope again for this component." : D.length !== R.requirements.length ? "View updated. Confirm the stroke requirement again for this component." : "Current view attached. Your entered details are unchanged."
    });
  }
  async function W(d, y) {
    await A(), s();
    const R = O(t.draft), N = re(await d(O(R.requestItems || [])), R.context);
    s(), l({ draft: { ...R, requestItems: N }, review: null, error: null, notice: "" });
    try {
      return await A(), l({ notice: y }), O(t.draft.requestItems);
    } catch (D) {
      throw l({ draft: R, review: null, notice: "The request list was not changed. Your previously saved details are still here." }), D;
    }
  }
  function B(d) {
    const y = (t.draft?.requestItems || t.project?.inquiry?.requestItems || []).find((R) => R.id === d);
    if (!y) throw new x("NOT_FOUND", "This referenced request is no longer available.");
    return y;
  }
  function T(d, y, { suggestedIntent: R, suggestedScope: N } = {}) {
    return Ve(e, d, y), o = d.revision ? O(d) : null, st(d) && (["quotation", "application-review"].includes(R) && (d.values.intent = R), (["product", "discuss"].includes(N) || N === "part" && d.context.part) && (d.values.quoteScope = N)), l({ draft: d, project: null, review: null, stage: "details", notice: d.revision && !M(d.context, y) ? "Your saved draft keeps its original view. Choose Use current view to replace it." : d.revision ? "Your saved draft is ready to continue." : "" }), d.revision || S(), m();
  }
  const L = {
    getState: m,
    subscribe(d) {
      return s(), p.add(d), () => p.delete(d);
    },
    async open({ context: d, suggestedIntent: y, suggestedScope: R } = {}) {
      s();
      const N = z(d);
      if (oe(e, { context: N }), t.draft && K(t.draft.context) === K(N))
        return M(t.draft.context, N) || l({ notice: "Your draft keeps its saved view. Choose Use current view to replace it." }), m();
      if (t.project && K(t.project.context) === K(N)) return m();
      if (!await Y()) throw new x(t.error?.code || "STORAGE_UNAVAILABLE", t.error?.message || "Save this draft before opening another product.");
      const D = ++g;
      l({ loading: !0, error: null, notice: "" });
      const V = Promise.resolve().then(() => e.getDraft(N));
      h = V;
      try {
        const F = await V;
        return b || D !== g ? m() : T(F, N, { suggestedIntent: y, suggestedScope: R });
      } catch (F) {
        throw !b && D === g && u(F), F;
      } finally {
        h === V && (h = null), !b && D === g && l({ loading: !1 });
      }
    },
    updateValues(d) {
      C();
      const y = { ...t.draft.values, ...d }, R = Object.hasOwn(d, "stroke") && d.stroke !== t.draft.values.stroke ? t.draft.requirements.filter((N) => N.id !== "stroke-confirmed") : t.draft.requirements;
      l({ draft: { ...t.draft, values: y, requirements: R }, review: null, error: null, notice: "" }), S();
    },
    updateRequirements(d) {
      C(), l({ draft: { ...t.draft, requirements: O(d) }, review: null, error: null }), S();
    },
    addRequestItem({ context: d, capture: y, purpose: R = "question", notes: N = "" } = {}) {
      return w(), j("add-request", async () => {
        const D = z(y ? await y() : d || L.getContext()), V = `REQ-${globalThis.crypto.randomUUID()}`, F = await W((me) => [...me, { id: V, purpose: R, notes: N, context: D }], "Reference added. Describe what you want to ask, change or review.");
        return O(F.find((me) => me.id === V));
      });
    },
    updateRequestItem(d, { purpose: y, notes: R } = {}) {
      return w(), j("update-request", async () => {
        B(d);
        const N = await W((D) => D.map((V) => V.id !== d ? V : {
          ...V,
          ...y !== void 0 ? { purpose: y } : {},
          ...R !== void 0 ? { notes: R } : {}
        }), "Referenced request saved.");
        return O(N.find((D) => D.id === d));
      });
    },
    editRequestItem(d, { purpose: y, notes: R } = {}) {
      w(), B(d);
      const N = t.draft.requestItems.map((D) => D.id !== d ? D : {
        ...D,
        ...y !== void 0 ? { purpose: y } : {},
        ...R !== void 0 ? { notes: R } : {}
      });
      re(N, t.draft.context), l({ draft: { ...t.draft, requestItems: N }, review: null, error: null, notice: "" }), S();
    },
    removeRequestItem(d) {
      return w(), j("remove-request", async () => (B(d), W((y) => y.filter((R) => R.id !== d), "Reference removed. Your other requests are unchanged.")));
    },
    getRequestItemContext(d) {
      return s(), O(B(d).context);
    },
    restoreRequestItem(d, y) {
      return j("restore-request", async () => (await A(), y(L.getRequestItemContext(d))));
    },
    edit() {
      s(), !(t.pending || t.stage !== "review") && l({ stage: "details", review: null, error: null });
    },
    loadSavedDraft() {
      return j("reload", async () => {
        if (!t.draft) throw new x("NOT_READY", "Open a draft before loading its saved version.");
        q(), await v.catch(() => {
        });
        let d;
        try {
          d = await e.getDraft(t.draft.context);
        } catch (y) {
          throw new x("RELOAD_FAILED", `The saved draft could not be loaded. Your current entries are still here. ${y?.message || "Please try again."}`);
        }
        if (!d?.revision) throw new x("DRAFT_UNAVAILABLE", "This draft was submitted or removed in another tab. Your current entries are still here; check the saved project before starting another inquiry.");
        return Ve(e, d, t.draft.context), o = O(d), l({ draft: O(d), review: null, project: null, stage: "details", error: null, notice: "Latest saved draft loaded. Review these details again before confirming." }), O(d);
      });
    },
    save: A,
    review() {
      return j("review", async () => {
        if (!t.draft || t.stage !== "details") throw new x("STALE_REVIEW", "Open your inquiry details before reviewing.");
        const d = await it({ repository: e, draft: t.draft, saveDraft: A });
        return l({ draft: d.draft, review: d.review, stage: "review", notice: "" }), O(d.review);
      });
    },
    confirm() {
      return t.stage === "confirmed" && t.project ? Promise.resolve(O(t.project)) : t.pending === "confirm" && E ? E : j("confirm", async () => {
        if (t.stage !== "review" || !t.review) throw new x("STALE_REVIEW", "Review the complete inquiry before confirming it.");
        const d = await at({ repository: e, review: t.review });
        return o = null, q(), l({ project: d, draft: null, review: null, stage: "confirmed", notice: "" }), O(d);
      });
    },
    startAnother({ capture: d, context: y, suggestedIntent: R = "quotation", suggestedScope: N = "discuss" } = {}) {
      return j("new", async () => {
        if (t.stage !== "confirmed" || !t.project) throw new x("NOT_READY", "Confirm the current inquiry before starting another one.");
        const D = g, V = z(d ? await d() : y || t.project.context), F = await e.getDraft(V);
        if (b || D !== g) throw new x("SUPERSEDED", "The inquiry changed before the new draft could open.");
        return T(F, V, { suggestedIntent: R, suggestedScope: N });
      });
    },
    adopt(d) {
      return C(), j("capture", async () => (U(d), await A(), L.getContext()));
    },
    capture(d) {
      return C(), j("capture", async () => {
        const y = await d();
        return U(y), await A(), L.getContext();
      });
    },
    restore(d) {
      return j("restore", async () => (await A(), d(L.getContext())));
    },
    getContext() {
      s();
      const d = t.draft?.context || t.project?.context;
      if (t.loading || !d) throw new x("NOT_READY", "Wait for the saved inquiry reference to finish loading.");
      return O(d);
    },
    beforeLeave: Y,
    hasUnsavedChanges() {
      return t.dirty || t.saving;
    },
    dispose() {
      q(), ++g, b = !0, p.clear();
    }
  };
  return L;
}
function lt(e) {
  const r = { ...e.values }, i = [...e.requirements], a = !Object.entries(r).some(([t, o]) => !["intent", "quoteScope"].includes(t) && String(o).trim());
  for (const [t, o] of Object.entries(vr(e.context)))
    H(e.context, t, r)?.enabled && !String(r[t] || "").trim() && (r[t] = o);
  return a && r.stroke && !i.some((t) => t.id === "stroke-confirmed") && i.push({
    id: "stroke-confirmed",
    label: "Required carriage stroke",
    value: r.stroke,
    unit: "mm",
    source: "customer",
    confirmed: !0,
    ...e.context.part ? { part: e.context.part } : {}
  }), { ...e, values: r, requirements: i };
}
const Ue = (e) => {
  Promise.resolve(e).catch(() => {
  });
};
function dt({ context: e, editable: r, busy: i, onCapture: a, onRestore: t, session: o }) {
  const f = e.inspection?.preview, v = e.drawing, E = v?.regionLabel || e.part?.title || e.productTitle, h = v ? `${v.sheetTitle} · ${v.revisionLabel || v.revision}` : e.chapter?.title;
  return /* @__PURE__ */ c("section", { className: "ei-reference", "aria-label": "Attached product reference", children: [
    /* @__PURE__ */ c("div", { className: "ei-reference-summary", children: [
      f ? /* @__PURE__ */ n("img", { src: f.dataUrl, width: f.width, height: f.height, alt: `Saved view of ${e.part?.title || e.productTitle}` }) : /* @__PURE__ */ n("span", { className: "ei-reference-placeholder", children: /* @__PURE__ */ n(Z, { name: "document" }) }),
      /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("small", { children: v ? "Saved drawing detail" : e.inspection || e.viewerReference ? "Saved 3D view" : "Product reference" }),
        /* @__PURE__ */ n("strong", { children: E }),
        h && /* @__PURE__ */ n("span", { children: h })
      ] }),
      t && /* @__PURE__ */ n(P, { variant: "quiet", className: "ei-view", disabled: i, onClick: () => Ue(t()), children: "View" })
    ] }),
    /* @__PURE__ */ c("details", { className: "ei-reference-details", children: [
      /* @__PURE__ */ n("summary", { children: "Reference details" }),
      /* @__PURE__ */ c("dl", { children: [
        /* @__PURE__ */ c("div", { children: [
          /* @__PURE__ */ n("dt", { children: "Product" }),
          /* @__PURE__ */ n("dd", { children: e.productTitle })
        ] }),
        e.productRevision && /* @__PURE__ */ c("div", { children: [
          /* @__PURE__ */ n("dt", { children: "Product version" }),
          /* @__PURE__ */ n("dd", { children: e.productRevision })
        ] }),
        e.part && /* @__PURE__ */ c("div", { children: [
          /* @__PURE__ */ n("dt", { children: "Component" }),
          /* @__PURE__ */ n("dd", { children: e.part.title })
        ] }),
        e.chapter && /* @__PURE__ */ c("div", { children: [
          /* @__PURE__ */ n("dt", { children: "Explanation" }),
          /* @__PURE__ */ n("dd", { children: e.chapter.title })
        ] }),
        e.document && /* @__PURE__ */ c("div", { children: [
          /* @__PURE__ */ n("dt", { children: "Document" }),
          /* @__PURE__ */ c("dd", { children: [
            e.document.title,
            " · ",
            e.document.revision
          ] })
        ] }),
        v ? /* @__PURE__ */ c(G, { children: [
          /* @__PURE__ */ c("div", { children: [
            /* @__PURE__ */ n("dt", { children: "Drawing" }),
            /* @__PURE__ */ n("dd", { children: v.title })
          ] }),
          /* @__PURE__ */ c("div", { children: [
            /* @__PURE__ */ n("dt", { children: "Source version" }),
            /* @__PURE__ */ n("dd", { children: v.revisionLabel || v.revision })
          ] }),
          /* @__PURE__ */ c("div", { children: [
            /* @__PURE__ */ n("dt", { children: "Sheet" }),
            /* @__PURE__ */ n("dd", { children: v.sheetTitle })
          ] }),
          /* @__PURE__ */ c("div", { children: [
            /* @__PURE__ */ n("dt", { children: "Detail" }),
            /* @__PURE__ */ n("dd", { children: v.regionLabel })
          ] }),
          v.mappingRevision && /* @__PURE__ */ c("div", { children: [
            /* @__PURE__ */ n("dt", { children: "Associations" }),
            /* @__PURE__ */ n("dd", { children: v.mappingRevision })
          ] }),
          /* @__PURE__ */ c("div", { children: [
            /* @__PURE__ */ n("dt", { children: "Overview" }),
            /* @__PURE__ */ n("dd", { children: v.presentationRevision || "Original source reference" })
          ] }),
          /* @__PURE__ */ c("div", { children: [
            /* @__PURE__ */ n("dt", { children: "Model version" }),
            /* @__PURE__ */ n("dd", { children: e.modelRevision })
          ] })
        ] }) : /* @__PURE__ */ c("div", { children: [
          /* @__PURE__ */ n("dt", { children: "Version" }),
          /* @__PURE__ */ n("dd", { children: e.roomSnapshot ? `Product version ${e.roomSnapshot.version}` : e.modelRevision })
        ] })
      ] }),
      /* @__PURE__ */ n("p", { children: v ? "The saved source and detail remain attached. Viewed dimensions are not automatically requirements." : "Viewing context does not confirm a requirement or engineering suitability." })
    ] }),
    r && a && /* @__PURE__ */ c("div", { className: "ei-reference-update", children: [
      /* @__PURE__ */ n("span", { children: v ? "This detail stays attached while you explore." : "This view stays attached while you explore." }),
      /* @__PURE__ */ n(P, { variant: "quiet", disabled: i, pending: o.getState().pending === "capture", pendingLabel: "Attaching…", onClick: () => Ue(o.capture(a)), children: v ? "Use current detail" : "Use current view" })
    ] })
  ] });
}
const be = (e) => {
  Promise.resolve(e).catch(() => {
  });
};
function ut({ context: e }) {
  const r = e.drawing;
  return /* @__PURE__ */ c("dl", { className: "ar-request-facts", children: [
    /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ n("dt", { children: "Product" }),
      /* @__PURE__ */ n("dd", { children: e.productTitle })
    ] }),
    e.part && /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ n("dt", { children: "Component" }),
      /* @__PURE__ */ n("dd", { children: e.part.title })
    ] }),
    /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ n("dt", { children: "Model version" }),
      /* @__PURE__ */ n("dd", { children: e.modelRevision })
    ] }),
    e.roomSnapshot && /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ n("dt", { children: "Product version" }),
      /* @__PURE__ */ n("dd", { children: e.roomSnapshot.version })
    ] }),
    e.chapter && /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ n("dt", { children: "Explanation" }),
      /* @__PURE__ */ n("dd", { children: e.chapter.title })
    ] }),
    e.document && /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ n("dt", { children: "Document" }),
      /* @__PURE__ */ c("dd", { children: [
        e.document.title,
        " · ",
        e.document.revision
      ] })
    ] }),
    r && /* @__PURE__ */ c(G, { children: [
      /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("dt", { children: "Drawing" }),
        /* @__PURE__ */ n("dd", { children: r.title })
      ] }),
      /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("dt", { children: "Source version" }),
        /* @__PURE__ */ n("dd", { children: r.revisionLabel || r.revision })
      ] }),
      /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("dt", { children: "Sheet" }),
        /* @__PURE__ */ n("dd", { children: r.sheetTitle })
      ] }),
      /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("dt", { children: "Detail" }),
        /* @__PURE__ */ n("dd", { children: r.regionLabel })
      ] }),
      /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("dt", { children: "Associations" }),
        /* @__PURE__ */ n("dd", { children: r.mappingRevision || "Original associations" })
      ] }),
      /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("dt", { children: "Overview" }),
        /* @__PURE__ */ n("dd", { children: r.presentationRevision || "Original source reference" })
      ] })
    ] })
  ] });
}
function ar({ item: e }) {
  const { context: r } = e;
  return /* @__PURE__ */ n("small", { className: "ar-request-origin", children: r.drawing ? `${r.drawing.sheetTitle} · ${r.drawing.revisionLabel || r.drawing.revision}` : r.inspection ? "Saved 3D view" : r.part ? "Component reference" : "Product reference" });
}
function or({ items: e = [], onOpen: r, hrefFor: i, title: a = "Referenced requests" }) {
  return e.length ? /* @__PURE__ */ c("section", { className: "ar-request-items ar-request-summary", "aria-label": a, children: [
    /* @__PURE__ */ c("div", { className: "ar-request-heading", children: [
      /* @__PURE__ */ n("h3", { children: a }),
      /* @__PURE__ */ n("span", { children: e.length })
    ] }),
    /* @__PURE__ */ n("ol", { className: "ar-request-list", children: e.map((t) => /* @__PURE__ */ c("li", { "data-request-item": t.id, children: [
      /* @__PURE__ */ c("div", { className: "ar-request-row", children: [
        /* @__PURE__ */ c("div", { children: [
          /* @__PURE__ */ n("strong", { children: Re(t) }),
          /* @__PURE__ */ n(ar, { item: t })
        ] }),
        r ? /* @__PURE__ */ n(P, { variant: "quiet", onClick: () => r(t.context, t), children: "View reference" }) : i && /* @__PURE__ */ c("a", { className: "ar-button", "data-variant": "quiet", href: i(t), children: [
          "View reference ",
          /* @__PURE__ */ n(Z, { name: "external" })
        ] })
      ] }),
      /* @__PURE__ */ n("span", { className: "ar-request-purpose", children: wr(t.purpose) }),
      /* @__PURE__ */ n("p", { className: "ar-request-notes", children: t.notes }),
      /* @__PURE__ */ c("details", { className: "ar-request-reference", children: [
        /* @__PURE__ */ n("summary", { children: "Exact reference" }),
        t.context.inspection?.preview && /* @__PURE__ */ n(
          "img",
          {
            className: "ar-request-preview",
            src: t.context.inspection.preview.dataUrl,
            width: t.context.inspection.preview.width,
            height: t.context.inspection.preview.height,
            alt: `Saved view of ${Re(t)}`
          }
        ),
        /* @__PURE__ */ n(ut, { context: t.context })
      ] })
    ] }, t.id)) }),
    /* @__PURE__ */ n("p", { className: "ar-request-footnote", children: "These are customer requests for discussion. Inclusion in a quotation requires seller review." })
  ] }) : null;
}
function ft({ state: e, session: r, busy: i, onCapture: a, onRestore: t }) {
  const o = e.draft?.requestItems || [], f = e.error?.fields || {}, [v, E] = xe(null), h = ee(null), g = ee(null), I = ae();
  if (J(() => {
    E(null);
  }, [e.draft?.id]), J(() => {
    const s = o.find((m) => f[`requestItem-${m.id}`]);
    s && E(s.id);
  }, [e.error]), !e.supportsRequestItems) return null;
  async function b() {
    const s = await r.addRequestItem(a ? { capture: a } : {});
    E(s.id), requestAnimationFrame(() => h.current?.querySelector(`[data-request-item="${s.id}"] textarea`)?.focus());
  }
  async function p(s) {
    await r.removeRequestItem(s), E((m) => m === s ? null : m), requestAnimationFrame(() => g.current?.focus());
  }
  return /* @__PURE__ */ c("section", { ref: h, className: "ar-request-items ar-request-editor", "aria-label": "Requests about details", children: [
    /* @__PURE__ */ c("div", { className: "ar-request-heading", children: [
      /* @__PURE__ */ n("h3", { children: "Requests about details" }),
      o.length > 0 && /* @__PURE__ */ n("span", { children: o.length })
    ] }),
    /* @__PURE__ */ n("p", { className: "ar-request-intro", children: "Keep a separate question with each view. Continue exploring to add another." }),
    o.length > 0 && /* @__PURE__ */ n("ol", { className: "ar-request-list", children: o.map((s) => {
      const m = v === s.id, l = `${I}-${s.id}`, u = f[`requestItem-${s.id}`];
      return /* @__PURE__ */ c("li", { "data-request-item": s.id, children: [
        /* @__PURE__ */ c(
          "button",
          {
            type: "button",
            className: "ar-request-toggle",
            "aria-expanded": m,
            "aria-controls": l,
            onClick: () => E(m ? null : s.id),
            children: [
              /* @__PURE__ */ c("span", { children: [
                /* @__PURE__ */ n("strong", { children: Re(s) }),
                /* @__PURE__ */ n(ar, { item: s }),
                !m && /* @__PURE__ */ n("small", { children: s.notes || "Add your question" })
              ] }),
              /* @__PURE__ */ n("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.6", "aria-hidden": "true", children: /* @__PURE__ */ n("path", { d: m ? "m6 15 6-6 6 6" : "m6 9 6 6 6-6" }) })
            ]
          }
        ),
        m && /* @__PURE__ */ c("div", { id: l, className: "ar-request-edit-fields", children: [
          /* @__PURE__ */ n(
            ne,
            {
              label: "Purpose",
              name: `request-purpose-${s.id}`,
              value: s.purpose,
              disabled: i,
              options: gr.map((q) => [q.value, q.label]),
              onChange: (q) => r.editRequestItem(s.id, { purpose: q.target.value })
            }
          ),
          /* @__PURE__ */ n(
            ne,
            {
              label: "Your request",
              name: `request-notes-${s.id}`,
              textarea: !0,
              rows: 3,
              maxLength: 2e3,
              required: !0,
              value: s.notes,
              error: u,
              disabled: i,
              placeholder: "What should we ask, change or review here?",
              onChange: (q) => r.editRequestItem(s.id, { notes: q.target.value })
            }
          ),
          /* @__PURE__ */ c("div", { className: "ar-request-item-actions", children: [
            t && /* @__PURE__ */ n(P, { variant: "quiet", disabled: i, onClick: () => be(t(s.id)), children: "View reference" }),
            /* @__PURE__ */ n(P, { variant: "quiet", disabled: i, onClick: () => be(p(s.id)), children: "Remove request" })
          ] })
        ] })
      ] }, s.id);
    }) }),
    f.requestItems && /* @__PURE__ */ n("p", { className: "ar-request-error", role: "alert", children: f.requestItems }),
    /* @__PURE__ */ n(
      P,
      {
        ref: g,
        variant: "secondary",
        disabled: i || o.length >= ve,
        pending: e.pending === "add-request",
        pendingLabel: "Attaching view…",
        className: "ar-request-add",
        onClick: () => be(b()),
        icon: "plus",
        children: a ? e.draft.context.drawing ? "Add current detail" : "Add current view" : "Add referenced request"
      }
    ),
    o.length >= ve && /* @__PURE__ */ c("p", { className: "ar-request-footnote", children: [
      "This inquiry holds up to ",
      ve,
      " referenced requests."
    ] })
  ] });
}
const _e = Object.freeze({
  eyebrow: "YOUR INQUIRY",
  detailsTitle: "Tell us what you need.",
  reviewTitle: "Review your request.",
  confirmedTitle: "Inquiry saved.",
  requirementsStep: "Requirements",
  reviewStep: "Review & confirm",
  stepsLabel: "Inquiry steps",
  minimizeLabel: "Minimize inquiry",
  closeLabel: "Close inquiry and keep draft",
  errorTitle: "Check your inquiry",
  resumeLabel: "Continue your inquiry",
  savedLabel: "Inquiry saved",
  draftLabel: "Saved inquiry draft",
  productLabel: "Product inquiry",
  loadingLabel: "Opening your saved inquiry…",
  reviewButton: "Review inquiry",
  confirmButton: "Confirm demo inquiry",
  receiptTitle: "Your inquiry and saved view are together.",
  receiptDescription: "You can continue exploring or open the project to follow the quotation and conversation.",
  receiptNote: "This fictional inquiry is saved in this browser. Nothing has been sent.",
  openProjectButton: "Open project",
  startAnotherButton: "Start another inquiry",
  saveNote: "Demo only · Nothing is sent",
  reviewNote: "Confirmation saves these exact details and this reference as one project. Engineering suitability remains subject to review."
});
function pt(e = {}) {
  if (!e || typeof e != "object" || Array.isArray(e)) throw new TypeError("Provide an inquiry presentation object.");
  if (e.fixedIntent !== void 0 && !Me.some((a) => a.value === e.fixedIntent)) throw new TypeError("Choose a supported fixed inquiry intent.");
  if (e.fields !== void 0 && (!Array.isArray(e.fields) || !e.fields.includes("application") || new Set(e.fields).size !== e.fields.length || e.fields.some((a) => !De.includes(a))))
    throw new TypeError("Inquiry fields must be unique supported fields and include application.");
  if (e.fields && !e.fields.includes("quantity") && e.fixedIntent !== "application-review") throw new TypeError("Hide quantity only for a fixed application-review inquiry.");
  if (e.renderReview !== void 0 && typeof e.renderReview != "function") throw new TypeError("The custom review must be a rendering function.");
  const r = { ..._e };
  for (const [a, t] of Object.entries(e.labels || {})) {
    if (!Object.hasOwn(_e, a) || typeof t != "string" || !t.trim() || t.length > 1e3) throw new TypeError(`Invalid inquiry label: ${a}.`);
    r[a] = t;
  }
  const i = {};
  for (const [a, t] of Object.entries(e.fieldLabels || {})) {
    if (!De.includes(a) || typeof t != "string" || !t.trim() || t.length > 100) throw new TypeError(`Invalid inquiry field label: ${a}.`);
    i[a] = t;
  }
  return Object.freeze({
    fixedIntent: e.fixedIntent || null,
    fields: e.fields ? Object.freeze([...e.fields]) : null,
    showScope: e.showScope !== !1,
    labels: Object.freeze(r),
    fieldLabels: Object.freeze(i),
    renderReview: e.renderReview
  });
}
const sr = (e, r) => !e.fields || e.fields.includes(r), Ce = (e, r) => e.fixedIntent && r && r.values.intent !== e.fixedIntent ? "This saved draft uses a different request purpose. Open it with its original form; your entries have not been changed." : "", $ = (e) => {
  Promise.resolve(e).catch(() => {
  });
}, ye = (e, r) => {
  try {
    e?.(r);
  } catch {
  }
}, ht = (e, r) => e.stage === "confirmed" ? r.confirmedTitle : e.stage === "review" ? r.reviewTitle : r.detailsTitle, cr = (e) => e.loading ? "Opening draft…" : e.saving ? "Saving…" : e.error && e.dirty ? "Draft not saved" : e.dirty ? "Unsaved changes" : e.draft?.updatedAt || e.stage === "confirmed" ? "Saved in this browser" : "Saves as you type";
function mt({ state: e, session: r, formId: i, disabled: a, presentation: t, onReview: o }) {
  const { draft: f, error: v, pending: E } = e, h = f.values, g = f.context, I = v?.fields || {}, b = h.intent === "application-review", p = (u) => sr(t, u) && H(g, u, h)?.enabled, s = (u, q = {}) => {
    const C = H(g, u, h);
    return p(u) ? /* @__PURE__ */ n(
      ne,
      {
        ...q,
        name: u,
        label: t.fieldLabels[u] || C.label,
        hint: C.hint || void 0,
        unit: C.unit || void 0,
        required: C.required,
        optional: !C.required,
        error: I[u],
        value: h[u] || "",
        onChange: (w) => r.updateValues({ [u]: w.target.value })
      },
      u
    ) : null;
  }, m = /* @__PURE__ */ c("div", { className: "ei-field-pair", children: [
    s("quantity", { type: "number", min: 1, max: 1e5, step: 1, inputMode: "numeric", placeholder: b ? "To discuss" : "e.g. 20" }),
    s("targetWeeks", { type: "number", min: 1, max: 104, step: 1, inputMode: "numeric", placeholder: "To discuss" })
  ] }), l = ["stroke", "load", "notes"].some(p) || f.requirements.length > 0;
  return /* @__PURE__ */ n("form", { id: i, className: "ei-form", noValidate: !0, onSubmit: (u) => {
    u.preventDefault(), $(o());
  }, children: /* @__PURE__ */ c("fieldset", { disabled: a || !!E, children: [
    !t.fixedIntent && /* @__PURE__ */ n(
      ne,
      {
        label: "I want to",
        name: "intent",
        value: h.intent || "",
        error: I.intent,
        options: [...h.intent ? [] : [["", "Not specified"]], ...Me.map((u) => [u.value, u.label])],
        onChange: (u) => r.updateValues({ intent: u.target.value })
      }
    ),
    s("application", { textarea: !0, rows: 3, maxLength: 2e3, placeholder: b ? "Describe your application or question…" : "Describe the application you need quoted…" }),
    t.showScope && /* @__PURE__ */ n(
      ne,
      {
        label: b ? "Scope to discuss" : "Requested quote scope",
        name: "quoteScope",
        value: h.quoteScope || "",
        error: I.quoteScope,
        options: [["", "Not specified"], ...qr.filter((u) => u.value !== "part" || g.part).map((u) => [u.value, u.value === "part" ? `Selected component · ${g.part.title}` : u.label])],
        onChange: (u) => r.updateValues({ quoteScope: u.target.value }),
        hint: "A viewed component is a reference. Choose the scope separately."
      }
    ),
    !b && m,
    l && /* @__PURE__ */ c(qe, { title: "Technical details", note: "Optional", openForError: !!(I.stroke || I.load || I.notes || I.requirements), defaultOpen: !!(h.stroke || h.load || h.notes || f.requirements.length), children: [
      /* @__PURE__ */ c("div", { className: "ei-field-pair", children: [
        s("stroke", { type: "number", min: 0, step: "any", inputMode: "decimal", maxLength: 100, placeholder: "To discuss" }),
        s("load", { maxLength: 200, placeholder: "Include the unit…" })
      ] }),
      s("notes", { textarea: !0, rows: 3, maxLength: 2e3 }),
      p("stroke") && h.stroke?.trim() && /* @__PURE__ */ c("label", { className: "ei-requirement-check", children: [
        /* @__PURE__ */ n(
          "input",
          {
            type: "checkbox",
            checked: f.requirements.some((u) => u.id === "stroke-confirmed"),
            onChange: (u) => r.updateRequirements(u.target.checked ? [...f.requirements.filter((q) => q.id !== "stroke-confirmed"), { id: "stroke-confirmed", label: "Required carriage stroke", value: h.stroke, unit: "mm", source: "customer", confirmed: !0, ...g.part ? { part: g.part } : {} }] : f.requirements.filter((q) => q.id !== "stroke-confirmed"))
          }
        ),
        /* @__PURE__ */ c("span", { children: [
          "Include my stroke requirement for engineering review",
          /* @__PURE__ */ n("small", { children: "Editing the stroke or attached component clears this confirmation." })
        ] })
      ] }),
      f.requirements.filter((u) => u.id !== "stroke-confirmed").map((u) => /* @__PURE__ */ c("div", { className: "ei-requirement-row", children: [
        /* @__PURE__ */ c("label", { children: [
          /* @__PURE__ */ n("input", { type: "checkbox", checked: u.confirmed, onChange: (q) => r.updateRequirements(f.requirements.map((C) => C.id === u.id ? { ...C, confirmed: q.target.checked } : C)) }),
          /* @__PURE__ */ c("span", { children: [
            u.label,
            ": ",
            u.value,
            " ",
            u.unit
          ] })
        ] }),
        /* @__PURE__ */ n(P, { variant: "quiet", onClick: () => r.updateRequirements(f.requirements.filter((q) => q.id !== u.id)), children: "Remove" })
      ] }, u.id)),
      I.requirements && /* @__PURE__ */ n("p", { className: "ei-field-error", role: "alert", children: I.requirements })
    ] }),
    b && ["quantity", "targetWeeks"].some(p) && /* @__PURE__ */ c(qe, { title: "Quantity & timing", note: "Optional", openForError: !!(I.quantity || I.targetWeeks), defaultOpen: !!(h.quantity || h.targetWeeks), children: [
      m,
      /* @__PURE__ */ n("p", { className: "ei-hint", children: "Leave unknown quantities open for discussion." })
    ] }),
    ["name", "company", "email"].some(p) && /* @__PURE__ */ c(qe, { title: "Contact details", note: "Optional in this demo", openForError: !!(I.name || I.company || I.email), defaultOpen: !!(h.name || h.company || h.email), children: [
      s("name", { maxLength: 120, autoComplete: "name" }),
      s("company", { maxLength: 160, autoComplete: "organization" }),
      s("email", { type: "email", inputMode: "email", maxLength: 254, autoComplete: "email", spellCheck: !1 })
    ] })
  ] }) });
}
function qe({ title: e, note: r, children: i, defaultOpen: a, openForError: t }) {
  const [o, f] = xe(!!a);
  return J(() => {
    t && f(!0);
  }, [t]), /* @__PURE__ */ c("details", { className: "ei-disclosure", open: o, onToggle: (v) => f(v.currentTarget.open), children: [
    /* @__PURE__ */ c("summary", { children: [
      /* @__PURE__ */ n("strong", { children: e }),
      /* @__PURE__ */ n("small", { children: r }),
      /* @__PURE__ */ n("span", { "aria-hidden": "true", children: o ? "−" : "+" })
    ] }),
    /* @__PURE__ */ n("div", { children: i })
  ] });
}
function vt({ draft: e, presentation: r }) {
  const { values: i, context: a } = e, t = ["quantity", "targetWeeks", "stroke", "load"].filter((o) => sr(r, o) && H(a, o, i)?.enabled || i[o]);
  return /* @__PURE__ */ c("div", { className: "ei-review", "aria-label": "Reviewed inquiry", children: [
    /* @__PURE__ */ c("dl", { className: "ei-facts", children: [
      /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("dt", { children: "Purpose" }),
        /* @__PURE__ */ n("dd", { children: $e(i) })
      ] }),
      r.showScope && /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("dt", { children: "Requested scope" }),
        /* @__PURE__ */ n("dd", { children: br(i, a) })
      ] })
    ] }),
    /* @__PURE__ */ c("section", { children: [
      /* @__PURE__ */ n("h3", { children: H(a, "application", i)?.label || "Application" }),
      /* @__PURE__ */ n("p", { children: i.application })
    ] }),
    /* @__PURE__ */ n("dl", { className: "ei-facts", children: t.map((o) => /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ n("dt", { children: H(a, o, i)?.label || o }),
      /* @__PURE__ */ n("dd", { children: i[o] ? `${i[o]}${o === "quantity" ? " units" : o === "targetWeeks" ? " weeks requested" : o === "stroke" ? " mm" : ""}` : "To discuss" })
    ] }, o)) }),
    i.notes && /* @__PURE__ */ c("section", { children: [
      /* @__PURE__ */ n("h3", { children: H(a, "notes", i)?.label || "Notes" }),
      /* @__PURE__ */ n("p", { children: i.notes })
    ] }),
    e.requirements.length > 0 && /* @__PURE__ */ c("section", { children: [
      /* @__PURE__ */ n("h3", { children: "Confirmed requirements" }),
      /* @__PURE__ */ n("ul", { children: e.requirements.map((o) => /* @__PURE__ */ c("li", { children: [
        o.label,
        ": ",
        o.value,
        " ",
        o.unit,
        o.part && /* @__PURE__ */ n("small", { children: o.part.title })
      ] }, o.id)) })
    ] }),
    ["name", "company", "email"].some((o) => i[o]) && /* @__PURE__ */ c("section", { children: [
      /* @__PURE__ */ n("h3", { children: "Contact" }),
      /* @__PURE__ */ n("dl", { className: "ei-facts", children: ["name", "company", "email"].filter((o) => i[o]).map((o) => /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("dt", { children: H(a, o, i)?.label || o }),
        /* @__PURE__ */ n("dd", { children: i[o] })
      ] }, o)) })
    ] }),
    /* @__PURE__ */ n("p", { className: "ei-confirm-note", children: r.labels.reviewNote })
  ] });
}
class wt extends lr.Component {
  state = { unavailable: !1 };
  static getDerivedStateFromError() {
    return { unavailable: !0 };
  }
  componentDidMount() {
    this.props.onUnavailable(this.state.unavailable);
  }
  componentDidCatch() {
    this.props.onUnavailable(!0);
  }
  render() {
    if (this.state.unavailable) return /* @__PURE__ */ n("div", { className: "ei-message ei-error", role: "alert", children: "The complete review could not be displayed. Your draft is unchanged. Choose Edit details and try reviewing again." });
    const { review: r, draft: i, presentation: a } = this.props;
    return /* @__PURE__ */ c(G, { children: [
      /* @__PURE__ */ n(or, { items: i.requestItems }),
      a.renderReview ? /* @__PURE__ */ n(gt, { render: a.renderReview, review: r, draft: i }) : /* @__PURE__ */ n(vt, { draft: i, presentation: a })
    ] });
  }
}
function gt({ render: e, review: r, draft: i }) {
  const a = e({ review: r, draft: i });
  if (a == null || a === !1 || a === "") throw new Error("A custom review must display the reviewed record.");
  return /* @__PURE__ */ n("div", { className: "ei-review ei-client-review", "aria-label": "Reviewed request", children: a });
}
function bt({ state: e, ui: r, session: i, controls: a, callbacks: t }) {
  const o = ee(null), f = ee(null), v = ee(null), [E, h] = xe(!1), g = ae(), I = ae(), b = e.draft?.context || e.project?.context, { presentation: p } = t, { labels: s } = p, m = Ce(p, e.draft), l = e.loading || !!e.pending || r.leaving, u = ["CONFLICT", "STALE_REVIEW", "RELOAD_FAILED", "DRAFT_UNAVAILABLE"].includes(e.error?.code);
  return J(() => {
    h(!1);
  }, [e.draft?.id, e.draft?.revision, e.stage, !!e.error]), J(() => {
    if (!E) return;
    const q = requestAnimationFrame(() => f.current?.querySelector("[data-reload-warning]")?.focus({ preventScroll: !0 }));
    return () => cancelAnimationFrame(q);
  }, [E]), J(() => {
    if (!r.open || !r.expanded) return;
    const q = requestAnimationFrame(() => {
      o.current?.focus({ preventScroll: !0 }), v.current && (v.current.scrollTop = 0);
    });
    return () => cancelAnimationFrame(q);
  }, [r.open, r.expanded, e.stage]), J(() => {
    if (!r.open || !r.expanded || !e.error) return;
    const q = requestAnimationFrame(() => {
      const C = f.current?.querySelector('[aria-invalid="true"], [role="alert"]');
      if (C && (C.matches("input,select,textarea,button") || (C.tabIndex = -1), C.focus({ preventScroll: !0 }), v.current)) {
        const w = C.getBoundingClientRect(), A = v.current.getBoundingClientRect();
        v.current.scrollTop += w.top - A.top - 24;
      }
    });
    return () => cancelAnimationFrame(q);
  }, [e.error, r.open, r.expanded]), r.open ? r.expanded ? /* @__PURE__ */ c("section", { ref: f, className: "room-ui ei-panel", role: "dialog", "aria-modal": "false", "aria-labelledby": g, "aria-busy": e.loading || void 0, "data-stage": e.stage, children: [
    /* @__PURE__ */ c("header", { className: "ei-header", children: [
      /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("span", { className: "ei-eyebrow", children: s.eyebrow }),
        /* @__PURE__ */ n("h2", { id: g, ref: o, tabIndex: -1, children: ht(e, s) })
      ] }),
      /* @__PURE__ */ c("div", { className: "ei-window-actions", children: [
        /* @__PURE__ */ n("button", { type: "button", className: "ei-icon-button", "aria-label": s.minimizeLabel, disabled: l, onClick: () => $(a.minimize()), children: "−" }),
        /* @__PURE__ */ n("button", { type: "button", className: "ei-icon-button", "aria-label": s.closeLabel, disabled: l, onClick: () => $(a.close()), children: "×" })
      ] })
    ] }),
    e.stage !== "confirmed" && /* @__PURE__ */ c("ol", { className: "ei-progress", "aria-label": s.stepsLabel, children: [
      /* @__PURE__ */ c("li", { "aria-current": e.stage === "details" ? "step" : void 0, "data-complete": e.stage === "review", children: [
        /* @__PURE__ */ n("span", { children: e.stage === "review" ? "✓" : "1" }),
        s.requirementsStep
      ] }),
      /* @__PURE__ */ c("li", { "aria-current": e.stage === "review" ? "step" : void 0, children: [
        /* @__PURE__ */ n("span", { children: "2" }),
        s.reviewStep
      ] })
    ] }),
    /* @__PURE__ */ c("div", { ref: v, className: "ei-scroll", children: [
      e.error && /* @__PURE__ */ c("div", { className: "ei-message ei-error", role: "alert", children: [
        /* @__PURE__ */ n("strong", { children: s.errorTitle }),
        /* @__PURE__ */ n("p", { children: e.error.message }),
        u && !E && /* @__PURE__ */ n(P, { variant: "quiet", disabled: l, "data-load-saved": !0, onClick: () => h(!0), children: "Load saved draft" }),
        u && E && /* @__PURE__ */ c("div", { className: "ei-reload-choice", children: [
          /* @__PURE__ */ n("p", { "data-reload-warning": !0, tabIndex: -1, children: "Your current entries will be replaced by the latest saved draft. Keep your edits here until you are ready to replace them." }),
          /* @__PURE__ */ c("div", { children: [
            /* @__PURE__ */ n(P, { variant: "quiet", disabled: l, onClick: () => {
              h(!1), requestAnimationFrame(() => f.current?.querySelector("[data-load-saved]")?.focus({ preventScroll: !0 }));
            }, children: "Keep my edits" }),
            /* @__PURE__ */ n(P, { variant: "secondary", disabled: l, onClick: () => $(i.loadSavedDraft()), children: "Replace with saved draft" })
          ] })
        ] }),
        !u && e.dirty && !Object.keys(e.error.fields || {}).length && /* @__PURE__ */ n(P, { variant: "quiet", disabled: l, onClick: () => $(i.save()), children: "Retry saving draft" })
      ] }),
      m && /* @__PURE__ */ n("div", { className: "ei-message ei-error", role: "alert", children: m }),
      e.notice && /* @__PURE__ */ n("p", { className: "ei-message", role: "status", children: e.notice }),
      e.loading ? /* @__PURE__ */ n("p", { className: "ei-loading", role: "status", children: s.loadingLabel }) : /* @__PURE__ */ c(G, { children: [
        b && /* @__PURE__ */ n(dt, { context: b, editable: e.stage === "details", busy: l, onCapture: t.onCapture, onRestore: t.onRestore ? a.restore : void 0, session: i }),
        e.draft && e.stage === "details" && /* @__PURE__ */ n(ft, { state: e, session: i, busy: l, onCapture: t.onCapture, onRestore: t.onRestore ? a.restoreItem : void 0 }),
        e.draft && (e.stage === "review" ? /* @__PURE__ */ n(wt, { review: e.review, draft: e.review?.draft || e.draft, presentation: p, onUnavailable: a.reviewUnavailable }, e.review?.token) : /* @__PURE__ */ n(mt, { state: e, session: i, formId: I, disabled: l, presentation: p, onReview: a.review })),
        e.stage === "confirmed" && e.project && /* @__PURE__ */ n(or, { items: e.project.inquiry.requestItems, onOpen: t.onRestore ? (q, C) => $(a.restoreItem(C.id)) : void 0 }),
        e.stage === "confirmed" && e.project && /* @__PURE__ */ c("div", { className: "ei-receipt", children: [
          /* @__PURE__ */ n("span", { className: "ei-receipt-mark", children: /* @__PURE__ */ n(Z, { name: "check" }) }),
          /* @__PURE__ */ n("h3", { children: s.receiptTitle }),
          /* @__PURE__ */ n("p", { children: s.receiptDescription }),
          /* @__PURE__ */ c("dl", { className: "ei-facts", children: [
            /* @__PURE__ */ c("div", { children: [
              /* @__PURE__ */ n("dt", { children: "Project" }),
              /* @__PURE__ */ n("dd", { children: e.project.id })
            ] }),
            /* @__PURE__ */ c("div", { children: [
              /* @__PURE__ */ n("dt", { children: "Purpose" }),
              /* @__PURE__ */ n("dd", { children: $e(e.project.inquiry.values) })
            ] })
          ] }),
          /* @__PURE__ */ n("p", { className: "ei-hint", children: s.receiptNote }),
          t.allowAnother && /* @__PURE__ */ n(P, { variant: "secondary", disabled: l, pending: e.pending === "new", pendingLabel: "Attaching current view…", onClick: () => $(i.startAnother({ capture: t.onCapture, suggestedIntent: p.fixedIntent || "quotation" })), children: s.startAnotherButton })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ c("footer", { className: "ei-footer", children: [
      /* @__PURE__ */ c("div", { className: "ei-save-state", role: "status", "aria-live": "polite", children: [
        /* @__PURE__ */ n("span", { children: cr(e) }),
        /* @__PURE__ */ n("small", { children: s.saveNote })
      ] }),
      /* @__PURE__ */ n("div", { className: "ei-actions", children: e.stage === "confirmed" ? /* @__PURE__ */ c(G, { children: [
        /* @__PURE__ */ n(P, { variant: "secondary", disabled: l, onClick: () => $(a.minimize()), children: "Keep exploring" }),
        t.onProject && /* @__PURE__ */ c(P, { disabled: l, onClick: () => $(a.openProject()), children: [
          s.openProjectButton,
          " ",
          /* @__PURE__ */ n("span", { "aria-hidden": "true", children: "→" })
        ] })
      ] }) : e.stage === "review" ? /* @__PURE__ */ c(G, { children: [
        /* @__PURE__ */ n(P, { variant: "secondary", disabled: l, onClick: () => i.edit(), children: "Edit details" }),
        /* @__PURE__ */ n(P, { disabled: l || !!m || r.reviewUnavailable, pending: e.pending === "confirm", pendingLabel: "Saving…", onClick: () => $(a.confirm()), children: s.confirmButton })
      ] }) : /* @__PURE__ */ c(G, { children: [
        /* @__PURE__ */ n(P, { variant: "quiet", disabled: l, onClick: () => $(a.minimize()), children: "Keep exploring" }),
        /* @__PURE__ */ c(P, { type: "submit", form: I, disabled: l || !e.draft || !!m, pending: e.pending === "review", pendingLabel: "Preparing…", children: [
          s.reviewButton,
          " ",
          /* @__PURE__ */ n("span", { "aria-hidden": "true", children: "→" })
        ] })
      ] }) })
    ] })
  ] }) : /* @__PURE__ */ n("div", { className: "room-ui ei-minimized", "aria-label": s.draftLabel, children: /* @__PURE__ */ c("button", { type: "button", className: "ei-resume", onClick: a.expand, children: [
    /* @__PURE__ */ n("span", { className: "ei-resume-mark", children: /* @__PURE__ */ n(Z, { name: e.stage === "confirmed" ? "check" : "document" }) }),
    /* @__PURE__ */ c("span", { children: [
      /* @__PURE__ */ n("strong", { children: e.stage === "confirmed" ? s.savedLabel : s.resumeLabel }),
      /* @__PURE__ */ n("small", { children: b?.part?.title || b?.productTitle || s.productLabel })
    ] }),
    /* @__PURE__ */ n("span", { "aria-hidden": "true", children: "↑" })
  ] }) }) : null;
}
async function yt(e, { repository: r = yr(), context: i, onCapture: a, onRestore: t, onProject: o, onState: f, onClose: v, allowAnother: E = !0, presentation: h } = {}) {
  if (!e?.ownerDocument) throw new TypeError("Provide an inquiry mount element.");
  const g = e.ownerDocument, I = g.defaultView, b = pt(h), p = ct({ repository: r }), s = hr(e), m = { onCapture: a, onRestore: t, onProject: o, allowAnother: E, presentation: b };
  let l = p.getState(), u = { open: !1, expanded: !1, leaving: !1 }, q = !1, C = null;
  const w = new AbortController();
  e.classList.add("embedded-inquiry-host");
  const A = () => {
    q || (s.render(/* @__PURE__ */ n(bt, { state: l, ui: u, session: p, controls: U, callbacks: m })), ye(f, {
      open: u.open,
      expanded: u.expanded,
      busy: l.loading || !!l.pending || u.leaving,
      draftId: l.draft?.id || null,
      hasDraft: !!l.draft,
      stage: l.stage,
      status: cr(l),
      projectId: l.project?.id || null,
      errorCode: l.error?.code || (u.reviewUnavailable ? "REVIEW_UNAVAILABLE" : null)
    }));
  }, S = (T) => {
    u = { ...u, ...T }, A();
  }, j = () => {
    C?.isConnected && !C.matches(':disabled, [aria-disabled="true"]') && !C.closest("[inert]") && C.getClientRects().length && I.getComputedStyle(C).visibility !== "hidden" && C.focus({ preventScroll: !0 });
  };
  async function Y(T = !1) {
    if (q || u.leaving || !u.open) return !1;
    S({ leaving: !0 });
    const L = await p.beforeLeave();
    return q ? !1 : (S(L ? { leaving: !1, expanded: !1, ...T ? { open: !1 } : {} } : { leaving: !1, expanded: !0 }), L && (j(), T && ye(v)), L);
  }
  const U = {
    reviewUnavailable(T) {
      u.reviewUnavailable !== T && S({ reviewUnavailable: T });
    },
    review({ fillSample: T = !1 } = {}) {
      if (!u.open || !u.expanded) throw new Error("Reopen the inquiry before reviewing it.");
      const L = Ce(b, l.draft);
      if (L) throw new Error(L);
      if (T) {
        const d = lt(p.getState().draft);
        p.updateValues(d.values), p.updateRequirements(d.requirements);
      }
      return p.review();
    },
    confirm() {
      if (!u.open || !u.expanded || u.reviewUnavailable) throw new Error("Reopen and review the complete request before confirming it.");
      const T = Ce(b, l.draft);
      if (T) throw new Error(T);
      return p.confirm();
    },
    minimize: () => Y(!1),
    close: () => Y(!0),
    expand: () => S({ open: !0, expanded: !0 }),
    async restore() {
      await p.restore(t), I.matchMedia("(max-width: 760px)").matches && await U.minimize();
    },
    async restoreItem(T) {
      await p.restoreRequestItem(T, t), I.matchMedia("(max-width: 760px)").matches && await U.minimize();
    },
    async openProject() {
      !l.project || !await p.beforeLeave() || await o?.(l.project);
    }
  }, W = p.subscribe((T) => {
    T.stage === "review" && (l.stage !== "review" || l.review?.token !== T.review?.token) && (u = { ...u, reviewUnavailable: !0 }), l = T, A();
  }), B = () => {
    const T = I.visualViewport;
    e.style.setProperty("--ei-viewport-height", `${T?.height || I.innerHeight}px`), e.style.setProperty("--ei-viewport-offset", `${T?.offsetTop || 0}px`);
  };
  return I.addEventListener("resize", B, { signal: w.signal }), I.visualViewport?.addEventListener("resize", B, { signal: w.signal }), I.visualViewport?.addEventListener("scroll", B, { signal: w.signal }), I.addEventListener("beforeunload", (T) => {
    p.hasUnsavedChanges() && (T.preventDefault(), T.returnValue = "");
  }, { signal: w.signal }), e.addEventListener("keydown", (T) => {
    T.stopPropagation(), T.key === "Escape" && u.expanded && (T.preventDefault(), $(U.minimize()));
  }, { signal: w.signal }), B(), A(), {
    async open(T = {}) {
      if (q) throw new Error("This inquiry surface has been disposed.");
      const { opener: L, stage: d, ...y } = T, R = L?.ownerDocument === g && typeof L.focus == "function" ? L : null;
      (R || !u.open || !u.expanded) && (C = R || g.activeElement);
      const N = z(y.context || i);
      return S({ open: !0, expanded: !0 }), await p.open({ ...y, suggestedIntent: b.fixedIntent || y.suggestedIntent, context: N }), d === "review" && l.stage === "details" ? await U.review() : d === "details" && l.stage === "review" && p.edit(), p.getState();
    },
    async beforeLeave() {
      if (q) return !0;
      S({ leaving: !0 });
      const T = await p.beforeLeave();
      return S({ leaving: !1, ...T ? {} : { open: !0, expanded: !0 } }), T;
    },
    getContext: () => l.draft || l.project ? p.getContext() : null,
    resume: U.expand,
    openProject: U.openProject,
    review: U.review,
    confirm: U.confirm,
    // The host must first pass beforeLeave; suspension never discards a draft.
    suspend: () => S({ open: !1, expanded: !1 }),
    minimize: U.minimize,
    async dispose() {
      return q ? !0 : await p.beforeLeave() ? (q = !0, w.abort(), W(), p.dispose(), s.unmount(), e.classList.remove("embedded-inquiry-host"), e.style.removeProperty("--ei-viewport-height"), e.style.removeProperty("--ei-viewport-offset"), ye(f, { open: !1, expanded: !1, busy: !1, draftId: null }), !0) : (S({ open: !0, expanded: !0 }), !1);
    }
  };
}
function At(e, r) {
  if (!r?.repository) throw new TypeError("A client inquiry requires its own repository adapter.");
  return yt(e, r);
}
const Be = "1", ie = Object.freeze(["inquiry", "selectedPart", "capturedView", "drawingDetail", "story"]);
function qt(e) {
  if (!e || e.version !== Be)
    throw new _("UNSUPPORTED_ADAPTER_VERSION", "Use a viewer adapter implementing integration contract version 1.");
  const r = Fe(e.capabilities);
  if (ze(r, ie, "Viewer capabilities"), ie.some((i) => typeof r[i] != "boolean") || r.inquiry !== !0)
    throw new _("INVALID_ADAPTER", "Declare every viewer capability as a boolean, with inquiry enabled.");
  if (ie.slice(1).some((i) => r[i]) && typeof e.capture != "function")
    throw new _("INVALID_ADAPTER", "Enabled viewer capabilities need a capture method.");
  if (r.capturedView && typeof e.restore != "function")
    throw new _("INVALID_ADAPTER", "Captured views need a restore method.");
  return Object.freeze({
    version: Be,
    id: le(e.id, "Adapter identity"),
    adapterVersion: le(e.adapterVersion, "Adapter version"),
    coordinateFrame: le(e.coordinateFrame, "Coordinate frame"),
    capabilities: Object.freeze(r)
  });
}
function Ie(e, r) {
  if (!ie.includes(r) || e.capabilities[r] !== !0)
    throw new _("UNSUPPORTED_CAPABILITY", `This viewer does not support ${r}. The saved reference is unchanged.`);
}
const Q = (e) => JSON.parse(JSON.stringify(e)), It = ["part", "snapshot", "drawing", "document", "chapter"], Et = ["part", "chapter", "drawing", "document", "inspection", "viewerReference"], Rt = (e, r) => ["productId", "productRevision", "modelId", "modelRevision", "roomReleaseId", "inquiryProfileVersion"].every((i) => e[i] === r[i]);
function St({ adapter: e, context: r, timeoutMs: i = 8e3 } = {}) {
  const a = qt(e), t = z(r);
  le(t.productRevision, "Product revision");
  const o = Q(t);
  for (const b of Et) delete o[b];
  if (!Number.isFinite(i) || i < 1 || i > 6e4) throw new TypeError("Use a viewer timeout between 1 and 60,000 milliseconds.");
  let f = null, v = !1, E = 0;
  const h = () => {
    if (v) throw new _("DISPOSED", "This viewer integration has been closed.");
  };
  function g(b = "CANCELLED", p = "The viewer operation was cancelled. Your saved reference is unchanged.") {
    if (!f) return;
    const s = f;
    f = null, s.controller.abort(new _(b, p));
  }
  async function I(b, p, { signal: s } = {}) {
    if (h(), s?.aborted) throw new _("CANCELLED", "The viewer operation was cancelled.");
    if (s && (typeof s.addEventListener != "function" || typeof s.removeEventListener != "function")) throw new TypeError("Pass an AbortSignal.");
    g("STALE_OPERATION", "A newer viewer operation replaced this one. Its result was not attached.");
    const m = new AbortController(), l = { controller: m, sequence: ++E, kind: b };
    f = l;
    let u, q;
    const C = () => m.abort(new _("CANCELLED", "The viewer operation was cancelled."));
    s?.addEventListener("abort", C, { once: !0 });
    const w = new Promise((A, S) => {
      q = () => S(m.signal.reason || new _("CANCELLED", "The viewer operation was cancelled.")), m.signal.addEventListener("abort", q, { once: !0 });
    });
    u = setTimeout(() => m.abort(new _("VIEWER_TIMEOUT", "The viewer did not respond in time. Your saved reference is unchanged. Try again.")), i);
    try {
      const A = await Promise.race([Promise.resolve().then(() => {
        if (m.signal.aborted) throw m.signal.reason;
        return p(m.signal);
      }), w]);
      if (v || f !== l || m.signal.aborted) throw m.signal.reason || new _("STALE_OPERATION", "This viewer result is no longer current.");
      return A;
    } finally {
      clearTimeout(u), s?.removeEventListener("abort", C), m.signal.removeEventListener("abort", q), f === l && (f = null);
    }
  }
  return Object.freeze({
    capabilities: () => Q(a.capabilities),
    descriptor: () => Q(a),
    captureContext(b) {
      return I("capture", async (p) => {
        if (!ie.slice(1).some((l) => a.capabilities[l])) return Q(o);
        const s = Fe(await e.capture({ signal: p }));
        ze(s, It, "The captured view");
        for (const [l, u] of [["part", "selectedPart"], ["snapshot", "capturedView"], ["drawing", "drawingDetail"], ["document", "drawingDetail"], ["chapter", "story"]])
          Object.hasOwn(s, l) && Ie(a, u);
        if (a.capabilities.capturedView && !Object.hasOwn(s, "snapshot")) throw new _("INVALID_REFERENCE", "The viewer did not capture its promised saved view.");
        const m = { ...Q(o) };
        for (const l of ["part", "drawing", "document", "chapter"]) Object.hasOwn(s, l) && (m[l] = s[l]);
        return Object.hasOwn(s, "snapshot") && (m.viewerReference = Oe({
          version: "1",
          adapter: { id: a.id, version: a.adapterVersion, coordinateFrame: a.coordinateFrame },
          product: { id: o.productId, revision: o.productRevision },
          model: { id: o.modelId, revision: o.modelRevision },
          snapshot: s.snapshot
        }, m)), z(m);
      }, b);
    },
    restoreContext(b, p) {
      return I("restore", async (s) => {
        Ie(a, "capturedView");
        const m = z(b);
        if (!Rt(m, o)) throw new _("IDENTITY_MISMATCH", "This saved view belongs to another product or version. Open its original product to restore it.");
        const l = Oe(m.viewerReference, m);
        if (l.adapter.id !== a.id || l.adapter.version !== a.adapterVersion || l.adapter.coordinateFrame !== a.coordinateFrame)
          throw new _("INCOMPATIBLE_ADAPTER", "This saved view needs its original compatible viewer adapter and coordinate frame. It has not been changed.");
        for (const [u, q] of [["part", "selectedPart"], ["drawing", "drawingDetail"], ["chapter", "story"]])
          m[u] && Ie(a, q);
        return await e.restore(Q(l.snapshot), { signal: s }), Q(m);
      }, p);
    },
    cancel() {
      h(), g();
    },
    dispose() {
      v || (v = !0, g("DISPOSED", "This viewer integration was closed."));
    }
  });
}
const Dt = "0.1.0";
export {
  Me as INQUIRY_INTENTS,
  Pt as INQUIRY_RULES_VERSION,
  Dt as INTEGRATION_KIT_VERSION,
  x as ProjectError,
  kt as assertReview,
  Ee as cloneProjectValue,
  at as confirmInquirySubmission,
  jt as createInquiryDraft,
  ct as createInquirySession,
  St as createIntegrationController,
  At as mountEmbeddedInquiry,
  Vt as normalizeInquiryDraft,
  pt as normalizeInquiryPresentation,
  Ut as normalizeInspectionReference,
  z as normalizeProjectContext,
  it as prepareInquirySubmission,
  K as projectContextKey,
  mr as reviewInquiry,
  _t as reviewedProjectValue,
  M as sameProjectValue
};
